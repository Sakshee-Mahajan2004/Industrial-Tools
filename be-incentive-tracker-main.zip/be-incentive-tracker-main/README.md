# Incentive Tracker Backend

A comprehensive Spring Boot backend application for managing incentive calculations and tracking, built with Gradle.

## Features

- **JWT Authentication** - Secure API access with Bearer tokens
- **PostgreSQL Database** - Robust data persistence
- **Flyway Migrations** - Version-controlled database schema management
- **Gradle Build System** - Modern, flexible build automation
- **MapStruct Integration** - Type-safe entity-DTO mapping with automatic field calculations
- **Swagger Documentation** - Interactive API documentation
- **Role-based Access Control** - Fine-grained permissions
- **Comprehensive APIs** - Full CRUD operations for all entities
- **Incentive Calculation Engine** - Complex business logic implementation

## Tech Stack

- **Spring Boot 3.2.0**
- **Spring Security** with JWT
- **Spring Data JPA**
- **PostgreSQL**
- **Gradle 8.5** for build automation
- **Flyway** for database migrations
- **MapStruct** for entity mapping
- **Swagger/OpenAPI 3**
- **Lombok** for boilerplate reduction

## Getting Started

### Prerequisites

- Java 17 or higher
- Gradle 8.5+ (or use included wrapper)
- PostgreSQL 12+

### Database Setup

1. Create a PostgreSQL database:
```sql
CREATE DATABASE incentive_tracker;
```

2. Update `application.yml` with your database credentials:
```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/incentive_tracker
    username: your_username
    password: your_password
```

### Database Migrations

The application uses Flyway for database migrations. Migrations are automatically applied on startup.

#### Manual Migration Commands
```bash
# Run migrations
./gradlew flywayMigrate

# Check migration status
./gradlew flywayInfo

# Clean database (development only)
./gradlew flywayClean

# Local development migrations
./gradlew flywayMigrateLocal
```

#### Migration Files Location
- **Location**: `src/main/resources/db/migration/`
- **Naming**: `V{version}__{description}.sql`
- **Examples**: 
  - `V1__Create_initial_schema.sql`
  - `V2__Insert_default_admin_user.sql`

### Running the Application

1. Clone the repository
2. Navigate to the backend directory
3. Run the application:
```bash
./gradlew bootRun

# With specific profile
./gradlew bootRun -Pprofile=dev
```

The application will start on `http://localhost:8080/api`

## API Documentation

Once the application is running, access the Swagger UI at:
- **Swagger UI**: http://localhost:8080/api/swagger-ui.html
- **API Docs**: http://localhost:8080/api/api-docs

## Authentication

### Default Admin User
- **Username**: admin
- **Password**: admin123

### Getting JWT Token

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

### Using JWT Token

Include the token in the Authorization header:
```bash
Authorization: Bearer <your-jwt-token>
```

## API Endpoints

### Authentication
- `POST /auth/login` - User login

### Candidates
- `GET /candidates` - Get all candidates (paginated)
- `GET /candidates/{id}` - Get candidate by ID
- `POST /candidates` - Create new candidate
- `PUT /candidates/{id}` - Update candidate
- `DELETE /candidates/{id}` - Delete candidate
- `POST /candidates/{id}/margin-revisions` - Add margin revision

### Coordinators
- `GET /coordinators` - Get all coordinators
- `POST /coordinators` - Create new coordinator
- `PUT /coordinators/{id}` - Update coordinator
- `DELETE /coordinators/{id}` - Delete coordinator

### Incentive Cycles
- `GET /incentive-cycles` - Get all cycles
- `POST /incentive-cycles` - Start new cycle
- `POST /incentive-cycles/{id}/hours` - Add hours to cycle
- `POST /incentive-cycles/{id}/calculate` - Calculate incentives
- `POST /incentive-cycles/{id}/approve` - Approve cycle
- `POST /incentive-cycles/{id}/cancel` - Cancel cycle

### Master Data
- `GET /master-data/contract-types` - Get contract types
- `GET /master-data/incentive-tiers` - Get incentive tiers
- `GET /master-data/user-permissions` - Get user permissions

## Permissions

The system supports role-based access control with the following permissions:

- `ADD_CANDIDATES` - Create and modify candidates
- `MARGIN_REVISION` - Add margin revisions
- `COORDINATORS` - Manage coordinators
- `START_INCENTIVE_CYCLE` - Start new cycles
- `CALCULATE_INCENTIVE_CYCLE` - Calculate incentives
- `ADD_HOURS` - Add hours to cycles
- `APPROVE_INCENTIVE_CYCLE` - Approve cycles
- `CUSTOM_REPORTS` - Generate custom reports
- `LEGACY_REPORTS` - Access legacy reports
- `DOWNLOAD` - Download reports
- `USER_MANAGEMENT` - Manage users
- `DELETE_APPROVED_CYCLES` - Delete approved cycles

## Business Logic

### MapStruct Integration

The application uses MapStruct for entity-DTO mapping with automatic field calculations:

#### Automatic Calculations
- **Candidate Fields**: Net purchase, margin, MSP fees automatically calculated
- **Margin Revisions**: All financial fields calculated on mapping
- **Type Safety**: Compile-time validation of mappings
- **Performance**: No reflection, pure method calls

#### Custom Mapping Logic
```java
@AfterMapping
default void calculateFields(@MappingTarget Candidate candidate) {
    // Custom calculation logic after mapping
}
```

### Incentive Calculation Rules

#### W2/C2C Candidates
- **160 Hour Threshold**: First incentive processed after 160 hours
- **Early Termination**: Only recruiter gets ₹2,000 if project ends before 160 hours
- **Recurring Incentives**: Based on margin tiers after 160 hours
- **Pro-rata Calculation**: For months with less than 160 hours

#### Margin-based Incentive Tiers
| Margin Range | Incentive Amount |
|--------------|------------------|
| $1.00-$2.00  | ₹500            |
| $2.01-$4.00  | ₹1,000          |
| $4.01-$6.00  | ₹1,500          |
| $6.01-$8.00  | ₹2,000          |
| $8.01-$10.00 | ₹2,500          |
| $10.01-$15.00| ₹3,500          |
| $15.01-$20.00| ₹4,000          |
| $20.01-$30.00| ₹4,500          |
| $30.01-$40.00| ₹7,000          |
| $40.01-$50.00| ₹10,000         |

#### One-time Incentives (at 160 hours)
- **CRM**: ₹1,000
- **Manager**: ₹1,500
- **Senior Manager**: ₹1,500
- **Associate Director**: ₹1,750
- **Center Head**: ₹1,500

#### Team Lead
- **Recurring**: ₹250 per placement (after 160 hours)

## Development

### Database Migrations

#### Creating New Migrations
1. Create new file in `src/main/resources/db/migration/`
2. Follow naming convention: `V{next_version}__{description}.sql`
3. Write SQL DDL/DML statements
4. Test migration with `mvn flyway:migrate`

#### Migration Best Practices
- **Never modify existing migrations** in production
- **Always backup** before running migrations
- **Test migrations** on development environment first
- **Use transactions** for data migrations

### MapStruct Development

#### Adding New Mappers
1. Create interface in `mapper` package
2. Annotate with `@Mapper(componentModel = "spring")`
3. Add `@Component` annotation
4. Configure mapping strategies
5. Add custom logic with `@AfterMapping`

#### Mapper Configuration
```java
@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
```

### Adding New Features

1. Create entity in `entity` package
2. Create migration file for database changes
3. Create repository in `repository` package
4. Create DTOs in `dto` package
5. Create mapper interface in `mapper` package
6. Create service in `service` package
7. Create controller in `controller` package
8. Add appropriate security annotations

### Testing

Run tests with:
```bash
./gradlew test
```

## Production Deployment

1. Set environment variables:
```bash
export DB_USERNAME=your_db_user
export DB_PASSWORD=your_db_password
export JWT_SECRET=your_jwt_secret_key
```

2. Build the application:
```bash
./gradlew clean build
```

3. Run the JAR:
```bash
java -jar build/libs/incentive-tracker-backend-0.0.1-SNAPSHOT.jar
```

### Production Database Setup

1. **Create production database**
2. **Set environment variables** for database connection
3. **Run Flyway migrations**:
```bash
./gradlew flywayMigrate -Pflyway.url=jdbc:postgresql://prod-host:5432/incentive_tracker
```
4. **Start application** with production profile

## Gradle Commands

### Build Commands
```bash
# Clean build
./gradlew clean build

# Run application
./gradlew bootRun

# Run tests
./gradlew test

# Check dependencies
./gradlew dependencies
```

### Database Commands
```bash
# Flyway migrations
./gradlew flywayMigrate
./gradlew flywayInfo
./gradlew flywayClean

# Local development
./gradlew flywayMigrateLocal
./gradlew flywayInfoLocal
```

### Development Commands
```bash
# Continuous build
./gradlew build --continuous

# Run with profile
./gradlew bootRun -Pprofile=dev

# Debug mode
./gradlew bootRun --debug-jvm
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## Gradle vs Maven Benefits

### **Performance**
- **Incremental builds** - Only rebuilds what changed
- **Build cache** - Reuses outputs from previous builds
- **Parallel execution** - Runs tasks in parallel when possible

### **Flexibility**
- **Groovy/Kotlin DSL** - More expressive build scripts
- **Custom tasks** - Easy to create custom build logic
- **Plugin ecosystem** - Rich plugin ecosystem

### **Developer Experience**
- **Gradle wrapper** - No need to install Gradle
- **Better dependency management** - More flexible dependency resolution
- **IDE integration** - Better IDE support and integration

## License

This project is licensed under the MIT License.
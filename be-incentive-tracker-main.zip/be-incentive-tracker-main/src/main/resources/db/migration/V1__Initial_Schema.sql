-- Initial schema for Incentive Tracker (all tables, relationships, and indexes)

-- Enable pgcrypto extension for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users table
CREATE TABLE users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(255) NOT NULL,
    middle_name VARCHAR(255),
    last_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(50),
    role VARCHAR(50) NOT NULL DEFAULT 'USER',
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid
);

-- User permissions table
CREATE TABLE user_permissions (
    user_id uuid NOT NULL,
    permission VARCHAR(100) NOT NULL,
    PRIMARY KEY (user_id, permission),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Coordinators table
CREATE TABLE coordinators (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid
);

-- Candidates table
CREATE TABLE candidates (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id VARCHAR(255) UNIQUE NOT NULL,
    candidate_name VARCHAR(255) NOT NULL,
    client_name VARCHAR(255) NOT NULL,
    contract_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    pay_rate DECIMAL(10,2),
    w2_payroll_admin_taxes_percentage DECIMAL(5,2),
    w2_payroll_admin_taxes DECIMAL(10,2),
    w2c2c_overhead_cost_percentage DECIMAL(5,2),
    w2c2c_overhead_cost DECIMAL(10,2),
    health_benefits DECIMAL(10,2),
    net_purchase DECIMAL(10,2),
    bill_rate DECIMAL(10,2),
    msp_fees_percentage DECIMAL(5,2),
    msp_fees_dollar DECIMAL(10,2),
    net_bill_rate DECIMAL(10,2),
    margin DECIMAL(10,2),
    finder_fees DECIMAL(10,2),
    recruiter_id uuid,
    lead_id uuid,
    manager_id uuid,
    senior_manager_id uuid,
    crm_id uuid,
    asso_director_id uuid,
    center_head_id uuid,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    FOREIGN KEY (recruiter_id) REFERENCES coordinators(id),
    FOREIGN KEY (lead_id) REFERENCES coordinators(id),
    FOREIGN KEY (manager_id) REFERENCES coordinators(id),
    FOREIGN KEY (senior_manager_id) REFERENCES coordinators(id),
    FOREIGN KEY (crm_id) REFERENCES coordinators(id),
    FOREIGN KEY (asso_director_id) REFERENCES coordinators(id),
    FOREIGN KEY (center_head_id) REFERENCES coordinators(id)
);

-- Margin revisions table
CREATE TABLE margin_revisions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id uuid NOT NULL,
    effective_date DATE NOT NULL,
    contract_type VARCHAR(50),
    pay_rate DECIMAL(10,2),
    w2_payroll_admin_taxes_percentage DECIMAL(5,2),
    w2_c2c_overhead_cost_percentage DECIMAL(5,2),
    health_benefits DECIMAL(10,2),
    bill_rate DECIMAL(10,2),
    msp_fees_percentage DECIMAL(5,2),
    finder_fees DECIMAL(10,2),
    w2_payroll_admin_taxes DECIMAL(10,2),
    w2c2c_overhead_cost DECIMAL(10,2),
    net_purchase DECIMAL(10,2),
    msp_fees_dollar DECIMAL(10,2),
    net_bill_rate DECIMAL(10,2),
    margin DECIMAL(10,2),
    reason TEXT,
    created_by uuid,
    updated_by uuid,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
);

-- Incentive cycles table
CREATE TABLE incentive_cycles (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    month VARCHAR(7) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'DRAFT',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    calculated_at TIMESTAMP,
    approved_at TIMESTAMP,
    cancelled_at TIMESTAMP,
    cancellation_reason TEXT,
    notes TEXT,
    created_by uuid,
    updated_by uuid,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Monthly hours table
CREATE TABLE monthly_hours (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_id uuid NOT NULL,
    candidate_id VARCHAR(255) NOT NULL,
    month VARCHAR(7) NOT NULL,
    hours_worked DECIMAL(10,2) NOT NULL,
    is_retroactive BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Incentive calculations table
CREATE TABLE incentive_calculations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_id uuid NOT NULL,
    coordinator_name VARCHAR(255) NOT NULL,
    coordinator_type VARCHAR(50) NOT NULL,
    candidate_id VARCHAR(255) NOT NULL,
    candidate_name VARCHAR(255) NOT NULL,
    month VARCHAR(7) NOT NULL,
    hours_worked DECIMAL(10,2),
    margin DECIMAL(10,2),
    incentive_amount DECIMAL(10,2),
    is_recurring BOOLEAN DEFAULT false,
    is_one_time BOOLEAN DEFAULT false,
    is_full_time BOOLEAN DEFAULT false,
    finder_fees DECIMAL(10,2),
    placement_count INTEGER,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Incentive adjustments table
CREATE TABLE incentive_adjustments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_id uuid NOT NULL,
    coordinator_name VARCHAR(255) NOT NULL,
    coordinator_type VARCHAR(50) NOT NULL,
    candidate_id VARCHAR(255) NOT NULL,
    candidate_name VARCHAR(255) NOT NULL,
    affected_month VARCHAR(7) NOT NULL,
    original_incentive DECIMAL(10,2),
    revised_incentive DECIMAL(10,2),
    adjustment_amount DECIMAL(10,2),
    adjustment_type VARCHAR(50) NOT NULL,
    margin_revision_id VARCHAR(255),
    processed_in_cycle VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Coordinator reports table
CREATE TABLE coordinator_reports (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_id uuid NOT NULL,
    coordinator_name VARCHAR(255) NOT NULL,
    coordinator_email VARCHAR(255) NOT NULL,
    coordinator_location VARCHAR(255) NOT NULL,
    total_incentive DECIMAL(10,2),
    adjustment_amount DECIMAL(10,2),
    sent_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    FOREIGN KEY (cycle_id) REFERENCES incentive_cycles(id) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX idx_candidates_candidate_id ON candidates(candidate_id);
CREATE INDEX idx_candidates_client_name ON candidates(client_name);
CREATE INDEX idx_margin_revisions_candidate_id ON margin_revisions(candidate_id);
CREATE INDEX idx_margin_revisions_effective_date ON margin_revisions(effective_date);
CREATE INDEX idx_incentive_cycles_month ON incentive_cycles(month);
CREATE INDEX idx_incentive_cycles_status ON incentive_cycles(status);
CREATE INDEX idx_monthly_hours_cycle_id ON monthly_hours(cycle_id);
CREATE INDEX idx_monthly_hours_candidate_id ON monthly_hours(candidate_id);
CREATE INDEX idx_incentive_calculations_cycle_id ON incentive_calculations(cycle_id);
CREATE INDEX idx_incentive_adjustments_cycle_id ON incentive_adjustments(cycle_id);
CREATE INDEX idx_coordinator_reports_cycle_id ON coordinator_reports(cycle_id);
CREATE INDEX idx_candidates_recruiter_id ON candidates(recruiter_id);
CREATE INDEX idx_candidates_lead_id ON candidates(lead_id);
CREATE INDEX idx_candidates_manager_id ON candidates(manager_id);
CREATE INDEX idx_candidates_senior_manager_id ON candidates(senior_manager_id);
CREATE INDEX idx_candidates_crm_id ON candidates(crm_id);
CREATE INDEX idx_candidates_asso_director_id ON candidates(asso_director_id);
CREATE INDEX idx_candidates_center_head_id ON candidates(center_head_id);

-- Insert initial admin user
INSERT INTO users (
    id, username, email, password, first_name, middle_name, last_name, phone_number, role, is_active, created_at, updated_at, created_by, updated_by
) VALUES (
    gen_random_uuid(),
    'admin',
    'admin@example.com',
    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- bcrypt hash for 'admin123' (replace as needed)
    'Admin',
    NULL,
    'User',
    '+10000000000',
    'ADMIN',
    true,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL,
    NULL
);

-- Add all permissions for the admin user
INSERT INTO user_permissions (user_id, permission) 
SELECT id, perm FROM users, (VALUES
    ('ADD_CANDIDATES'),
    ('MARGIN_REVISION'),
    ('COORDINATORS'),
    ('START_INCENTIVE_CYCLE'),
    ('CALCULATE_INCENTIVE_CYCLE'),
    ('ADD_HOURS'),
    ('APPROVE_INCENTIVE_CYCLE'),
    ('CUSTOM_REPORTS'),
    ('LEGACY_REPORTS'),
    ('DOWNLOAD'),
    ('USER_MANAGEMENT'),
    ('DELETE_APPROVED_CYCLES')
) AS perms(perm)
WHERE username = 'admin';



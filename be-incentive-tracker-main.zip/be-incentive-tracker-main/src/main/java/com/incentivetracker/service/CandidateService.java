package com.incentivetracker.service;

import com.incentivetracker.dto.CandidateDto;
import com.incentivetracker.dto.MarginRevisionDto;
import com.incentivetracker.entity.Candidate;
import com.incentivetracker.entity.MarginRevision;
import com.incentivetracker.exception.ResourceNotFoundException;
import com.incentivetracker.mapper.CandidateMapper;
import com.incentivetracker.mapper.MarginRevisionMapper;
import com.incentivetracker.repository.CandidateRepository;
import com.incentivetracker.repository.CoordinatorRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class CandidateService {

    private final CandidateRepository candidateRepository;
    private final CandidateMapper candidateMapper;
    private final MarginRevisionMapper marginRevisionMapper;
    
    private final CoordinatorRepository coordinatorRepository;

    public Page<CandidateDto> getAllCandidates(Pageable pageable) {
        return candidateRepository.findAll(pageable)
                .map(candidateMapper::toDto);
    }

    public CandidateDto getCandidateById(UUID id) {
        Candidate candidate = candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + id));
        return candidateMapper.toDto(candidate);
    }

    public CandidateDto getCandidateByCandidateId(String candidateId) {
        Candidate candidate = candidateRepository.findByCandidateId(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with candidateId: " + candidateId));
        return candidateMapper.toDto(candidate);
    }

    public CandidateDto createCandidate(CandidateDto candidateDto) {
        if (candidateRepository.existsByCandidateId(candidateDto.getCandidateId())) {
            throw new IllegalArgumentException("Candidate with ID " + candidateDto.getCandidateId() + " already exists");
        }
        
        Candidate candidate = candidateMapper.toEntity(candidateDto);
        calculateFields(candidate);
        candidate = candidateRepository.save(candidate);
        return candidateMapper.toDto(candidate);
    }
    
    public CandidateDto updateCandidate(UUID id, CandidateDto candidateDto) {
        Candidate existingCandidate = candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + id));
    
        candidateMapper.updateEntityFromDto(candidateDto, existingCandidate);
    
        if (candidateDto.getRecruiter() != null && candidateDto.getRecruiter().getId() != null) {
            existingCandidate.setRecruiter(
                coordinatorRepository.findById(candidateDto.getRecruiter().getId()).orElse(null)
            );
        } else {
            existingCandidate.setRecruiter(null);
        }
        if (candidateDto.getLead() != null && candidateDto.getLead().getId() != null) {
            existingCandidate.setLead(
                coordinatorRepository.findById(candidateDto.getLead().getId()).orElse(null)
            );
        } else {
            existingCandidate.setLead(null);
        }
        if (candidateDto.getManager() != null && candidateDto.getManager().getId() != null) {
            existingCandidate.setManager(
                coordinatorRepository.findById(candidateDto.getManager().getId()).orElse(null)
            );
        } else {
            existingCandidate.setManager(null);
        }
        if (candidateDto.getSeniorManager() != null && candidateDto.getSeniorManager().getId() != null) {
            existingCandidate.setSeniorManager(
                coordinatorRepository.findById(candidateDto.getSeniorManager().getId()).orElse(null)
            );
        } else {
            existingCandidate.setSeniorManager(null);
        }
        if (candidateDto.getCrm() != null && candidateDto.getCrm().getId() != null) {
            existingCandidate.setCrm(
                coordinatorRepository.findById(candidateDto.getCrm().getId()).orElse(null)
            );
        } else {
            existingCandidate.setCrm(null);
        }
        if (candidateDto.getAssoDirector() != null && candidateDto.getAssoDirector().getId() != null) {
            existingCandidate.setAssoDirector(
                coordinatorRepository.findById(candidateDto.getAssoDirector().getId()).orElse(null)
            );
        } else {
            existingCandidate.setAssoDirector(null);
        }
        if (candidateDto.getCenterHead() != null && candidateDto.getCenterHead().getId() != null) {
            existingCandidate.setCenterHead(
                coordinatorRepository.findById(candidateDto.getCenterHead().getId()).orElse(null)
            );
        } else {
            existingCandidate.setCenterHead(null);
        }
    
        calculateFields(existingCandidate);
        existingCandidate = candidateRepository.save(existingCandidate);
        return candidateMapper.toDto(existingCandidate);
    }

    public void deleteCandidate(UUID id) {
        if (!candidateRepository.existsById(id)) {
            throw new ResourceNotFoundException("Candidate not found with id: " + id);
        }
        candidateRepository.deleteById(id);
    }

    public MarginRevisionDto addMarginRevision(UUID candidateId, MarginRevisionDto revisionDto) {
        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + candidateId));
        
        MarginRevision revision = marginRevisionMapper.toEntity(revisionDto);
        revision.setCandidate(candidate);
        calculateRevisionFields(revision, candidate);
        
        candidate.getMarginRevisions().add(revision);
        candidateRepository.save(candidate);
        
        return marginRevisionMapper.toDto(revision);
    }

    public List<MarginRevisionDto> getMarginRevisions(UUID candidateId) {
        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found with id: " + candidateId));
        
        return candidate.getMarginRevisions().stream()
                .map(marginRevisionMapper::toDto)
                .toList();
    }

    public List<CandidateDto> getActiveCandidates() {
        List<Candidate> activeCandidates = candidateRepository.findActiveCandidatesForDate(LocalDate.now());
        return activeCandidates.stream()
                .map(candidateMapper::toDto)
                .toList();
    }

    public List<CandidateDto> getCandidatesByClient(String clientName) {
        List<Candidate> candidates = candidateRepository.findByClientName(clientName);
        return candidates.stream()
                .map(candidateMapper::toDto)
                .toList();
    }

    public List<CandidateDto> getAllCandidatesList() {
        List<Candidate> candidatesList = candidateRepository.findAll();
        return candidatesList.stream()
                .map(candidateMapper::toDto)
                .toList();
    }

    private void calculateFields(Candidate candidate) {
        // Calculation logic is now handled by MapStruct @AfterMapping in CandidateMapper
        // This method can be removed or used for additional business logic
    }

    private void calculateRevisionFields(MarginRevision revision, Candidate candidate) {
        // Calculation logic is now handled by MapStruct @AfterMapping in MarginRevisionMapper
        // This method can be removed or used for additional business logic
    }
}
package com.incentivetracker.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.incentivetracker.mapper")
public class MapStructConfig {
    // This configuration ensures MapStruct mappers are properly scanned and registered as Spring beans
}
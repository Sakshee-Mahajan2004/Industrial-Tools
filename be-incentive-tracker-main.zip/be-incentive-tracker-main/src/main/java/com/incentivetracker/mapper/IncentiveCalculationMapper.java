package com.incentivetracker.mapper;

import com.incentivetracker.dto.IncentiveCalculationDto;
import com.incentivetracker.entity.IncentiveCalculation;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface IncentiveCalculationMapper {
    
    IncentiveCalculationDto toDto(IncentiveCalculation calculation);
    
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    IncentiveCalculation toEntity(IncentiveCalculationDto calculationDto);
}
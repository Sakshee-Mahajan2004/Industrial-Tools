package com.incentivetracker.mapper;

import com.incentivetracker.dto.IncentiveAdjustmentDto;
import com.incentivetracker.entity.IncentiveAdjustment;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface IncentiveAdjustmentMapper {
    
    IncentiveAdjustmentDto toDto(IncentiveAdjustment adjustment);
    
    @Mapping(target = "id", ignore = true)
    IncentiveAdjustment toEntity(IncentiveAdjustmentDto adjustmentDto);
}
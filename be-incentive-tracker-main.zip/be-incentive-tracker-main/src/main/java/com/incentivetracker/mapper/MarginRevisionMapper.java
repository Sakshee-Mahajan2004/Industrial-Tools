package com.incentivetracker.mapper;

import com.incentivetracker.dto.MarginRevisionDto;
import com.incentivetracker.entity.MarginRevision;
import org.mapstruct.*;
import org.springframework.stereotype.Component;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
@Component
public interface MarginRevisionMapper {
    
    MarginRevisionDto toDto(MarginRevision marginRevision);
    
    @Mapping(target = "id", ignore = true)
    MarginRevision toEntity(MarginRevisionDto marginRevisionDto);
    
    @AfterMapping
    default void calculateRevisionFields(@MappingTarget MarginRevision revision) {
        if (revision.getContractType() != null && 
            revision.getContractType() != com.incentivetracker.entity.Candidate.ContractType.FULLTIME) {
            
            // Calculate W2/C2C Overhead Cost
            if (revision.getPayRate() != null && revision.getW2C2COverheadCostPercentage() != null) {
                revision.setW2C2COverheadCost(
                    revision.getPayRate()
                        .multiply(revision.getW2C2COverheadCostPercentage())
                        .divide(java.math.BigDecimal.valueOf(100))
                );
            }
            
            // Calculate Net Purchase
            java.math.BigDecimal netPurchase = revision.getPayRate() != null ? revision.getPayRate() : java.math.BigDecimal.ZERO;
            if (revision.getW2C2COverheadCost() != null) {
                netPurchase = netPurchase.add(revision.getW2C2COverheadCost());
            }
            if (revision.getHealthBenefits() != null) {
                netPurchase = netPurchase.add(revision.getHealthBenefits());
            }
            revision.setNetPurchase(netPurchase);
            
            // Calculate MSP Fees Dollar
            if (revision.getBillRate() != null && revision.getMspFeesPercentage() != null) {
                revision.setMspFeesDollar(
                    revision.getBillRate()
                        .multiply(revision.getMspFeesPercentage())
                        .divide(java.math.BigDecimal.valueOf(100))
                );
            }
            
            // Calculate Net Bill Rate
            if (revision.getBillRate() != null && revision.getMspFeesDollar() != null) {
                revision.setNetBillRate(revision.getBillRate().subtract(revision.getMspFeesDollar()));
            }
            
            // Calculate Margin
            if (revision.getNetBillRate() != null && revision.getNetPurchase() != null) {
                revision.setMargin(revision.getNetBillRate().subtract(revision.getNetPurchase()));
            }
        }
    }
}
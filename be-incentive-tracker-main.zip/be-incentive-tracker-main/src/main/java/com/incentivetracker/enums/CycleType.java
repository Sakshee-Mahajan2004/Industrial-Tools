package com.incentivetracker.enums;

public enum CycleType {
    REGULAR, ADDITIONAL
}

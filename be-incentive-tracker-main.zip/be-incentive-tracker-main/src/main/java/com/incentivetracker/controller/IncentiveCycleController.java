package com.incentivetracker.controller;

import com.incentivetracker.dto.IncentiveCalculationDto;
import com.incentivetracker.dto.IncentiveCycleDto;
import com.incentivetracker.dto.MonthlyHoursDto;
import com.incentivetracker.service.IncentiveCycleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/incentive-cycles")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Incentive Cycles", description = "Incentive cycle management APIs")
public class IncentiveCycleController {

    private final IncentiveCycleService incentiveCycleService;

    @GetMapping
    @Operation(summary = "Get all incentive cycles", description = "Retrieve all incentive cycles with pagination")
    public ResponseEntity<Page<IncentiveCycleDto>> getAllCycles(Pageable pageable) {
        return ResponseEntity.ok(incentiveCycleService.getAllCycles(pageable));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get cycle by ID", description = "Retrieve a specific incentive cycle by ID")
    public ResponseEntity<IncentiveCycleDto> getCycleById(@PathVariable UUID id) {
        return ResponseEntity.ok(incentiveCycleService.getCycleById(id));
    }

    @GetMapping("/active")
    @Operation(summary = "Get active cycles", description = "Get all active (non-approved) cycles")
    public ResponseEntity<List<IncentiveCycleDto>> getActiveCycles() {
        return ResponseEntity.ok(incentiveCycleService.getActiveCycles());
    }

    @GetMapping("/approved")
    @Operation(summary = "Get approved cycles", description = "Get all approved cycles")
    public ResponseEntity<List<IncentiveCycleDto>> getApprovedCycles() {
        return ResponseEntity.ok(incentiveCycleService.getApprovedCycles());
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_START_INCENTIVE_CYCLE') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Start incentive cycle", description = "Start a new incentive cycle")
    public ResponseEntity<IncentiveCycleDto> startCycle(@Valid @RequestBody IncentiveCycleDto cycleDto) {
        return new ResponseEntity<>(incentiveCycleService.startCycle(cycleDto), HttpStatus.CREATED);
    }

    @PostMapping("/{id}/add-hours")
    @PreAuthorize("hasRole('ROLE_ADD_HOURS') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Add hours to cycle", description = "Add monthly hours to an incentive cycle")
    public ResponseEntity<IncentiveCycleDto> addHours(@PathVariable UUID id, 
                                                     @Valid @RequestBody List<MonthlyHoursDto> hoursDto) {
        return ResponseEntity.ok(incentiveCycleService.addHours(id, hoursDto));
    }

    @PostMapping("/{id}/add-calculations")
    @PreAuthorize("hasRole('ROLE_ADD_HOURS') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Add hours to cycle", description = "Add monthly hours to an incentive cycle")
    public ResponseEntity<IncentiveCycleDto> addCalculatedIncentive(@PathVariable UUID id, 
                                                     @Valid @RequestBody List<IncentiveCalculationDto> hoursDto) {
        return ResponseEntity.ok(incentiveCycleService.addCalculatedIncentive(id, hoursDto));
    }


    @PostMapping("/{id}/calculate-incentives")
    @PreAuthorize("hasRole('ROLE_CALCULATE_INCENTIVE_CYCLE') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Calculate incentives", description = "Calculate incentives for a cycle")
    public ResponseEntity<IncentiveCycleDto> calculateIncentives(@PathVariable UUID id) {
        return ResponseEntity.ok(incentiveCycleService.calculateIncentives(id));
    }

    @PostMapping("/{id}/approve")
    @PreAuthorize("hasRole('ROLE_APPROVE_INCENTIVE_CYCLE') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Approve cycle", description = "Approve an incentive cycle")
    public ResponseEntity<IncentiveCycleDto> approveCycle(@PathVariable UUID id) {
        return ResponseEntity.ok(incentiveCycleService.approveCycle(id));
    }

    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasRole('ROLE_START_INCENTIVE_CYCLE') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Cancel cycle", description = "Cancel an incentive cycle")
    public ResponseEntity<IncentiveCycleDto> cancelCycle(@PathVariable UUID id, 
                                                        @RequestParam String reason) {
        return ResponseEntity.ok(incentiveCycleService.cancelCycle(id, reason));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_DELETE_APPROVED_CYCLES') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Delete cycle", description = "Delete an incentive cycle")
    public ResponseEntity<Void> deleteCycle(@PathVariable UUID id) {
        incentiveCycleService.deleteCycle(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/approved")
    @PreAuthorize("hasRole('ROLE_DELETE_APPROVED_CYCLES') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Delete all approved cycles", description = "Delete all incentive cycles with status APPROVED")
    public ResponseEntity<Void> deleteAllApprovedCycles() {
        incentiveCycleService.deleteAllApprovedCycles();
        return ResponseEntity.noContent().build();
    }
}
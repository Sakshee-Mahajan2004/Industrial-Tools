package com.incentivetracker.controller;

import com.incentivetracker.dto.CandidateDto;
import com.incentivetracker.dto.MarginRevisionDto;
import com.incentivetracker.service.CandidateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/candidates")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "Candidates", description = "Candidate management APIs")
public class CandidateController {

    private final CandidateService candidateService;

    @GetMapping
    @Operation(summary = "Get all candidates", description = "Retrieve all candidates with pagination")
    public ResponseEntity<Page<CandidateDto>> getAllCandidates(Pageable pageable) {
        return ResponseEntity.ok(candidateService.getAllCandidates(pageable));
    }

    @GetMapping("/list")
    @Operation(summary = "Get all candidates as list", description = "Retrieve all candidates as a simple list (no pagination)")
    public ResponseEntity<List<CandidateDto>> getAllCandidatesList() {
        return ResponseEntity.ok(candidateService.getAllCandidatesList());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get candidate by ID", description = "Retrieve a specific candidate by ID")
    public ResponseEntity<CandidateDto> getCandidateById(@PathVariable UUID id) {
        return ResponseEntity.ok(candidateService.getCandidateById(id));
    }

    @GetMapping("/candidate-id/{candidateId}")
    @Operation(summary = "Get candidate by candidate ID", description = "Retrieve a specific candidate by candidate ID")
    public ResponseEntity<CandidateDto> getCandidateByCandidateId(@PathVariable String candidateId) {
        return ResponseEntity.ok(candidateService.getCandidateByCandidateId(candidateId));
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_ADD_CANDIDATES') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Create candidate", description = "Create a new candidate")
    public ResponseEntity<CandidateDto> createCandidate(@Valid @RequestBody CandidateDto candidateDto) {
        return new ResponseEntity<>(candidateService.createCandidate(candidateDto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADD_CANDIDATES') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Update candidate", description = "Update an existing candidate")
    public ResponseEntity<CandidateDto> updateCandidate(@PathVariable UUID id, 
                                                        @Valid @RequestBody CandidateDto candidateDto) {
        return ResponseEntity.ok(candidateService.updateCandidate(id, candidateDto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADD_CANDIDATES') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Delete candidate", description = "Delete a candidate by ID")
    public ResponseEntity<Void> deleteCandidate(@PathVariable UUID id) {
        candidateService.deleteCandidate(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/margin-revisions")
    @PreAuthorize("hasRole('ROLE_MARGIN_REVISION') or hasRole('ROLE_ADMIN')")
    @Operation(summary = "Add margin revision", description = "Add a margin revision for a candidate")
    public ResponseEntity<MarginRevisionDto> addMarginRevision(@PathVariable UUID id, 
                                                              @Valid @RequestBody MarginRevisionDto revisionDto) {
        return ResponseEntity.ok(candidateService.addMarginRevision(id, revisionDto));
    }

    @GetMapping("/{id}/margin-revisions")
    @Operation(summary = "Get margin revisions", description = "Get all margin revisions for a candidate")
    public ResponseEntity<List<MarginRevisionDto>> getMarginRevisions(@PathVariable UUID id) {
        return ResponseEntity.ok(candidateService.getMarginRevisions(id));
    }

    @GetMapping("/active")
    @Operation(summary = "Get active candidates", description = "Get all currently active candidates")
    public ResponseEntity<List<CandidateDto>> getActiveCandidates() {
        return ResponseEntity.ok(candidateService.getActiveCandidates());
    }

    @GetMapping("/by-client/{clientName}")
    @Operation(summary = "Get candidates by client", description = "Get all candidates for a specific client")
    public ResponseEntity<?> getCandidatesByClient(@PathVariable String clientName) {
        try {
            List<CandidateDto> candidates = candidateService.getCandidatesByClient(clientName);
            return ResponseEntity.ok(candidates);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to fetch candidates for client: " + clientName + ". Error: " + ex.getMessage());
        }
    }
}
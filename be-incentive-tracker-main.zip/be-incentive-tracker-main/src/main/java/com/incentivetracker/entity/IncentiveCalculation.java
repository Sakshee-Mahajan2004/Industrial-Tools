package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "incentive_calculations")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class IncentiveCalculation extends BaseEntity {
    @Column(nullable = false)
    private String coordinatorName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CoordinatorType coordinatorType;
    
    @Column(nullable = false)
    private String candidateId;
    
    @Column(nullable = false)
    private String candidateName;
    
    @Column(nullable = false)
    private String month;
    
    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal hoursWorked;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal margin;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal incentiveAmount;
    
    @Column(nullable = false)
    private Boolean isRecurring;
    
    @Column(nullable = false)
    private Boolean isOneTime;
    
    private Boolean isFullTime = false;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal finderFees;
    
    private Integer placementCount;
    
    private String notes;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cycle_id")
    private IncentiveCycle cycle;
    
    @CreationTimestamp
    private LocalDateTime createdAt;
    
    public enum CoordinatorType {
        RECRUITER, CRM, TEAM_LEAD, MANAGER, SENIOR_MANAGER, ASSO_DIRECTOR, CENTER_HEAD
    }
}
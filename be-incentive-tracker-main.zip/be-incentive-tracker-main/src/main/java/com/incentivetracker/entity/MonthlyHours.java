package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "monthly_hours")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class MonthlyHours extends BaseEntity {
    @Column(nullable = false)
    private String candidateId;
    
    @Column(nullable = false)
    private String month; // YYYY-MM format
    
    @Column(nullable = false, precision = 8, scale = 2)
    private BigDecimal hoursWorked;
    
    @Column(nullable = false)
    private Boolean isRetroactive = false;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cycle_id")
    private IncentiveCycle cycle;
    
    @CreationTimestamp
    private LocalDateTime createdAt;
}
package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "incentive_adjustments")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class IncentiveAdjustment extends BaseEntity {
    @Column(nullable = false)
    private String coordinatorName;
    
    @Column(nullable = false)
    private String coordinatorType;
    
    @Column(nullable = false)
    private String candidateId;
    
    @Column(nullable = false)
    private String candidateName;
    
    @Column(nullable = false)
    private String affectedMonth;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal originalIncentive;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal revisedIncentive;
    
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal adjustmentAmount;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AdjustmentType adjustmentType;
    
    @Column(nullable = false)
    private String marginRevisionId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cycle_id")
    private IncentiveCycle cycle;
    
    private String processedInCycle;
    
    public enum AdjustmentType {
        EXCESS, SHORTFALL
    }
}
package com.incentivetracker.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "users")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class User extends BaseEntity {
    @Column(unique = true, nullable = false)
    private String username;
    
    @Column(unique = true, nullable = false)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    @Column(nullable = false)
    private String firstName;

    private String middleName;

    @Column(nullable = false)
    private String lastName;

    private String phoneNumber;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role = Role.USER;
    
    @ElementCollection(fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @CollectionTable(name = "user_permissions", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "permission")
    private Set<Permission> permissions;
    
    @Column(nullable = false)
    private Boolean isActive = true;
    
    public enum Role {
        ADMIN, USER
    }
    
    public enum Permission {
        ADD_CANDIDATES,
        MARGIN_REVISION,
        COORDINATORS,
        START_INCENTIVE_CYCLE,
        CALCULATE_INCENTIVE_CYCLE,
        ADD_HOURS,
        APPROVE_INCENTIVE_CYCLE,
        CUSTOM_REPORTS,
        LEGACY_REPORTS,
        DOWNLOAD,
        USER_MANAGEMENT,
        DELETE_APPROVED_CYCLES
    }
}
package com.incentivetracker.repository;

import com.incentivetracker.entity.Coordinator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CoordinatorRepository extends JpaRepository<Coordinator, java.util.UUID> {
    Optional<Coordinator> findByEmail(String email);
    Boolean existsByEmail(String email);
}
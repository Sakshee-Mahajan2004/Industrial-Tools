package com.incentivetracker.repository;

import com.incentivetracker.entity.IncentiveCycle;
import com.incentivetracker.entity.MonthlyHours;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
@Repository
public interface MonthlyHoursRepository  extends JpaRepository<MonthlyHours, UUID> {

    long deleteByCycle(IncentiveCycle cycle);
}

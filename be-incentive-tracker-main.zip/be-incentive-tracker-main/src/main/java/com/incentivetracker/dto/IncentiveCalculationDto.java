package com.incentivetracker.dto;

import com.incentivetracker.entity.IncentiveCalculation;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class IncentiveCalculationDto {
    private java.util.UUID id;
    private String coordinatorName;
    private IncentiveCalculation.CoordinatorType coordinatorType;
    private String candidateId;
    private String candidateName;
    private String month;
    private BigDecimal hoursWorked;
    private BigDecimal margin;
    private BigDecimal incentiveAmount;
    private Boolean isRecurring;
    private Boolean isOneTime;
    private Boolean isFullTime;
    private BigDecimal finderFees;
    private Integer placementCount;
    private String notes;
}
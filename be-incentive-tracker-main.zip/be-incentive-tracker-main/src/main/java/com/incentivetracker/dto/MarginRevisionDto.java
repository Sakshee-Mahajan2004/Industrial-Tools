package com.incentivetracker.dto;

import com.incentivetracker.entity.Candidate;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class MarginRevisionDto {
    private java.util.UUID id;
    
    @NotNull(message = "Effective date is required")
    private LocalDate effectiveDate;
    
    private Candidate.ContractType contractType;
    private BigDecimal payRate;
    private BigDecimal w2PayrollAdminTaxesPercentage;
    private BigDecimal w2C2COverheadCostPercentage;
    private BigDecimal healthBenefits;
    private BigDecimal billRate;
    private BigDecimal mspFeesPercentage;
    private BigDecimal finderFees;
    
    // Calculated fields
    private BigDecimal w2PayrollAdminTaxes;
    private BigDecimal w2C2COverheadCost;
    private BigDecimal netPurchase;
    private BigDecimal mspFeesDollar;
    private BigDecimal netBillRate;
    private BigDecimal margin;
    
    private String reason;
    private String createdBy;
}
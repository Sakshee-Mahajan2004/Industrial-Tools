package com.incentivetracker.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class MonthlyHoursDto {
    private java.util.UUID id;
    
    @NotBlank(message = "Candidate ID is required")
    private String candidateId;
    
    @NotBlank(message = "Month is required")
    private String month;
    
    @NotNull(message = "Hours worked is required")
    @PositiveOrZero(message = "Hours worked must be positive or zero")
    private BigDecimal hoursWorked;
    
    private Boolean isRetroactive = false;
}
package com.amp.serviceImp;

import com.amp.dto.SearchDto;
import com.amp.entity.*;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.ActualBookRepo;
import com.amp.repository.GuestRepository;
import com.amp.repository.HotelRepository;
import com.amp.repository.RoomsRepository;
import com.amp.service.ActualBookService;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ActualBookImpl implements ActualBookService {

    @Autowired
    private ActualBookRepo actualBookRepo;

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private RoomsRepository roomsRepository;

    @Autowired
    private GuestRepository guestRepository;


    @Override
    public ActualBooking addRecord(ActualBooking actualBooking , HttpServletRequest request) {
        try{
            String authToken = request.getHeader("Authorization");
            String token = null ;
            if(authToken != null && authToken.startsWith("Bearer ")){
                token = authToken.substring(7);
            }
            JwtUtil jwt = new JwtUtil();
           long id =  jwt.extractUserId(token);
           actualBooking.setUserId(id);

            List<Guest> guest = new ArrayList<>();
            for(Guest guestt : actualBooking.getGuest()){
                guestt.setActualBooking(actualBooking);
                guest.add(guestt);
            }
            actualBooking.setGuest(guest);


            Hotel hotel = hotelRepository.findById(actualBooking.getHotelId())
                    .orElseThrow(()-> new RuntimeException("Hotel Id not Found !! "));
            actualBooking.setHotelName(hotel.getHotelName());
            actualBooking.setHotelAddress(hotel.getHotelAdd());
            List<Rooms> rooms = roomsRepository.findRoomsByHotelId(actualBooking.getHotelId());
            for(Rooms room : rooms){
                if(actualBooking.getRoomType().trim().equalsIgnoreCase(room.getRoomType())){
                    actualBooking.setRoomId(room.getRoomId());
                    actualBooking.setTotalPrice(room.getRoomBasePrice() * actualBooking.getNumberOfAdults());
                    actualBooking.setAvailableRooms(room.getNumberOfRooms());

                    if (actualBooking.getPaymentMethod().trim().equalsIgnoreCase("Upi")) {
                        actualBooking.setPaymentStatus("Done");
                        actualBooking.setStatus(BookingStatus.BOOKED);// Set status to Booked
                        Rooms rooms1 = roomsRepository.findById(room.getRoomId()).orElseThrow(()-> new RuntimeException("room not found ! "));
                        rooms1.setNumberOfRooms(rooms1.getNumberOfRooms()- actualBooking.getRoomsNeeded());
                        hotel.setHotelRooms(hotel.getHotelRooms()-actualBooking.getRoomsNeeded());
                    } else {
                        actualBooking.setPaymentStatus("Pending");
                        actualBooking.setStatus(BookingStatus.PENDING);  // Set status to Pending
                    }
                }
            }

            return actualBookRepo.save(actualBooking);
        }catch (Exception e){
            throw new RuntimeException("Record not saved !! " + e.getMessage());
        }
    }

@Override
public SearchDto<ActualBooking> getAllRecords(int page, int size, String sortBy, String sortDirection, Long userId, String city, LocalDate checkInDate, LocalDate checkOutDate) {
    try {

        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "BookingId"; // Default sorting field
        }
        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc"; // Default sorting direction
        }

        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);


        Page<ActualBooking> actualBookings = actualBookRepo.searchBookings(userId, city, checkInDate, checkOutDate, pageable);
        long totalActualBooking = actualBookRepo.count();
        return new SearchDto<>(actualBookings.getContent(), totalActualBooking, page, size);
    } catch (Exception e) {
        throw new ResourceNotFoundException("Records Not Found!!");
    }
}



    public List<Guest> getGuestByBookingId(int id) {
        try {
            return actualBookRepo. findGuestsByBookingId(id);
        }catch(Exception e ){
            throw new ResourceNotFoundException("List Was Not Found ");
        }
    }

    @Override
    public ActualBooking cancelBooking(int bookingId, String cancelReason) {
        try {
            ActualBooking actualBooking = actualBookRepo.findById(bookingId)
                    .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id " + bookingId));

            // Set the status and cancel reason
            actualBooking.setStatus(BookingStatus.CANCELLED);
            actualBooking.setCancelReason(cancelReason);  // Save the cancel reason

            return actualBookRepo.save(actualBooking);
        } catch (Exception e) {
            throw new RuntimeException("Error canceling booking: " + e.getMessage());
        }
    }
    @Override
    public List<ActualBooking> getBookingHistoryByUserId(long userId) {
        try {

            return actualBookRepo.findByUserId(userId);
        } catch (Exception e) {
            throw new ResourceNotFoundException("No bookings found for user with id " + userId);
        }
    }

    @Override
    public ActualBooking checkInBooking(int bookingId) {
        try {
            ActualBooking actualBooking = actualBookRepo.findById(bookingId)
                    .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id " + bookingId));

            if (actualBooking.getCheckInStatus()== CheckInStatus.CHECKED_IN || actualBooking.getStatus()==BookingStatus.CANCELLED) {
                throw new RuntimeException("Booking cannot be checked in as it is already checked in or cancelled");
            }
            actualBooking.setCheckInStatus(CheckInStatus.CHECKED_IN);

            return actualBookRepo.save(actualBooking);
        } catch (Exception e) {
            throw new RuntimeException("Error checking in booking " + e.getMessage());
        }
    }

    @Override
    public ActualBooking checkOutBooking(int bookingId) {
        try {
            ActualBooking actualBooking = actualBookRepo.findById(bookingId)
                    .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id " + bookingId));

            if (actualBooking.getCheckInStatus() == CheckInStatus.CHECKED_OUT || actualBooking.getStatus() == BookingStatus.CANCELLED) {
                throw new RuntimeException("Booking cannot be checked out as it is already checked out or cancelled.");
            }

            actualBooking.setCheckInStatus(CheckInStatus.CHECKED_OUT);

            return actualBookRepo.save(actualBooking);
        } catch (Exception e) {
            throw new RuntimeException("Error checking out booking: " + e.getMessage());
        }
    }
}






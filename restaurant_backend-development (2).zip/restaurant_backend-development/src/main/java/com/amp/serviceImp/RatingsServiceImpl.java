package com.amp.serviceImp;

import com.amp.entity.ActualBooking;
import com.amp.entity.Ratings;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.ActualBookRepo;
import com.amp.repository.RatingsRepo;
import com.amp.service.RatingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatingsServiceImpl implements RatingsService {

    @Autowired
    private RatingsRepo ratingsRepo;

    @Autowired
    private ActualBookRepo actualBookRepo;

    @Override
    public Ratings addRating(Ratings ratings) {
      ActualBooking actualBooking = actualBookRepo.findById(ratings.getBookingId()).orElseThrow(()-> new RuntimeException("Booking Id not Found !! "));
      ratings.setHotelId(actualBooking.getHotelId());
      ratings.setUserId(actualBooking.getUserId());
      return ratingsRepo.save(ratings);
    }

    @Override
    public List<Ratings> getAll(int page, int size) {
        try {
            Pageable pageable = PageRequest.of(page,size);
            Page<Ratings> ratings = ratingsRepo.findAll(pageable);
            return ratings.getContent();
        }catch(Exception e ){
            throw new ResourceNotFoundException(" Records Not Found !!" + e.getMessage());
        }
    }

    @Override
    public List<Ratings> findByHotelId(int id){
        try{
            return ratingsRepo.findByHotelId(id);
        }catch(Exception e){
            throw new ResourceNotFoundException("List Was Not Found !! " + e.getMessage()) ;
        }
    }
}

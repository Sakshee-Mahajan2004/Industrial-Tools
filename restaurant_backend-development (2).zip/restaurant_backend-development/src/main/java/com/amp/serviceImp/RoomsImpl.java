package com.amp.serviceImp;

import com.amp.dto.SearchDto;
import com.amp.entity.Hotel;
import com.amp.entity.Rooms;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.HotelRepository;
import com.amp.repository.RoomsRepository;
import com.amp.service.RoomsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomsImpl implements RoomsService {
    @Autowired
    private RoomsRepository roomsRepository;

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public Rooms addRoom(Rooms rooms) {
        Hotel hotel = hotelRepository.findById(rooms.getHotel().getHotelId()).
                orElseThrow(()-> new ResourceNotFoundException("Hotel Not Found !! "));
        if(rooms.getNumberOfRooms() > hotel.getHotelRooms()){
            throw new RuntimeException("Rooms size exceeded than hotel Rooms ");
        }
        rooms.setHotel(hotel);
        return roomsRepository.save(rooms);
    }

@Override
public SearchDto<Rooms> getAllRooms(int page, int size, String sortBy, String sortDirection, String roomType, Integer hotelId, Integer minRoomBasePrice, Integer maxRoomBasePrice) {
    try {

        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "roomId";  // Default sorting field
        }
        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc";  // Default sorting direction
        }

        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);


        Page<Rooms> rooms = roomsRepository.searchRooms(roomType, hotelId, minRoomBasePrice, maxRoomBasePrice, pageable);
        long totalRooms = roomsRepository.count();
        return new SearchDto<>(rooms.getContent(), totalRooms, page, size);
    } catch (Exception e) {
        throw new RuntimeException("Error fetching rooms: " + e.getMessage());
    }
}


    @Override
    public boolean deleteRoomsById(int id) {
        try{
            roomsRepository.deleteById(id);
        }catch(Exception e ){
            throw new RuntimeException("Id not Found !");
        }
         return true;
    }

    @Override
    public Rooms updateRoomsById(int id, int roomNumber, String roomType) {
         try{
             Rooms room = roomsRepository.findById(id).
                     orElseThrow(()-> new RuntimeException(
                             "Room With Id " + id + " Not Found"));
             room.setRoomType(roomType);
            return roomsRepository.save(room);

         }catch(Exception e ){
             throw new RuntimeException("Room Updation Failed !! ");
         }
    }
    @Override
    public List<Rooms> getRoomsByHotelId(int hotelId) {
        try {
            return roomsRepository.findRoomsByHotelId(hotelId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching rooms for hotel with ID " + hotelId, e);
        }
    }
    @Override
    public Boolean deleteRoomsByHotelId(int hotelId) {
        try {

            List<Rooms> rooms = roomsRepository.findRoomsByHotelId(hotelId);
            if (rooms.isEmpty()) {
                throw new RuntimeException("No rooms found for hotel with ID " + hotelId);
            }
            roomsRepository.deleteAll(rooms);
            return true;
        } catch (Exception e) {
            throw new RuntimeException("Error deleting rooms for hotel with ID " + hotelId, e);
        }
    }

}

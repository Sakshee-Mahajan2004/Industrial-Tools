package com.amp.serviceImp;

import com.amp.dto.LoginRequest;

import com.amp.dto.JwtLoginResponse;
import com.amp.entity.User;
import com.amp.repository.UserRepository;
import com.amp.service.LoginService;
import com.amp.utilis.jwt.JwtUtil;
import com.sun.jdi.request.InvalidRequestStateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public JwtLoginResponse login(LoginRequest loginRequest) {
        Optional<User> user = userRepository.findByEmail(loginRequest.getEmail());
//        System.out.println(user);
        if (user.isEmpty()) {
            throw new InvalidRequestStateException("user not found");}
        User user1 =user.get();
        if (!passwordEncoder.matches(loginRequest.getPassword(), user1.getPassword())) {
            throw new InvalidRequestStateException("Invalid password");
        }
        // jwt token
//        String token = jwtUtil.generateToken(user1.getEmail());
//        user1.setPassword(token);
        JwtLoginResponse loginResponse = new JwtLoginResponse(

                user.get().getUserId(),
                user.get().getFirstName(),
                user.get().getLastName(),
                user.get().getEmail(),
                user.get().getMobile(),
                user.get().getRole(),
                jwtUtil.generateToken(user.get().getEmail(),user.get().getUserId())
        );
        return loginResponse;
    }
}

package com.amp.serviceImp;

import com.amp.entity.ActualBooking;
import com.amp.entity.Guest;
import com.amp.repository.GuestRepository;
import com.amp.service.GuestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GuestServiceImpl implements GuestService {

    @Autowired
    private GuestRepository guestRepository;

    // Create a new Guest
    @Override
    public Guest createGuest(Guest guest) {

        return guestRepository.save(guest); // Save the guest to the database
    }

    // Get Guest by ID
    @Override
    public Guest getGuestById(int guestId) {
        Optional<Guest> guestOptional = guestRepository.findById(guestId);
        return guestOptional.orElse(null); // Return the guest if found, otherwise null
    }

    // Get All Guests
    @Override
    public List<Guest> getAllGuests() {
        return guestRepository.findAll(); // Retrieve all guests from the database
    }

    // Update Guest by ID
    @Override
    public Guest updateGuest(int guestId, Guest guest) {
        Optional<Guest> guestOptional = guestRepository.findById(guestId);
        if (guestOptional.isPresent()) {
            Guest existingGuest = guestOptional.get();
            // Update the fields of the existing guest
            existingGuest.setFirstName(guest.getFirstName());
            existingGuest.setLastName(guest.getLastName());
            existingGuest.setGender(guest.getGender());
            existingGuest.setNationality(guest.getNationality());
            existingGuest.setPhoneNumber(guest.getPhoneNumber());
            existingGuest.setGovIdType(guest.getGovIdType());
            existingGuest.setGovIdNumber(guest.getGovIdNumber());
            return guestRepository.save(existingGuest); // Save the updated guest
        } else {
            return null; // Return null if the guest is not found
        }
    }

    // Delete Guest by ID
    @Override
    public boolean deleteGuest(int guestId) {
        Optional<Guest> guestOptional = guestRepository.findById(guestId);
        if (guestOptional.isPresent()) {
            guestRepository.deleteById(guestId);
            return true;
        } else {
            return false;
        }
    }
}
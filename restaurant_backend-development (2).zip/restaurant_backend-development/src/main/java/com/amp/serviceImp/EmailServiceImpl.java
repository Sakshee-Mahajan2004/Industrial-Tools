package com.amp.serviceImp;


import com.amp.dto.MailBody;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl {

   @Autowired
   private JavaMailSender javaMailSender;

    public void sendSimpleMessage(MailBody mailBody) {
        try {
            String senderName = " Prakriti Stay ";
            MimeMessage message = javaMailSender.createMimeMessage();

            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(mailBody.to());
            helper.setSubject(mailBody.subject());
            helper.setText((mailBody.text()), true);
            helper.setFrom(new InternetAddress("abhishekkmishra0901@gmail.com",senderName));

            javaMailSender.send(message);
            System.out.println("Email sent successfully!");

        } catch (Exception e) {
           System.out.println(e.getMessage());
           e.printStackTrace();
        }
    }



}

package com.amp.serviceImp;

import com.amp.dto.SearchDto;
import com.amp.entity.Hotel;
import com.amp.entity.TemporaryBooking;
import com.amp.entity.User;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.HotelRepository;
import com.amp.repository.TempBookingRepo;
import com.amp.repository.UserRepository;
import com.amp.service.TempBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;

@Service
public class TempBookServiceImpl implements TempBookService {

    @Autowired
    private TempBookingRepo tempBookingRepo;

    @Autowired
    private UserRepository userRepository ;

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public TemporaryBooking addRecord(TemporaryBooking temporaryBooking) {
        try{
            User user = userRepository.findById(temporaryBooking.getUser().getUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            temporaryBooking.setUser(user);

            Hotel hotel = hotelRepository.findById(temporaryBooking.getHotel().getHotelId()).
                    orElseThrow(()->new RuntimeException("Hotel was not Found !!"));
            temporaryBooking.setHotel(hotel);
            Date currentDate = new Date(System.currentTimeMillis());
            temporaryBooking.setInquiryDate(currentDate); //setting the inquiry date to current date
            return tempBookingRepo.save(temporaryBooking);
        }catch(Exception e ){
            throw new RuntimeException("Record Was Not saved !!" + e.getMessage());
        }
    }


@Override
public SearchDto<TemporaryBooking> getTempRecords(int page, int size, String sortBy, String sortDirection,
                                                  String city, Integer minAdults, Integer maxAdults,
                                                  LocalDate checkInDateStart, LocalDate checkInDateEnd) {
    try {

        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "id";  // Default sorting field (e.g., id)
        }
        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc";  // Default sorting direction
        }

        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<TemporaryBooking> tempBookings = tempBookingRepo.searchTemporaryBookings(
                city, minAdults, maxAdults, checkInDateStart, checkInDateEnd, pageable);

        long totalRecords = tempBookingRepo.count();
        return new SearchDto<>(tempBookings.getContent(), totalRecords, page, size);
    } catch (Exception e) {
        throw new RuntimeException("Records Was Not Found !! " + e.getMessage());
    }
}
    @Override
    public boolean deleteRecord(int id) {
        try{
            hotelRepository.deleteById(id);
            return true;
        }catch (Exception e){
            throw new ResourceNotFoundException("Record with Id " + id + "Not Found " + e.getMessage());
        }
    }

}
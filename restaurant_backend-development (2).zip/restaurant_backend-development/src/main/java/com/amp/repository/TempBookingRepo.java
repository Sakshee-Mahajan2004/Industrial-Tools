package com.amp.repository;

import com.amp.entity.TemporaryBooking;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface TempBookingRepo extends JpaRepository<TemporaryBooking , Integer> {

    @Query("SELECT t FROM TemporaryBooking t WHERE " +
            "(:city IS NULL OR t.city LIKE %:city%) AND " +
            "(:minAdults IS NULL OR t.numberOfAdults >= :minAdults) AND " +
            "(:maxAdults IS NULL OR t.numberOfAdults <= :maxAdults) AND " +
            "(:checkInDateStart IS NULL OR t.checkInDate >= :checkInDateStart) AND " +
            "(:checkInDateEnd IS NULL OR t.checkInDate <= :checkInDateEnd)")
    Page<TemporaryBooking> searchTemporaryBookings(@Param("city") String city,
                                                   @Param("minAdults") Integer minAdults,
                                                   @Param("maxAdults") Integer maxAdults,
                                                   @Param("checkInDateStart") LocalDate checkInDateStart,
                                                   @Param("checkInDateEnd") LocalDate checkInDateEnd,
                                                   Pageable pageable);


}
package com.amp.repository;

import com.amp.entity.ActualBooking;
import com.amp.entity.Guest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ActualBookRepo extends JpaRepository<ActualBooking,Integer> {

    @Query("SELECT ab FROM ActualBooking ab WHERE ab.userId = :userId")
    List<ActualBooking> findByUserId(@Param("userId") long userId);

    @Query("SELECT g FROM Guest g WHERE g.actualBooking.BookingId = :bookingId")
    List<Guest> findGuestsByBookingId(@Param("bookingId") int bookingId);

@Query("SELECT ab FROM ActualBooking ab WHERE " +
        "(:userId IS NULL OR ab.userId = :userId) AND " +
        "(:city IS NULL OR ab.city LIKE %:city%) AND " +
        "(:checkInDate IS NULL OR ab.checkInDate >= :checkInDate) AND " +
        "(:checkOutDate IS NULL OR ab.checkOutDate <= :checkOutDate)")
Page<ActualBooking> searchBookings(@Param("userId") Long userId,
                                   @Param("city") String city,
                                   @Param("checkInDate") LocalDate checkInDate,
                                   @Param("checkOutDate") LocalDate checkOutDate,
                                   Pageable pageable);

    long count();

}

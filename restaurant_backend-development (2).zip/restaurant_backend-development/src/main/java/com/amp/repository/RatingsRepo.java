package com.amp.repository;

import com.amp.entity.Ratings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RatingsRepo extends JpaRepository<Ratings,Integer> {
    List<Ratings> findByHotelId(int id);
}

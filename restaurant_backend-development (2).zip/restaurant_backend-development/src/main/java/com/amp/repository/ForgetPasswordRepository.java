package com.amp.repository;

import com.amp.entity.ForgotPassword;
import com.amp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ForgetPasswordRepository extends JpaRepository<ForgotPassword,Integer> {
     Optional<ForgotPassword> findByOtp(Integer otp);

}

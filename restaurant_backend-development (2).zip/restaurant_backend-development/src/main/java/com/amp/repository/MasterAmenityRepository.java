package com.amp.repository;

import com.amp.entity.MasterAmenity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterAmenityRepository extends JpaRepository<MasterAmenity, Integer> {
    Page<MasterAmenity> findByAmenityNameContainingIgnoreCase(String keyword, Pageable pageable);

}

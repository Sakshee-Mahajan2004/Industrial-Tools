package com.amp.controller;

import com.amp.dto.SearchDto;
import com.amp.entity.Hotel;
import com.amp.dto.ApiResponse;
import com.amp.service.HotelService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RequestMapping("/api/hotel")
@RestController
@CrossOrigin(origins = "*")
@Tag(name = "Hotel API", description = "All API related to Hotel")
//@Operation(summary = "get Amenities By Id", description = "Get All Amenities by hotel id")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    // Save Hotel Information
    @PostMapping("/save")
    public ApiResponse<Hotel> saveHotel(@Valid @RequestBody Hotel hotel) {
        try {
            Hotel savedHotel = hotelService.saveHotelInfo(hotel);
            return new ApiResponse<>(HttpStatus.OK.value(), "Hotel saved successfully", savedHotel);
        } catch (RuntimeException e) {
            // Check for specific message and return bad request
            if (e.getMessage().contains("This hotel owner is already associated with another hotel")) {
                return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), e.getMessage(), null);
            }
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to save hotel", null);
        }
    }


    // Get Hotel by ID with Amenities
    @GetMapping("/get/{id}")
    public ApiResponse<Hotel> findHotelById(@PathVariable int id) {
        try {
            Hotel hotel = hotelService.findHotelById(id);
            return new ApiResponse<>(HttpStatus.OK.value(), "Hotel found", hotel);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Hotel not found", null);
        }
    }

    // Get All Hotels with Amenities
@GetMapping("/getAll")
public ApiResponse<SearchDto<Hotel>> findAll(
        @RequestParam int page,
        @RequestParam int size,
        @RequestParam(required = false, defaultValue = "") String sortBy,
        @RequestParam(required = false, defaultValue = "") String sortDirection,
        @RequestParam(required = false, defaultValue = "0") int roomsNeeded,
        @RequestParam(required = false, defaultValue = "") String city) {
    try {
        // Call the service method with the received parameters
        SearchDto<Hotel> response = hotelService.getAll(page, size, sortBy, sortDirection, roomsNeeded, city);

        // Check if the response data is empty
        if (response.getData().isEmpty()) {
            return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "No hotels found", null);
        }
        return new ApiResponse<>(HttpStatus.OK.value(), "Hotels found", response);
    } catch (Exception e) {
        return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error retrieving hotels", null);
    }
}

    @PutMapping("/update/{id}")
    public ApiResponse<Hotel> updateHotel(@Valid @PathVariable int id, @RequestBody Hotel hotel) {
        try {
            Hotel updatedHotel = hotelService.updateHotel(id, hotel);
            return new ApiResponse<>(HttpStatus.OK.value(), "Hotel updated successfully", updatedHotel);
        } catch (RuntimeException e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), e.getMessage(), null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error occurred while updating the hotel", null);
        }
    }
    @DeleteMapping("/delete/{id}")
    public ApiResponse<Void> deleteHotel(@PathVariable int id) {
        try {
            boolean isDeleted = hotelService.deleteHotel(id);
            if (isDeleted) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "Hotel deleted successfully", null);
            } else {
                return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Hotel not found", null);
            }
        } catch (RuntimeException e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), e.getMessage(), null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error deleting hotel", null);
        }
    }
    @GetMapping("/byUserId")
    public ApiResponse<List<Hotel>> getHotelsByUserId(@RequestParam long userId) {
        List<Hotel> hotels = hotelService.findHotelsByUserId(userId);
        return new ApiResponse<>(HttpStatus.FOUND.value(), "Hotels fetched successfully", hotels);
    }

    @GetMapping("/hotelRooms")
    public ApiResponse<Hotel> roomsUpdate(@RequestParam int bookingId){
        return new ApiResponse<>(HttpStatus.OK.value(),"Rooms Were Updated ",hotelService.checkout(bookingId));
    }

    @GetMapping("/hotelCity")
    public ApiResponse<List<Hotel>> findHotelByCity(@RequestParam String city , @RequestParam int hotelRooms ){
        return new ApiResponse<>(HttpStatus.OK.value(),"Hotels Were Fetched ",hotelService.findByCityEqualsIgnoreCase(city , hotelRooms));
    }

   @GetMapping("/hotelLocation")
    public ApiResponse<Set<String>> getAllLocation(){
        return new ApiResponse<>(HttpStatus.OK.value(),"All Hotel Location Were Fetched" , hotelService.getAllHotelLocation());
   }
}

package com.amp.controller;

import com.amp.dto.ApiResponse;
import com.amp.entity.Ratings;
import com.amp.service.RatingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ratings")
public class RatingsController {

    @Autowired
    private RatingsService ratingsService;

    @PostMapping("/addRating")
    public ApiResponse<Ratings> addRating(@RequestBody Ratings ratings){
        return new ApiResponse<>(HttpStatus.ACCEPTED.value(),
                "Ratings Added ",ratingsService.addRating(ratings));
    }

    @GetMapping("/getAll")
    public ApiResponse<List<Ratings>> getAll(int page , int size){
        return new ApiResponse<>(HttpStatus.FOUND.value(),
                "Ratings Fetched ",ratingsService.getAll(page,size));
    }

    @GetMapping("/Hotel")
    public List<Ratings> getByHotel(@RequestParam int id ){
        return ratingsService.findByHotelId(id);
    }

}
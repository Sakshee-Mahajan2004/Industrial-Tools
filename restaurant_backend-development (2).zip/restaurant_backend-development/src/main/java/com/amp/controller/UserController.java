package com.amp.controller;


import com.amp.dto.*;

import com.amp.entity.ForgotPassword;
import com.amp.entity.Role;
import com.amp.entity.User;
import com.amp.repository.ForgetPasswordRepository;
import com.amp.repository.RoleRepository;
import com.amp.repository.UserRepository;
import com.amp.serviceImp.EmailServiceImpl;
import com.amp.service.LoginService;
import com.amp.service.UserService;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.validation.Valid;
import org.springdoc.core.annotations.ParameterObject;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;
import java.util.Random;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private LoginService loginService;
    @Autowired
    AuthenticationManager authenticationManager;


    @Autowired
    private EmailServiceImpl emailService;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    PasswordEncoder passwordEncoder;


    @Autowired
    private ForgetPasswordRepository forgetPasswordRepository;
    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ApiResponse<User> registerUser(@Valid @RequestBody User user) {
        try {

            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {
                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {
               throw new BadRequestException("Mobile number already in use");
            }
            Role role=new Role();
             role.setRoleId(1000);
             user.setRole(role);
               User registeredUser = userService.registerUser(user);
               return new ApiResponse<>(HttpStatus.OK.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {

            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register User", null);
//            throw new RuntimeException(e.getMessage());
        }

    }
    @PostMapping("/Owner/register")
    public ApiResponse<User> registerOwner(@Valid @RequestBody User user) {
        try {
            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {

                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {

                throw new BadRequestException("Mobile number already in use");
            }
            Role role=new Role();
            role.setRoleId(1002);
            user.setRole(role);
            User registeredUser = userService.registerOwner(user);
            return new ApiResponse<>(HttpStatus.OK.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register Hotel Owner", null);
//            throw new RuntimeException(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ApiResponse<JwtLoginResponse> login(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail().toLowerCase();
        loginRequest.setEmail(email);

        JwtLoginResponse loginResponse = loginService.login(loginRequest);
        return new ApiResponse<>(HttpStatus.OK.value(), "Login Success", loginResponse);
    }

@GetMapping("/allUsers")
public ApiResponse<SearchDto<User>> findAllUsers(@RequestParam int page, @RequestParam int size,
                                                 @RequestParam(required = false, defaultValue = "") String sortBy,
                                                 @RequestParam(required = false, defaultValue = "") String sortDirection,
                                                 @RequestParam(required = false, defaultValue = "") String searchTerm) {
    SearchDto<User> response = userService.findAllUsers(page, size, sortBy, sortDirection, searchTerm);

    if (response.getData().isEmpty()) {
        return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "No users found", response);
    }

    return new ApiResponse<>(HttpStatus.OK.value(), "Users found", response);
}



    @GetMapping("/users/{id}")
    public User getUserById(@PathVariable long id) {
        return userService.findUserById(id);
    }

    @DeleteMapping("/usersDelete/{id}")
    public ApiResponse<String> deleteUserById(@PathVariable Long id) {
        userService.deleteUserById(id);

        return new ApiResponse<>(HttpStatus.OK.value(), "User deleted successfully", null);
    }

    @PutMapping("updateUser/{id}")
    public ApiResponse<User> updateUser(@Valid @PathVariable Long id, @RequestBody User userDetails) {
        try {
            User updatedUser = userService.updateUser(id, userDetails);
            return new ApiResponse<>(HttpStatus.ACCEPTED.value(), "User updated successfully", updatedUser);
//        } catch (Exception e) {
//           throw new RuntimeException(e.getMessage());
//            return new ApiResponse<>(HttpStatus.ACCEPTED.value(), "User updated successfully", updatedUser);
        } catch (RuntimeException e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "User not found", null);
        }
    }


    @PostMapping("verifyEmail/{email}")
    public ApiResponse<String> verifyEmail(@PathVariable String email) {
      User user=  userRepository.findByEmail(email).orElseThrow(()->new RuntimeException("Email not found"));

      int otp=otpGenerator();
        MailBody mailBody=MailBody.builder().to(email).text(("<html>"
                        + "<body>"
                        + "<p>Dear "+user.getFirstName()+" "+user.getLastName()+", </p>"
                        + "<p>We received a request to reset your password. Please use the following One-Time Password (OTP) to proceed:</p>"
                        + "<p><strong>OTP: " + otp + "</strong></p>"
                        + "<p>If you did not request this, please ignore this email.</p>"
                        + "<p>Best Regards,<br/>The Prakriti Stay Team</p>"
                        + "</body>"
                        + "</html>"))
                .subject("Password Reset Request – Prakriti Stay OTP").build();
        ForgotPassword fp=ForgotPassword.builder().otp(otp).expirationTime(new Date(System.currentTimeMillis()+120*1000)).user(user).build();
        emailService.sendSimpleMessage(mailBody);
        forgetPasswordRepository.save(fp);
        return new ApiResponse<>(HttpStatus.OK.value(), "OTP has been sent to your mail", email);
    }

    @PostMapping("verifyOtp/{otp}/{email}")
    public ApiResponse<String> verifyOtp(@PathVariable Integer otp,@PathVariable String email) {
        userRepository.findByEmail(email).orElseThrow(()->new RuntimeException("Email not found"));
        ForgotPassword fp=forgetPasswordRepository.findByOtp(otp).orElseThrow(()->new RuntimeException("Invalid OTP"));
        if(fp.getExpirationTime().before(Date.from(Instant.now())))
        {
            forgetPasswordRepository.deleteById(fp.getId());

            try {
                throw new BadRequestException("OTP Expired!!");
            } catch (BadRequestException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return new ApiResponse<>(HttpStatus.OK.value(), "Verified Email", email);
    }

    @PostMapping("/changePassword/{email}")
    public ApiResponse<String> changePasswordHandler(@RequestBody ChangePassword changePassword, @PathVariable String email) {
        if(!Objects.equals(changePassword.password(),changePassword.confirmPassword())) {
            try {
                throw new BadRequestException("Password and Confirm Password must be Same");
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }


        try {

            String encodedPassword=passwordEncoder.encode(changePassword.password());

                userRepository.updatePassword(email, encodedPassword);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return new ApiResponse<>(HttpStatus.OK.value(), "Password changed successfully", email);
      }
//        String encodedPassword=passwordEncoder.encode(changePassword.password());
//        userRepository.updatePassword(email,encodedPassword);
//        return new ApiResponse<>(HttpStatus.OK.value(), "Password changed successfully", email);
//    }


    private Integer otpGenerator(){
        Random random=new Random();
        return random.nextInt(100000 ,999999);
    }

}








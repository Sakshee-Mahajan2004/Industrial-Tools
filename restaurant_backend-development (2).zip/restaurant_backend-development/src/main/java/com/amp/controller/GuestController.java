package com.amp.controller;

import com.amp.dto.ApiResponse;
import com.amp.entity.Guest;
import com.amp.service.GuestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/api/Guest/")
@CrossOrigin(origins = "*")
@RestController
public class GuestController {

    @Autowired
    private GuestService guestService;

    // Create a new Guest
    @PostMapping("/create")
    public ApiResponse<Guest> createGuest(@RequestBody Guest guest) {
        try {
            Guest createdGuest = guestService.createGuest(guest);
            return new ApiResponse<>(HttpStatus.CREATED.value(), "Guest created successfully with ID: " + createdGuest.getGuestId(), createdGuest);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to create guest: " + e.getMessage(), null);
        }
    }

    // Get Guest by ID
    @GetMapping("/{guestId}")
    public ApiResponse<Guest> getGuestById(@PathVariable int guestId) {
        try {
            Guest guest = guestService.getGuestById(guestId);
            if (guest != null) {
                return new ApiResponse<>(HttpStatus.OK.value(), "Guest retrieved successfully", guest);
            } else {
                return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Guest not found with ID: " + guestId, null);
            }
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to retrieve guest: " + e.getMessage(), null);
        }
    }

    // Get All Guests
    @GetMapping("/all")
    public ApiResponse<List<Guest>> getAllGuests() {
        try {
            List<Guest> guests = guestService.getAllGuests();
            if (!guests.isEmpty()) {
                return new ApiResponse<>(HttpStatus.OK.value(), "Guests retrieved successfully", guests);
            } else {
                return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "No guests found", null);
            }
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to retrieve guests: " + e.getMessage(), null);
        }
    }

    // Update Guest by ID
    @PutMapping("/update/{guestId}")
    public ApiResponse<Guest> updateGuest(@PathVariable int guestId, @RequestBody Guest guest) {
        try {
            Guest updatedGuest = guestService.updateGuest(guestId, guest);
            if (updatedGuest != null) {
                return new ApiResponse<>(HttpStatus.OK.value(), "Guest updated successfully with ID: " + updatedGuest.getGuestId(), updatedGuest);
            } else {
                return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Guest not found with ID: " + guestId, null);
            }
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to update guest: " + e.getMessage(), null);
        }
    }

    // Delete Guest by ID
    @DeleteMapping("/delete/{guestId}")
    public ApiResponse<String> deleteGuest(@PathVariable int guestId) {
        try {
            boolean isDeleted = guestService.deleteGuest(guestId);
            if (isDeleted) {
                return new ApiResponse<>(HttpStatus.OK.value(), "Guest deleted successfully with ID: " + guestId, null);
            } else {
                return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Guest not found with ID: " + guestId, null);
            }
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to delete guest: " + e.getMessage(), null);
        }
    }
}
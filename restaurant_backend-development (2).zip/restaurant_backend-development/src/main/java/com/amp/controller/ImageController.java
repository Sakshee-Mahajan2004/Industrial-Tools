package com.amp.controller;
import com.amp.dto.ApiResponse;
import com.amp.entity.Hotel;
import com.amp.entity.Images;
import com.amp.entity.Rooms;
import com.amp.repository.HotelRepository;
import com.amp.repository.ImageRepository;
import com.amp.repository.RoomsRepository;
import com.amp.service.ImageService;
import jakarta.validation.Valid;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/images")
public class ImageController {


  @Autowired
  private HotelRepository hotelRepository;

  @Autowired
  private ImageService imageService;

  @Autowired
  private RoomsRepository roomsRepository;

  @Autowired
  private ImageRepository imageRepository;

    @PostMapping("/upload")
    public ApiResponse<Images> uploadImage(@Valid
                                              @RequestParam("imageFile") MultipartFile imageFile,
                                           @RequestParam(value = "hotelId", required = false) Integer hotelId,
                                           @RequestParam(value = "roomId", required = false) Integer roomId) {
        try {

            Hotel hotel = null;
            Rooms room = null;

            if (hotelId != null) {
                hotel = hotelRepository.findById(hotelId)
                        .orElseThrow(() -> new IllegalArgumentException("Hotel not found with ID " + hotelId));
            }

            if (roomId != null) {
                room = roomsRepository.findById(roomId)
                        .orElseThrow(() -> new IllegalArgumentException("Room not found with ID " + roomId));
            }

            System.out.println("Hotel id:: "+hotelId);
            System.out.println("Room id::"+roomId);

            Images savedImage = imageService.saveImage(imageFile, hotel, room);

            return new ApiResponse<>(HttpStatus.OK.value(),"Image Saved Successfully",savedImage);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Failed to save image",null);
        }
    }

    @GetMapping("/getImageById/{imageId}")
    public ResponseEntity<UrlResource> getImage(@PathVariable int imageId) throws Exception {
        try {
            Images image = imageService.getImageById(imageId);

            if (image == null) {
                return ResponseEntity.notFound().build();
            }

            String imageUrl = image.getImageUrl();

            Path path = Paths.get( imageUrl);
            UrlResource resource = new UrlResource(path.toUri());

            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .body(resource);

        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    @GetMapping("/getImages")
    public ResponseEntity<UrlResource>  getImages(
            @RequestParam(value = "hotel_id", required = false) Integer hotelId,
            @RequestParam(value = "room_id", required = false) Integer roomId,
            @RequestParam(value = "imageName") String imageName) {

        if (imageName == null || imageName.trim().isEmpty()) {
//            return ResponseEntity.badRequest().body(null);
            try {
                throw new BadRequestException();
            } catch (BadRequestException e) {
                throw new RuntimeException(e);
            }
        }

        try {

            if(hotelId!=null && roomId!=null)
            {
                String imagePath = "src/main/resources/static/image/room/" + imageName;
                Path path = Paths.get(imagePath);

                UrlResource resource = new UrlResource(path.toUri());

                if (!resource.exists() || !resource.isReadable()) {
                    throw new FileNotFoundException("File not found: " + imageName);
                }

                return ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_JPEG)
                        .body(resource);
            }
            if (hotelId != null && roomId==null) {
                String imagePath = "src/main/resources/static/image/hotel/" + imageName;
                Path path = Paths.get(imagePath);

                UrlResource resource = new UrlResource(path.toUri());

                if (!resource.exists() || !resource.isReadable()) {
                    throw new FileNotFoundException("File not found: " + imageName);
                }

                return ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_JPEG)
                        .body(resource);
            }
                if (roomId != null && hotelId==null) {
                    String imagePath = "src/main/resources/static/image/room/" + imageName;
                    Path path = Paths.get(imagePath);

                    UrlResource resource = new UrlResource(path.toUri());

                    if (!resource.exists() || !resource.isReadable()) {
                        throw new FileNotFoundException("File not found: " + imageName);
                    }

                    return ResponseEntity.ok()
                            .contentType(MediaType.IMAGE_JPEG)
                            .body(resource);

                }
                return ResponseEntity.notFound().build();

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(null);
        }
    }



    private String getImagePath(Integer hotelId, Integer roomId, String imageName) {

        if (hotelId != null) {
            return "image/hotel/" + hotelId + "/" + imageName;
        } else if (roomId != null) {
            return "image/room/" + roomId + "/" + imageName;
        }
        return null;
    }

    @GetMapping("/getImagesByHotelAndRoom")
    public ApiResponse<List<Images>> getImagesByHotelAndRoom(
            @RequestParam(value = "hotelId", required = false) Integer hotelId,
            @RequestParam(value = "roomId", required = false) Integer roomId) {
        try {

            List<Images> images = imageService.getImagesByHotelAndRoom(hotelId, roomId);

            return new ApiResponse<>(HttpStatus.OK.value(), "Images fetched successfully", images);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to fetch images", null);
        }

    }


    @DeleteMapping("/deleteImage/{id}")
    public ApiResponse<Images> deleteImage(@PathVariable int id) {

        Optional<Images> image = imageRepository.findById(id);

        if (!image.isPresent()) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Image not found", null);
        }

        Images images = image.get();

        Path filePath1 = Path.of(images.getImageUrl());
        Path filePath2 = Path.of(images.getImageUrl());

        try {
            if (Files.exists(filePath1)) {
                Files.delete(filePath1);
            }
            if (Files.exists(filePath2)) {
                Files.delete(filePath2);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to delete image files: " + e.getMessage());
        }

        imageService.deleteImageById(id);
        return new ApiResponse<>(HttpStatus.OK.value(), "Image deleted successfully!", null);
    }

}




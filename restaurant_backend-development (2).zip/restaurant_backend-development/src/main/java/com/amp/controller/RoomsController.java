package com.amp.controller;

import com.amp.dto.SearchDto;
import com.amp.entity.Rooms;
import com.amp.dto.ApiResponse;
import com.amp.service.RoomsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class RoomsController {
    private ApiResponse apiResponse;

    @Autowired
    private RoomsService roomsService;

    @PostMapping("/addRoom")
    public ApiResponse<Rooms> addRoom(@RequestBody Rooms rooms){
        return new ApiResponse<>(HttpStatus.ACCEPTED.value() ,
                " Room Was Added Successfully " , roomsService.addRoom(rooms));
    }

@GetMapping("/getRooms")
public ApiResponse<SearchDto<Rooms>> getAllRooms(@RequestParam int page, @RequestParam int size,
                                                 @RequestParam(required = false, defaultValue = "") String sortBy,
                                                 @RequestParam(required = false, defaultValue = "") String sortDirection,
                                                 @RequestParam(required = false, defaultValue = "") Integer minRoomBasePrice,
                                                 @RequestParam(required = false, defaultValue = "") Integer maxRoomBasePrice,
                                                 @RequestParam(required = false, defaultValue = "") String roomType,
                                                 @RequestParam(required = false, defaultValue = "") Integer hotelId) {
    SearchDto<Rooms> response = roomsService.getAllRooms(page, size, sortBy, sortDirection, roomType, hotelId, minRoomBasePrice, maxRoomBasePrice);
    return new ApiResponse<>(HttpStatus.FOUND.value(), "Successful", response);
}


    @DeleteMapping("/deleteRoom/{id}")
    public ApiResponse<Boolean> deleteRoom(@PathVariable int id){
        return new ApiResponse<Boolean>(HttpStatus.OK .value(), "Deleted" , roomsService.deleteRoomsById(id));
    }

    @PatchMapping("/updateRoom/{id}")
    public ApiResponse<Rooms> updateRoom(@PathVariable int id ,
                            @RequestParam int roomNumber , @RequestParam String roomType )
    {
        return new ApiResponse<>(HttpStatus.OK .value(),
                "Room was Updated Successfully !! " ,
                roomsService.updateRoomsById(id,roomNumber,roomType));
    }
    @GetMapping("/getRoomsByHotelId")
    public ApiResponse<List<Rooms>> getRoomsByHotelId(@RequestParam int hotelId){
        List<Rooms> rooms = roomsService.getRoomsByHotelId(hotelId);
        return new ApiResponse<>(HttpStatus.FOUND.value(), "Rooms fetched successfully", rooms);
    }
    @DeleteMapping("/deleteRoomsByHotelId/{hotelId}")
    public ApiResponse<Boolean> deleteRoomsByHotelId(@RequestParam int hotelId){
        return new ApiResponse<>(HttpStatus.OK.value(), "Rooms deleted successfully", roomsService.deleteRoomsByHotelId(hotelId));
    }
}

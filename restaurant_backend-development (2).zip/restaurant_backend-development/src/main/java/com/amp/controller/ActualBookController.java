package com.amp.controller;

import com.amp.dto.ApiResponse;
import com.amp.dto.SearchDto;
import com.amp.entity.ActualBooking;
import com.amp.entity.Guest;
import com.amp.service.ActualBookService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/booking")
@CrossOrigin(origins = "*")
public class ActualBookController {
    @Autowired
    private ActualBookService actualBookService;


    @PostMapping("/addRecord")
    public ApiResponse<ActualBooking> addRecord(@RequestBody ActualBooking actualBooking , HttpServletRequest httpServletRequest){
        return new ApiResponse<>(HttpStatus.ACCEPTED.value()
                ,"Record Saved ",actualBookService.addRecord(actualBooking,httpServletRequest));
    }

@GetMapping("/getAll")
public ApiResponse<SearchDto<ActualBooking>> getRecords(@RequestParam int page, @RequestParam int size,
                                                        @RequestParam(required = false, defaultValue = "") String sortBy,
                                                        @RequestParam(required = false, defaultValue = "") String sortDirection,
                                                        @RequestParam(required = false) Long userId,
                                                        @RequestParam(required = false, defaultValue = "") String city,
                                                        @RequestParam(required = false) LocalDate checkInDate,
                                                        @RequestParam(required = false) LocalDate checkOutDate) {
    SearchDto<ActualBooking> response = actualBookService.getAllRecords(page, size, sortBy, sortDirection, userId, city, checkInDate, checkOutDate);
    return new ApiResponse<>(HttpStatus.FOUND.value(), "Records Fetched !!", response);
}



    @GetMapping("/guests")
    public ApiResponse<List<Guest>> getGuest(@RequestParam int id){
        return new ApiResponse<>(HttpStatus.FOUND.value(),
                "Guests Were Fetched ! ", actualBookService.getGuestByBookingId(id));
    }

    @PutMapping("/cancel")
    public ApiResponse<ActualBooking> cancelBooking(@RequestParam int bookingId,
                                                    @RequestParam String cancelReason) {
        return new ApiResponse<>(HttpStatus.OK.value(), "Booking Cancelled",
                actualBookService.cancelBooking(bookingId, cancelReason));
    }

    @GetMapping("/history")
    public ApiResponse<List<ActualBooking>> getBookingHistoryByUserId(@RequestParam long userId) {
        return new ApiResponse<>(HttpStatus.FOUND.value(), "Booking History Fetched",
                actualBookService.getBookingHistoryByUserId(userId));
    }
    @PutMapping("/checkin")
    public ApiResponse<ActualBooking> checkInBooking(@RequestParam int bookingId){
    return new ApiResponse<>(HttpStatus.OK.value(), "Booking Checked In",
            actualBookService.checkInBooking(bookingId));
    }
    @PutMapping("/checkout")
    public ApiResponse<ActualBooking> checkOutBooking(@RequestParam int bookingId){
        return new ApiResponse<>(HttpStatus.OK.value(), "Booking Checked Out",
                actualBookService.checkOutBooking(bookingId));
    }

}



package com.amp.controller;

import com.amp.dto.ApiResponse;
import com.amp.dto.SearchDto;
import com.amp.entity.MasterAmenity;
import com.amp.service.HotelService;
import com.amp.service.MasterAmenityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RequestMapping("/api/masterAmenity")
@RestController
@CrossOrigin(origins = "*")
public class MasterAmenityController {

    @Autowired
    private MasterAmenityService masterAmenityService;

    @Autowired
    private HotelService hotelService;

    // Get all master amenities
@GetMapping("/getAll")
public ApiResponse<SearchDto<MasterAmenity>> getAll(@RequestParam int page, @RequestParam int size,
                                                    @RequestParam(required = false, defaultValue = "") String sortBy,
                                                    @RequestParam(required = false, defaultValue = "") String sortDirection,
                                                    @RequestParam(required = false, defaultValue = "") String keyword) {
    SearchDto<MasterAmenity> response = masterAmenityService.getAllMasterAmenities(page, size, sortBy, sortDirection, keyword);
    if (response.getData().isEmpty()) {
        return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "No Master Amenities Found", response);
    }
    return new ApiResponse<>(HttpStatus.OK.value(), "Master Amenities Found", response);
}


    // Get master amenity by ID
    @GetMapping("/get/{id}")
    public ApiResponse<MasterAmenity> getMasterAmenityById(@PathVariable int id) {
        try {
            MasterAmenity masterAmenity = masterAmenityService.getMasterAmenityById(id);
            return new ApiResponse<>(HttpStatus.OK.value(), "Master Amenity Found", masterAmenity);
        } catch (RuntimeException e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Master Amenity Not Found", null);
        }
    }

    // Create a new master amenity
    @PostMapping("/create")
    public ApiResponse<MasterAmenity> createMasterAmenity(@RequestBody MasterAmenity masterAmenity) {
        try {
            MasterAmenity savedMasterAmenity = masterAmenityService.createMasterAmenity(masterAmenity);
            return new ApiResponse<>(HttpStatus.CREATED.value(), "Master Amenity Created", savedMasterAmenity);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Bad Request", null);
        }
    }

    // Update an existing master amenity
    @PutMapping("/update/{id}")
    public ApiResponse<MasterAmenity> updateMasterAmenity(@PathVariable int id, @RequestBody MasterAmenity masterAmenity) {
        try {
            MasterAmenity updatedMasterAmenity = masterAmenityService.updateMasterAmenity(id, masterAmenity);
            return new ApiResponse<>(HttpStatus.OK.value(), "Master Amenity Updated", updatedMasterAmenity);
        } catch (RuntimeException e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Master Amenity Not Found", null);
        }
    }

    // Delete a master amenity
    @DeleteMapping("/delete/{id}")
    public ApiResponse<Void> deleteMasterAmenity(@PathVariable int id) {
        boolean isDeleted = masterAmenityService.deleteMasterAmenity(id);
        if (isDeleted) {
            return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "Master Amenity Deleted", null);
        } else {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Master Amenity Not Found", null);
        }
    }
    // Fetch amenities associated with a hotel ID
    @GetMapping("/getByHotelId/{hotelId}")
    public ApiResponse<Set<MasterAmenity>> getAmenitiesByHotelId(@PathVariable int hotelId) {
        try {
            Set<MasterAmenity> amenities = hotelService.getAmenitiesByHotelId(hotelId);
            return new ApiResponse<>(HttpStatus.OK.value(), "Amenities found for Hotel", amenities);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Hotel not found or no amenities found", null);
        }
    }

    // Add amenities to a hotel
    @PostMapping("/addAmenitiesToHotel/{hotelId}")
    public ApiResponse<Set<MasterAmenity>> addAmenitiesToHotel(@PathVariable int hotelId, @RequestBody List<Integer> amenityIds) {
        try {
            Set<MasterAmenity> addedAmenities = hotelService.addAmenitiesToHotel(hotelId, amenityIds);
            return new ApiResponse<>(HttpStatus.CREATED.value(), "Amenities added successfully", addedAmenities);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Error adding amenities to hotel", null);
        }
    }

    // Update amenities of a hotel
    @PutMapping("/updateAmenitiesByHotelId/{hotelId}")
    public ApiResponse<Set<MasterAmenity>> updateAmenitiesByHotelId(@PathVariable int hotelId, @RequestBody List<Integer> amenityIds) {
        try {
            Set<MasterAmenity> updatedAmenities = hotelService.updateAmenitiesByHotelId(hotelId, amenityIds);
            return new ApiResponse<>(HttpStatus.OK.value(), "Amenities updated successfully", updatedAmenities);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Error updating amenities for hotel", null);
        }
    }
}

package com.amp.dto;

import com.amp.entity.Role;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
//@NoArgsConstructor
public class JwtLoginResponse {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String mobile;
    private Role role;
    private String token;
}

package com.amp.utilis.serialization;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.amp.entity.BookingStatus;

import java.io.IOException;

public class BookingStatusSerializer extends JsonSerializer<BookingStatus> {

    @Override
    public void serialize(BookingStatus status, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        if (status != null) {
            jsonGenerator.writeString(status.name());
        }
    }
}

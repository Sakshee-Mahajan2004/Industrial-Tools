package com.amp.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApi {
    @Bean
    public OpenAPI customOpenAPIConfig() {
        return new OpenAPI().info(buildInfo());
    }
    private Info buildInfo() {
        return new Info().title("Hotel Management API").description("All hotel management api");
    }
}

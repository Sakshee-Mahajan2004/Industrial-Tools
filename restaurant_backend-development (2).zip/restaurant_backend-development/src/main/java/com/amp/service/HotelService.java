package com.amp.service;

import com.amp.dto.SearchDto;


import com.amp.entity.Hotel;
import com.amp.entity.MasterAmenity;

import java.util.List;
import java.util.Set;

public interface HotelService {
    Hotel saveHotelInfo(Hotel hotel);  // Save a new hotel or update existing
    Hotel findHotelById(int id);  // Find hotel by its ID
//    PaginatedResponse<Hotel> getAll(int page, int size);  // Get all hotels
    SearchDto<Hotel> getAll(int page, int size,String sortBy,String sortDirection,int roomsNeeded, String city);  // Get all hotels

    boolean deleteHotel(int id);  // Delete hotel by ID
    Hotel updateHotel(int id, Hotel hotel);  // Update hotel information
    Hotel checkout(int bookingId);
    List<Hotel> findByCityEqualsIgnoreCase(String City , int hotelRooms);

    List<Hotel> findHotelsByUserId(long userId);
    Set<String> getAllHotelLocation();

    Set<MasterAmenity> updateAmenitiesByHotelId(int hotelId, List<Integer> amenityIds);

    Set<MasterAmenity> addAmenitiesToHotel(int hotelId, List<Integer> amenityIds);

    Set<MasterAmenity> getAmenitiesByHotelId(int hotelId);
}

package com.amp.service;

import com.amp.dto.SearchDto;
import com.amp.entity.Rooms;

import java.util.List;

public interface RoomsService {
    Rooms addRoom(Rooms rooms);
    SearchDto<Rooms> getAllRooms(int page, int size,String sortBy,String sortDirection,String roomType, Integer hotelId, Integer minRoomBasePrice, Integer maxRoomBasePrice);
    boolean deleteRoomsById(int id);
    Rooms updateRoomsById(int id , int roomNumber , String roomType );
    List<Rooms> getRoomsByHotelId(int hotelId);
    Boolean deleteRoomsByHotelId(int hotelId);
}

package com.amp.service;

import com.amp.dto.SearchDto;
import com.amp.entity.MasterAmenity;

public interface MasterAmenityService {
    SearchDto<MasterAmenity> getAllMasterAmenities(int page, int size,String sortBy,String sortDirection,String keyword);
    MasterAmenity getMasterAmenityById(int id);
    MasterAmenity createMasterAmenity(MasterAmenity masterAmenity);

    boolean deleteMasterAmenity(int id);


    MasterAmenity updateMasterAmenity(int id, MasterAmenity masterAmenity);
}

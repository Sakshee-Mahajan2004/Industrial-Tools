package com.amp.service;

import com.amp.entity.Hotel;
import com.amp.entity.Images;
import com.amp.entity.Rooms;
import org.springframework.core.io.UrlResource;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ImageService {



    Images saveImage(MultipartFile imageFile, Hotel hotel, Rooms room) throws IOException;


    void deleteImageById(int id);


    public Images getImageById(int imageId);

//    public List<Images> getImageByHotelIdAndRoomId(Hotel hotel,Rooms room);
//    List<Images> findByHotel_HotelId(Hotel hotel);   // Fetch images by hotel
//    List<Images> findByRoom_RoomId(Rooms room);

    List<Images> getImagesByHotelAndRoom(Integer hotelId, Integer roomId);
}

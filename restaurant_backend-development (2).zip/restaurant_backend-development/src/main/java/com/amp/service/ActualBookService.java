package com.amp.service;

import com.amp.dto.SearchDto;
import com.amp.entity.ActualBooking;
import com.amp.entity.Guest;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDate;
import java.util.List;

public interface ActualBookService {
//    ActualBooking addRecord(ActualBooking actualBooking);
//    SearchDto<ActualBooking> getAllRecords(int page, int size, String sortBy, String sortDirection);
      SearchDto<ActualBooking> getAllRecords(int page, int size,String sortBy,String sortDirection, Long userId, String city, LocalDate checkInDate, LocalDate checkOutDate);
    ActualBooking addRecord(ActualBooking actualBooking , HttpServletRequest httpServletRequest);
//    List<ActualBooking> getAllRecords(int page, int size);
    List<Guest> getGuestByBookingId(int id);
    ActualBooking cancelBooking(int bookingId, String cancelReason);
    List<ActualBooking> getBookingHistoryByUserId(long userId);

    ActualBooking checkInBooking(int bookingId);

    ActualBooking checkOutBooking(int bookingId);
}

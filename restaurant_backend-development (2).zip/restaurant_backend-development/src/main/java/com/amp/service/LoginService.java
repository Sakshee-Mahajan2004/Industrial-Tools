package com.amp.service;


import com.amp.dto.LoginRequest;
import com.amp.dto.JwtLoginResponse;

public interface LoginService {
    JwtLoginResponse login(LoginRequest loginRequest);


}

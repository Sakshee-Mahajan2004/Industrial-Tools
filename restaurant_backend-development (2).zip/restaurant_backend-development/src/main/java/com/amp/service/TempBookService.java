package com.amp.service;

import com.amp.dto.SearchDto;
import com.amp.entity.TemporaryBooking;

import java.time.LocalDate;

public interface TempBookService {
    TemporaryBooking addRecord(TemporaryBooking temporaryBooking);
    SearchDto<TemporaryBooking> getTempRecords(int page, int size,String sortBy,String sortDirection,String city, Integer minAdults, Integer maxAdults,
                                               LocalDate checkInDateStart, LocalDate checkInDateEnd);
    boolean deleteRecord(int id );
}
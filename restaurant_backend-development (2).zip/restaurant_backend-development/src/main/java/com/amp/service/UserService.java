package com.amp.service;

import com.amp.dto.SearchDto;
import com.amp.entity.User;
import jakarta.validation.Valid;

import java.util.List;

public interface UserService {



   User registerUser(User user) throws Exception;
   SearchDto<User> findAllUsers(int page, int size,String sortBy,String sortDirection,String searchTerm);
   User findUserById(long id);
   void deleteUserById(long id);
   User updateUser(long id, User userDetails);


   User registerOwner(User user);

   boolean existsByEmail(String email);

   boolean existsByMobile(String mobile);
}




package com.amp.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.checkerframework.common.aliasing.qual.Unique;


@Entity
@Table(name = "users")
@Data
public class User  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long userId;

    @NotEmpty(message = "user first name must not be empty")
    private String firstName;

    @NotEmpty(message = "user last name must not be empty")
    private String lastName;

    @NotEmpty(message = "user email must not be empty")
    @Email(message = "Invalid email format")
    private String email;

    @NotEmpty(message = "user password must not be empty")
    private String password;

    @Pattern(regexp = "^[0-9]{10}$", message = "Invalid mobile number. ")
    @Unique
    @NotEmpty(message = "user mobile number must not be empty")
    private String mobile;
    @ManyToOne
    @JoinColumn(name = "role_Id")
    private Role role;

}

package com.amp.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "roles")
@Data
public class Role {

    @Id
    @Column(name = "role_Id", unique = true)
    private int roleId;

    private String roleName;
}
package com.amp.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TemporaryBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tempBookingId;
    @NotEmpty(message = "City Cannot Be Empty ")
    private String city;
    private Date inquiryDate;
    @NotNull(message = "Date Cannot Be Empty ! ")
    private LocalDate checkInDate;
    @NotNull(message = "Date Cannot be Empty ")
    @Future(message = "CheckIn Checkout Cannot be same ")
    private LocalDate checkOutDate;
    @Min(value = 1 , message = "Minimum 1 Adult ")
    private int numberOfAdults;
    @NotNull(message = "Hotel Price Must Not be Empty ")
    private double hotelPrice;
    @Min(value = 1 , message = "Minimum 1 room must be selected")
    private int numberOfRoomsSelected ;


    @JsonIgnoreProperties({"password","role"})
    @ManyToOne(fetch = FetchType.EAGER )
    @JoinColumn(name = "user_id")
    private User user ;

    @JsonIgnoreProperties({"amenities","amenityIds","hotelOwner"})
    @ManyToOne(fetch = FetchType.EAGER )
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;

}

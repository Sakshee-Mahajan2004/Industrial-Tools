package com.amp.entity;

public enum CheckInStatus {
    NOT_CHECKED_IN,
    CHECKED_IN,
    CHECKED_OUT;
}

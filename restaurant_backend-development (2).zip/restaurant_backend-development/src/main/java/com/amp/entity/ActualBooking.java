package com.amp.entity;

import com.amp.utilis.serialization.BookingStatusDeserializer;
import com.amp.utilis.serialization.BookingStatusSerializer;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ActualBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int BookingId;
    @NotNull(message = "UserId cannot be Null ")
    public long userId ;
    @NotEmpty(message = "City name must Not be Empty ! ")
    private String city ;
    @NotNull(message = "CheckIn Date Must Not Be Empty ! ")
    private LocalDate checkInDate;

    @NotNull(message = "CheckOut Date Must Not Be Empty ! ")
    @Future(message = "CheckOut Date Must be In Future ! ")
    private LocalDate checkOutDate;

    @Min(value = 1 , message = "Minimum 1 adult Should be There ")
    private int numberOfAdults;

    @Min(value = 1 , message = "Minimum 1 Room Must Be Selected ! ")
    private int roomsNeeded;

    @NotNull
    @NotEmpty(message = "RoomType Must Not be Empty ! ")
    private String roomType ;
    private int totalPrice;  //set from backend
    private String paymentStatus;

    @NotEmpty(message = "Payment Method Must Be Specified ")
    private String paymentMethod;

    @NotNull(message = "Hotel Id must Be Specified ! ")
    private int hotelId;// frontend
    private String hotelName;
    private String hotelAddress;


    private int roomId;
    private int availableRooms;

    private String cancelReason;
    @Enumerated(EnumType.ORDINAL)  // Store as integer in the database
    @JsonSerialize(using = BookingStatusSerializer.class)
    @JsonDeserialize(using = BookingStatusDeserializer.class)
    private BookingStatus status;

    @Enumerated(EnumType.ORDINAL)
    private CheckInStatus CheckInStatus = com.amp.entity.CheckInStatus.NOT_CHECKED_IN;

    @OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "actualBooking")
    private List<Guest> guest;

}

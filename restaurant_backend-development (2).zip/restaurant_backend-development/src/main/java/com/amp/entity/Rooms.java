package com.amp.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Rooms {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int roomId ;
    @NotEmpty(message = "Must Specify the Room Type ")
    private String roomType ;
    @NotNull(message = "Base Price must be Given ")
    private int roomBasePrice ;
    @NotNull(message = "Number Of Rooms Cannot Be Null ")
    @Min(value = 0 )
    private int numberOfRooms;

   @ManyToOne(fetch = FetchType.EAGER , cascade = CascadeType.ALL)
   @JoinColumn(name = "hotel_id")
    private Hotel hotel;
}

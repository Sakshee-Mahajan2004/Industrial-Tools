package com.amp.entity;

public enum BookingStatus {
    PENDING,
    BOOKED,
    CANCELLED
}

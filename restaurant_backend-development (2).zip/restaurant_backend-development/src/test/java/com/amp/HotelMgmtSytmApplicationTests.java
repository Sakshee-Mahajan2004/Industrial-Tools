package com.amp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelMgmtSytmApplicationTests {

	@Test
	void contextLoads() {
	}

}

import React from 'react';
import { IncentiveCycle, Candidate, MonthlyHours } from '../types';
import { X, Calendar, Users, Clock, AlertCircle } from 'lucide-react';
import { ExportUtils } from './ExportUtils';

interface CycleHoursReportModalProps {
  cycle: IncentiveCycle;
  candidates: Candidate[];
  onClose: () => void;
}

export const CycleHoursReportModal: React.FC<CycleHoursReportModalProps> = ({
  cycle,
  candidates,
  onClose
}) => {
  const formatMonth = (month: string) => {
    if (/^\d{4}$/.test(month)) {
      return month; 
    }
    const [year, monthNum] = month.split('-');
    return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };
  

  // Group hours by month
  const hoursByMonth = cycle.monthlyHours.reduce((acc, hours) => {
    if (!acc[hours.month]) {
      acc[hours.month] = [];
    }
    acc[hours.month].push(hours);
    return acc;
  }, {} as Record<string, MonthlyHours[]>);

  const months = Object.keys(hoursByMonth).sort();
  const retroactiveMonths = months.filter(month => month !== cycle.month);

  const getTotalHours = (monthHours: MonthlyHours[]) => {
    return monthHours.reduce((sum, h) => sum + h.hoursWorked, 0);
  };

  const getCandidateInfo = (candidateId: string) => {
    return candidates.find(c => c.candidateId === candidateId);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Clock className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Hours Report</h2>
              <p className="text-sm text-gray-500">
                Cycle: {formatMonth(cycle.month)} • {cycle.monthlyHours.length} entries
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <ExportUtils
              data={cycle.monthlyHours}
              filename={`hours-report-${cycle.month}`}
              title={`Hours Report - ${formatMonth(cycle.month)}`}
              type="hours"
              cycle={cycle}
              candidates={candidates}
            />
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-600 text-sm font-medium">Total Entries</p>
                  <p className="text-2xl font-bold text-blue-900">{cycle.monthlyHours.length}</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-600 text-sm font-medium">Total Hours</p>
                  <p className="text-2xl font-bold text-green-900">
                    {cycle.monthlyHours.reduce((sum, h) => sum + h.hoursWorked, 0)}
                  </p>
                </div>
                <Clock className="w-8 h-8 text-green-600" />
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-600 text-sm font-medium">Months Covered</p>
                  <p className="text-2xl font-bold text-purple-900">{months.length}</p>
                </div>
                <Calendar className="w-8 h-8 text-purple-600" />
              </div>
            </div>

            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-600 text-sm font-medium">Retroactive</p>
                  <p className="text-2xl font-bold text-orange-900">{retroactiveMonths.length}</p>
                </div>
                <AlertCircle className="w-8 h-8 text-orange-600" />
              </div>
            </div>
          </div>

          {/* Retroactive Hours Notice */}
          {retroactiveMonths.length > 0 && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                <h3 className="font-medium text-orange-900">Retroactive Hours Added</h3>
              </div>
              <p className="text-orange-700 text-sm mb-2">
                Hours were added for previous months: {retroactiveMonths.map(formatMonth).join(', ')}
              </p>
            </div>
          )}

          {/* Month-wise Breakdown */}
          {months.map(month => (
            <div key={month} className="bg-white border border-gray-200 rounded-lg">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Calendar className="w-5 h-5 mr-2" />
                    {formatMonth(month)}
                    {month !== cycle.month && (
                      <span className="ml-2 px-2 py-1 bg-orange-100 text-orange-800 text-xs font-medium rounded-full">
                        Retroactive
                      </span>
                    )}
                  </h3>
                  <div className="text-sm text-gray-600">
                    {hoursByMonth[month].length} candidates • {getTotalHours(hoursByMonth[month])} total hours
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Candidate
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Client
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contract Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Hours Worked
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Margin/Finder Fees
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {hoursByMonth[month]
                      .sort((a, b) => b.hoursWorked - a.hoursWorked)
                      .map((hours, index) => {
                        const candidate = getCandidateInfo(hours.candidateId);
                        return (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div>
                                <div className="font-medium text-gray-900">
                                  {candidate?.candidateName || 'Unknown'}
                                </div>
                                <div className="text-sm text-gray-500">{hours.candidateId}</div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                              {candidate?.clientName || 'N/A'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                candidate?.contractType === 'FULLTIME' 
                                  ? 'bg-purple-100 text-purple-800'
                                  : candidate?.contractType === 'W2'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-green-100 text-green-800'
                              }`}>
                                {candidate?.contractType || 'Unknown'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-lg font-semibold text-gray-900">
                                {hours.hoursWorked}
                              </div>
                              {candidate?.contractType === 'FULLTIME' && (
                                <div className="text-xs text-gray-500">
                                  {hours.hoursWorked > 0 ? 'Placement' : 'No placement'}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                              {candidate?.contractType === 'FULLTIME' 
                                ? (candidate.finderFees ? `$${candidate.finderFees.toFixed(2)}` : 'N/A')
                                : (candidate?.margin ? `$${candidate.margin.toFixed(2)}/hr` : 'N/A')
                              }
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
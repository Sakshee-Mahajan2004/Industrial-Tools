import React, { useState, useMemo } from 'react';
import { IncentiveCycle, Candidate, IncentiveCalculation } from '../types';
import { formatCurrencyForReport } from '../utils/calculations';
import { FileText, X, Download, Filter, Eye } from 'lucide-react';

interface CustomReportModalProps {
  cycles: IncentiveCycle[];
  candidates: Candidate[];
  onClose: () => void;
}

interface ReportFilters {
  selectedCycles: string[];
  selectedCoordinators: string[];
  selectedCandidates: string[];
  coordinatorTypes: string[];
  minIncentive: number;
  maxIncentive: number;
  includeZeroIncentives: boolean;
}

interface ReportRow {
  cycleMonth: string;
  coordinatorName: string;
  coordinatorType: string;
  candidateId: string;
  candidateName: string;
  clientName: string;
  startDate: string;
  endDate: string;
  payRate: number;
  billRate: number;
  margin: number;
  hoursWorked: number;
  incentiveAmount: number;
  incentiveType: string;
  taxesPercentage: number;
  healthBenefits: number;
  netPurchase: number;
  mspFeesPercentage: number;
  netBillRate: number;
  recruiter: string;
  crm: string;
  lead: string;
  manager: string;
  seniorManager: string;
  assoDirector: string;
  centerHead: string;
}

export const CustomReportModal: React.FC<CustomReportModalProps> = ({
  cycles,
  candidates,
  onClose
}) => {
  const [filters, setFilters] = useState<ReportFilters>({
    selectedCycles: cycles.map(c => c.id),
    selectedCoordinators: [],
    selectedCandidates: [],
    coordinatorTypes: [],
    minIncentive: 0,
    maxIncentive: 0,
    includeZeroIncentives: false
  });

  const [showPreview, setShowPreview] = useState(false);

  const reportData = useMemo(() => {
    const rows: ReportRow[] = [];
    
    cycles.forEach(cycle => {
      if (!filters.selectedCycles.includes(cycle.id)) return;
      
      cycle.incentiveCalculations.forEach(calc => {
        const candidate = candidates.find(c => c.candidateId === calc.candidateId);
        if (!candidate) return;
        
        // Apply filters
        if (filters.selectedCoordinators.length > 0 && 
            !filters.selectedCoordinators.includes(calc.coordinatorName)) return;
        
        if (filters.selectedCandidates.length > 0 && 
            !filters.selectedCandidates.includes(calc.candidateId)) return;
        
        if (filters.coordinatorTypes.length > 0 && 
            filters.coordinatorTypes.includes(calc.coordinatorType)) return;
        
        if (calc.incentiveAmount < filters.minIncentive) return;
        if (filters.maxIncentive > 0 && calc.incentiveAmount > filters.maxIncentive) return;
        
        if (!filters.includeZeroIncentives && calc.incentiveAmount === 0) return;
        
        rows.push({
          cycleMonth: cycle.month,
          coordinatorName: calc.coordinatorName,
          coordinatorType: calc.coordinatorType,
          candidateId: calc.candidateId,
          candidateName: calc.candidateName,
          clientName: candidate.clientName,
          startDate: candidate.startDate,
          endDate: candidate.endDate || '',
          payRate: candidate.payRate,
          billRate: candidate.billRate,
          margin: calc.margin,
          hoursWorked: calc.hoursWorked,
          incentiveAmount: calc.incentiveAmount,
          incentiveType: calc.isRecurring ? 'Recurring' : 'One-time',
          taxesPercentage: (candidate as any).taxesPercentage ?? '',
          healthBenefits: candidate.healthBenefits,
          netPurchase: candidate.netPurchase,
          mspFeesPercentage: candidate.mspFeesPercentage,
          netBillRate: candidate.netBillRate,
          recruiter: typeof candidate.recruiter === 'string' ? candidate.recruiter : '',
          crm: typeof candidate.crm === 'string' ? candidate.crm : '',
          lead: typeof candidate.lead === 'string' ? candidate.lead : '',
          manager: typeof candidate.manager === 'string' ? candidate.manager : '',
          seniorManager: typeof candidate.seniorManager === 'string' ? candidate.seniorManager : '',
          assoDirector: typeof candidate.assoDirector === 'string' ? candidate.assoDirector : '',
          centerHead: typeof candidate.centerHead === 'string' ? candidate.centerHead : ''
        });
      });
    });
    
    return rows;
  }, [cycles, candidates, filters]);

  const uniqueCoordinators = useMemo(() => {
    const coordinators = new Set<string>();
    cycles.forEach(cycle => {
      cycle.incentiveCalculations.forEach(calc => {
        coordinators.add(calc.coordinatorName);
      });
    });
    return Array.from(coordinators).sort();
  }, [cycles]);

  const uniqueCandidates = useMemo(() => {
    return candidates.map(c => ({ id: c.candidateId, name: c.candidateName })).sort((a, b) => a.name.localeCompare(b.name));
  }, [candidates]);

  const coordinatorTypes = [
    'recruiter', 'crm', 'teamLead', 'manager', 'seniorManager', 'assoDirector', 'centerHead'
  ];

  const handleFilterChange = (key: keyof ReportFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleMultiSelectChange = (key: keyof ReportFilters, value: string, checked: boolean) => {
    setFilters(prev => ({
      ...prev,
      [key]: checked 
        ? [...(prev[key] as string[]), value]
        : (prev[key] as string[]).filter(item => item !== value)
    }));
  };

  const downloadReport = () => {
    const headers = [
      'Cycle Month', 'Coordinator Name', 'Coordinator Type', 'Candidate ID', 'Candidate Name',
      'Client Name', 'Start Date', 'End Date', 'Pay Rate', 'Bill Rate', 'Margin',
      'Hours Worked', 'Incentive Amount', 'Incentive Type', 'Taxes %', 'Health Benefits',
      'Net Purchase', 'MSP Fees %', 'Net Bill Rate', 'Recruiter', 'CRM', 'Team Lead',
      'Manager', 'Senior Manager', 'Associate Director', 'Center Head'
    ];

    const csvContent = [
      headers,
      ...reportData.map(row =>[
        new Date(row.cycleMonth + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' }),
        row.coordinatorName,
        capitalizeFirstLetter(getCordinatorType(row.coordinatorType)?.replace(/([A-Z])/g, ' $1').trim() || ''),
        row.candidateId,
        row.candidateName,
        row.clientName,
        new Date(row.startDate).toLocaleDateString(),
        row.endDate ? new Date(row.endDate).toLocaleDateString() : '',
        `$${row.payRate.toFixed(2)}`,
        `$${row.billRate.toFixed(2)}`,
        `$${row.margin.toFixed(2)}`,
        row.hoursWorked.toString(),
        Number(row.incentiveAmount || 0).toLocaleString('en-IN'),
        row.incentiveType,
        `${row.taxesPercentage}%`,
        `$${row.healthBenefits.toFixed(2)}`,
        `$${row.netPurchase.toFixed(2)}`,
        `${row.mspFeesPercentage}%`,
        `$${row.netBillRate.toFixed(2)}`,
        row.recruiter,
        row.crm,
        row.lead,
        row.manager,
        row.seniorManager,
        row.assoDirector,
        row.centerHead
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `custom-incentive-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const totalIncentives = reportData.reduce((sum, row) => sum + row.incentiveAmount, 0);

  const getCordinatorType = (type: string) => {
    switch (type) {
      case 'RECRUITER':
        return 'recruiter';
      case 'CRM':
        return 'crm';
      case 'TEAM_LEAD':
        return 'teamLead';
      case 'MANAGER':
        return 'manager';
      case 'SENIOR_MANAGER':
        return 'seniorManager';
      case 'ASSO_DIRECTOR':
        return 'assoDirector';
      case 'CENTER_HEAD':
        return 'centerHead';
      default:
        return type;
    }
  }

  function capitalizeFirstLetter(str: string) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }


  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-screen overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <FileText className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Custom Incentive Report</h2>
              <p className="text-sm text-gray-500">Generate detailed reports with custom filters</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Filters */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-4">
            <div className="flex items-center space-x-2 mb-4">
              <Filter className="w-5 h-5 text-gray-600" />
              <h3 className="text-lg font-medium text-gray-900">Report Filters</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Cycle Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cycles</label>
                <div className="max-h-32 overflow-y-auto border border-gray-300 rounded p-2 bg-white">
                  {cycles.map(cycle => (
                    <label key={cycle.id} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={filters.selectedCycles.includes(cycle.id)}
                        onChange={(e) => handleMultiSelectChange('selectedCycles', cycle.id, e.target.checked)}
                        className="rounded"
                      />
                      <span>{new Date(cycle.month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Coordinator Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Coordinators</label>
                <div className="max-h-32 overflow-y-auto border border-gray-300 rounded p-2 bg-white">
                  {uniqueCoordinators.map(coordinator => (
                    <label key={coordinator} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={filters.selectedCoordinators.includes(coordinator)}
                        onChange={(e) => handleMultiSelectChange('selectedCoordinators', coordinator, e.target.checked)}
                        className="rounded"
                      />
                      <span>{coordinator}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Coordinator Types */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Coordinator Types</label>
                <div className="max-h-32 overflow-y-auto border border-gray-300 rounded p-2 bg-white">
                  {coordinatorTypes.map(type => (
                    <label key={type} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={filters.coordinatorTypes.includes(type)}
                        onChange={(e) => handleMultiSelectChange('coordinatorTypes', type, e.target.checked)}
                        className="rounded"
                      />
                      <span>{type.replace(/([A-Z])/g, ' $1').trim()}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Incentive Range */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Min Incentive (₹)</label>
                <input
                  type="number"
                  value={filters.minIncentive}
                  onChange={(e) => handleFilterChange('minIncentive', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Max Incentive (₹)</label>
                <input
                  type="number"
                  value={filters.maxIncentive}
                  onChange={(e) => handleFilterChange('maxIncentive', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="No limit"
                />
              </div>

              {/* Include Zero Incentives */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="includeZero"
                  checked={filters.includeZeroIncentives}
                  onChange={(e) => handleFilterChange('includeZeroIncentives', e.target.checked)}
                  className="rounded"
                />
                <label htmlFor="includeZero" className="text-sm font-medium text-gray-700">
                  Include Zero Incentives
                </label>
              </div>
            </div>
          </div>

          {/* Report Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-blue-600 text-sm font-medium">Total Records</p>
              <p className="text-2xl font-bold text-blue-900">{reportData.length}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-green-600 text-sm font-medium">Total Incentives</p>
              <p className="text-2xl font-bold text-green-900">{formatCurrencyForReport(totalIncentives)}</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-purple-600 text-sm font-medium">Unique Coordinators</p>
              <p className="text-2xl font-bold text-purple-900">
                {new Set(reportData.map(r => r.coordinatorName)).size}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between items-center">
            <button
              onClick={() => setShowPreview(!showPreview)}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <Eye className="w-4 h-4" />
              <span>{showPreview ? 'Hide Preview' : 'Show Preview'}</span>
            </button>

            <button
              onClick={downloadReport}
              className="flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              disabled={reportData.length === 0}
            >
              <Download className="w-4 h-4" />
              <span>Download Report ({reportData.length} records)</span>
            </button>
          </div>

          {/* Preview */}
          {showPreview && (
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-2 border-b">
                <h4 className="font-medium text-gray-900">Report Preview (First 10 records)</h4>
              </div>
              <div className="overflow-x-auto max-h-96">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Month</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Coordinator</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Candidate</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Margin</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Incentive</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {reportData.slice(0, 10).map((row, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-3 py-2 whitespace-nowrap">
                          {new Date(row.cycleMonth + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap font-medium">{row.coordinatorName}</td>
                        <td className="px-3 py-2 whitespace-nowrap text-xs">
                          <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                            {capitalizeFirstLetter(getCordinatorType(row.coordinatorType)?.replace(/([A-Z])/g, ' $1').trim() || '')}
                          </span>
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap">{row.candidateName}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{row.clientName}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{row.hoursWorked}</td>
                        <td className="px-3 py-2 whitespace-nowrap">${row.margin.toFixed(2)}</td>
                        <td className="px-3 py-2 whitespace-nowrap font-semibold text-green-600">
                          {formatCurrencyForReport(row.incentiveAmount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
import React, { useMemo, useState } from 'react';
import { IncentiveCalculation } from '../types';
import { formatCurrencyForReport } from '../utils/calculations';
import { ExportUtils } from './ExportUtils';
import { TrendingUp, Users, DollarSign, Calendar, Filter, Eye, EyeOff } from 'lucide-react';

interface IncentiveReportsProps {
  incentives: IncentiveCalculation[];
}

export const IncentiveReports: React.FC<IncentiveReportsProps> = ({ incentives }) => {
  const [fromMonth, setFromMonth] = useState('');
  const [toMonth, setToMonth] = useState('');
  const [showPreview, setShowPreview] = useState(false);

  // Filter incentives based on date range
  const filteredIncentives = useMemo(() => {
    if (!fromMonth && !toMonth) return incentives;
    
    return incentives.filter(incentive => {
      const incentiveMonth = incentive.month;
      
      if (fromMonth && incentiveMonth < fromMonth) return false;
      if (toMonth && incentiveMonth > toMonth) return false;
      
      return true;
    });
  }, [incentives, fromMonth, toMonth]);

  const summaryData = useMemo(() => {
    const personSummary = filteredIncentives.reduce((acc, incentive) => {
      if (!acc[incentive.coordinatorName]) {
        acc[incentive.coordinatorName] = {
          name: incentive.coordinatorName,
          type: incentive.coordinatorType,
          totalIncentive: 0,
          candidates: new Set(),
          months: new Set()
        };
      }
      
      acc[incentive.coordinatorName].totalIncentive += incentive.incentiveAmount;
      acc[incentive.coordinatorName].candidates.add(incentive.candidateId);
      acc[incentive.coordinatorName].months.add(incentive.month);
      
      return acc;
    }, {} as Record<string, any>);

    return Object.values(personSummary).map((person: any) => ({
      ...person,
      candidateCount: person.candidates.size,
      monthCount: person.months.size
    }));
  }, [filteredIncentives]);

  const monthlyData = useMemo(() => {
    const monthly = filteredIncentives.reduce((acc, incentive) => {
      if (!acc[incentive.month]) {
        acc[incentive.month] = {
          month: incentive.month,
          totalIncentive: 0,
          coordinatorCount: new Set(),
          candidateCount: new Set()
        };
      }
      
      acc[incentive.month].totalIncentive += incentive.incentiveAmount;
      acc[incentive.month].coordinatorCount.add(incentive.coordinatorName);
      acc[incentive.month].candidateCount.add(incentive.candidateId);
      
      return acc;
    }, {} as Record<string, any>);

    return Object.values(monthly)
      .map((month: any) => ({
        ...month,
        coordinatorCount: month.coordinatorCount.size,
        candidateCount: month.candidateCount.size
      }))
      .sort((a, b) => b.month.localeCompare(a.month)); // Sort by month descending
  }, [filteredIncentives]);

  const totalIncentives = filteredIncentives.reduce((sum, incentive) => sum + incentive.incentiveAmount, 0);
  const uniqueCoordinators = new Set(filteredIncentives.map(i => i.coordinatorName)).size;
  const uniqueCandidates = new Set(filteredIncentives.map(i => i.candidateId)).size;

  // const formatMonth = (month: string) => {
  //   const [year, monthNum] = month.split('-');
  //   return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { 
  //     year: 'numeric', 
  //     month: 'long' 
  //   });
  // };
  const formatMonth = (month: string) => {
    if (!month || typeof month !== 'string' || !month.includes('-')) return 'Invalid Month';
    const [year, monthNum] = month.split('-');
    return new Date(parseInt(year), parseInt(monthNum) - 1).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };


  const clearFilters = () => {
    setFromMonth('');
    setToMonth('');
  };

  const getCordinatorType = (type: string) => {
    switch (type) {
      case 'RECRUITER':
        return 'recruiter';
      case 'CRM':
        return 'crm';
      case 'TEAM_LEAD':
        return 'teamLead';
      case 'MANAGER':
        return 'manager';
      case 'SENIOR_MANAGER':
        return 'seniorManager';
      case 'ASSO_DIRECTOR':
        return 'assoDirector';
      case 'CENTER_HEAD':
        return 'centerHead';
      default:
        return type;
    }
  }

  function capitalizeFirstLetter(str: string) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
 
  return (
    <div className="space-y-8">
      {/* Date Range Filter */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Month-wise Report Filter</h3>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowPreview(!showPreview)}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span>{showPreview ? 'Hide Preview' : 'Show Preview'}</span>
            </button>
            <ExportUtils
              data={filteredIncentives}
              filename={`legacy-incentive-report${fromMonth || toMonth ? `_${fromMonth || 'start'}_to_${toMonth || 'end'}` : ''}_${new Date().toISOString().split('T')[0]}`}
              title="Legacy Incentive Report"
              type="legacy"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">From Month</label>
            <input
              type="month"
              value={fromMonth}
              onChange={(e) => setFromMonth(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">To Month</label>
            <input
              type="month"
              value={toMonth}
              onChange={(e) => setToMonth(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={clearFilters}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Clear Filters
            </button>
          </div>
          
          <div className="text-sm text-gray-600">
            <div>Showing: {filteredIncentives.length} of {incentives.length} records</div>
            {(fromMonth || toMonth) && (
              <div className="text-blue-600 font-medium">
                {fromMonth ? formatMonth(fromMonth) : 'Start'} to {toMonth ? formatMonth(toMonth) : 'End'}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 text-sm font-medium">Total Incentives</p>
              <p className="text-2xl font-bold text-blue-900">{formatCurrencyForReport(totalIncentives)}</p>
              <p className="text-sm text-blue-700 mt-1">
                {(fromMonth || toMonth) ? 'Filtered Period' : 'All Time'}
              </p>
            </div>
            <DollarSign className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg border border-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-600 text-sm font-medium">Active Coordinators</p>
              <p className="text-2xl font-bold text-green-900">{uniqueCoordinators}</p>
              <p className="text-sm text-green-700 mt-1">
                {(fromMonth || toMonth) ? 'In Period' : 'Total'}
              </p>
            </div>
            <Users className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-600 text-sm font-medium">Active Candidates</p>
              <p className="text-2xl font-bold text-purple-900">{uniqueCandidates}</p>
              <p className="text-sm text-purple-700 mt-1">
                {(fromMonth || toMonth) ? 'In Period' : 'Total'}
              </p>
            </div>
            <TrendingUp className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Monthly Summary */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Monthly Incentive Summary
            {(fromMonth || toMonth) && (
              <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                Filtered
              </span>
            )}
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Month
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total Incentive
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Coordinators
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Candidates
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {monthlyData.map((month, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{formatMonth(month.month)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-lg font-semibold text-green-600">
                      {formatCurrencyForReport(month.totalIncentive)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                    {month.coordinatorCount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                    {month.candidateCount}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Person-wise Summary */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Person-wise Incentive Summary
            {(fromMonth || toMonth) && (
              <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                Filtered
              </span>
            )}
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Coordinator
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total Incentive
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Candidates
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Months
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {summaryData
                .sort((a, b) => b.totalIncentive - a.totalIncentive)
                .map((person, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{person.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                      {capitalizeFirstLetter(getCordinatorType(person.type)?.replace(/([A-Z])/g, ' $1').trim() || '')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-lg font-semibold text-green-600">
                      {formatCurrencyForReport(person.totalIncentive)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                    {person.candidateCount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                    {person.monthCount}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed Breakdown - Show only if preview is enabled */}
      {showPreview && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Eye className="w-5 h-5 mr-2" />
              Detailed Incentive Breakdown
              {(fromMonth || toMonth) && (
                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                  Filtered
                </span>
              )}
            </h3>
            <p className="text-sm text-gray-500 mt-1">
              Showing {filteredIncentives.length} records
            </p>
          </div>
          <div className="overflow-x-auto max-h-96">
            <table className="w-full">
              <thead className="bg-gray-50 sticky top-0">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Coordinator
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Candidate
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Month
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Hours/Placements
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Margin/Finder Fees
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Incentive
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredIncentives
                  .sort((a, b) => b.month.localeCompare(a.month))
                  .map((incentive, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{incentive.coordinatorName}</div>
                      <div className="text-sm text-gray-500 capitalize">
                        {capitalizeFirstLetter(getCordinatorType(incentive.coordinatorType)?.replace(/([A-Z])/g, ' $1').trim() || '')}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900">{incentive.candidateName}</div>
                      <div className="text-sm text-gray-500">{incentive.candidateId}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                      {formatMonth(incentive.month)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                      {incentive.isFullTime ? (incentive.placementCount || 1) : incentive.hoursWorked}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                      {incentive.isFullTime 
                        ? (incentive.finderFees ? `$${incentive.finderFees.toFixed(2)}` : 'N/A')
                        : `$${incentive.margin.toFixed(2)}`
                      }
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-semibold text-green-600">
                        {formatCurrencyForReport(incentive.incentiveAmount)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        incentive.isFullTime
                          ? 'bg-purple-100 text-purple-800'
                          : incentive.isRecurring 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-orange-100 text-orange-800'
                      }`}>
                        {incentive.isFullTime ? 'Full-time' : (incentive.isRecurring ? 'Recurring' : 'One-time')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
import axiosClient from './axiosClient';
import { Coordinator } from '../types';

export interface CoordinatorPayload {
  name: string;
  email: string;
  location: string;
}

export interface UpdateCoordinatorPayload {
  id: string;
  name: string;
  email: string;
  location: string;
}

export async function createCoordinator(payload: CoordinatorPayload) {
  const response = await axiosClient.post('/coordinators', payload);
  return response.data;
}

export async function getCoordinators(): Promise<Coordinator[]> {
  const response = await axiosClient.get('/coordinators/list');
  return response.data;
}

export async function updateCoordinator(payload: UpdateCoordinatorPayload) {
  const response = await axiosClient.put(`/coordinators/${payload.id}`, payload);
  return response.data;
}

export async function deleteCoordinator(id: string) {
  const response = await axiosClient.delete(`/coordinators/${id}`);
  console.log("response", response)
  return response.data;
} 
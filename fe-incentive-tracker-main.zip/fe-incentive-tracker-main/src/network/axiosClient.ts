
import axios from 'axios';

const axiosClient = axios.create({
  baseURL: 'http://incapi.amptech.corp/api', 
  // baseURL: 'http://localhost:8080/api',
});

// Add a request interceptor to include token from localStorage
axiosClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers = config.headers || {};
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default axiosClient;
export interface Candidate {
  id?: string;
  candidateId: string;
  candidateName: string;
  clientName: string;
  contractType: 'C2C' | 'W2' | 'FULLTIME';
  startDate: string;
  endDate?: string;
  payRate: number;
  w2PayrollAdminTaxesPercentage: number;
  w2PayrollAdminTaxes: number; // Calculated: payRate * w2PayrollAdminTaxesPercentage
  w2C2COverheadCostPercentage: number;
  w2C2COverheadCost: number; // Calculated: payRate * w2C2COverheadCostPercentage
  healthBenefits: number;
  netPurchase: number; // Calculated: payRate + w2PayrollAdminTaxes + w2C2COverheadCost + healthBenefits
  billRate: number;
  mspFeesPercentage: number;
  mspFeesDollar: number; // Calculated: billRate * mspFeesPercentage
  netBillRate: number; // Calculated: billRate - mspFeesDollar
  margin: number; // Calculated: netBillRate - netPurchase
  // Full-time specific fields
  finderFees?: number; // Only for Fulltime contracts
  crm?: Coordinator;
  lead?: Coordinator;
  manager?: Coordinator;
  seniorManager?: Coordinator;
  assoDirector?: Coordinator;
  centerHead?: Coordinator;
  recruiter?: Coordinator;
  marginRevisions?: MarginRevision[];
}

export interface MarginRevision {
  id: string;
  candidateId: string;
  effectiveDate: string; // YYYY-MM-DD format in EST
  contractType?: 'C2C' | 'W2' | 'FULLTIME'; // Contract type can also be revised
  payRate?: number;
  w2PayrollAdminTaxesPercentage?: number;
  w2C2COverheadCostPercentage?: number;
  healthBenefits?: number;
  billRate?: number;
  mspFeesPercentage?: number;
  finderFees?: number; // For full-time contracts
  // Calculated fields for this revision
  w2PayrollAdminTaxes: number;
  w2C2COverheadCost: number;
  netPurchase: number;
  mspFeesDollar: number;
  netBillRate: number;
  margin: number;
  reason?: string;
  createdAt: string;
  createdBy?: string;
}

export interface MonthlyHours {
  candidateId: string;
  month: string; // YYYY-MM format
  hoursWorked: number;
  isRetroactive?: boolean; // Flag to indicate if this was added retroactively
}

export interface IncentiveCalculation {
  coordinatorName: string;
  coordinatorType: 'recruiter' | 'crm' | 'teamLead' | 'manager' | 'seniorManager' | 'assoDirector' | 'centerHead';
  candidateId: string;
  candidateName: string;
  month: string;
  hoursWorked: number;
  margin: number;
  incentiveAmount: number;
  isRecurring: boolean;
  isOneTime: boolean;
  isFullTime?: boolean;
  finderFees?: number;
  placementCount?: number; // For full-time placements in the month
  notes?: string;
}

export interface IncentiveAdjustment {
  id: string;
  coordinatorName: string;
  coordinatorType: string;
  candidateId: string;
  candidateName: string;
  affectedMonth: string;
  originalIncentive: number;
  revisedIncentive: number;
  adjustmentAmount: number; // Positive = additional payment, Negative = overpayment
  adjustmentType: 'excess' | 'shortfall';
  marginRevisionId: string;
  createdAt: string;
  processedInCycle?: string;
}

export interface IncentiveTier {
  from: number;
  to: number;
  amount: number;
}

export interface Coordinator {
  id: string;
  name: string;
  email: string;
  location: string;
  createdAt: string;
}

export interface IncentiveCycle {
  id: string;
  month: string; // YYYY-MM format
  type: 'regular' | 'additional'; // Regular monthly or additional mid-month cycle
  status: 'draft' | 'calculating' | 'calculated' | 'approved' | 'cancelled'|'CALCULATED' | "APPROVED";
  startedAt: string;
  calculatedAt?: string;
  approvedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
  monthlyHours: MonthlyHours[];
  incentiveCalculations: IncentiveCalculation[];
  incentiveAdjustments?: IncentiveAdjustment[];
  coordinatorReports?: CoordinatorReport[];
  notes?: string;
  createdBy?: string;
}

export interface CoordinatorReport {
  coordinatorName: string;
  coordinatorEmail: string;
  coordinatorLocation: string;
  totalIncentive: number;
  adjustmentAmount?: number;
  placements: {
    candidateId: string;
    candidateName: string;
    clientName: string;
    contractType: string;
    margin: number;
    hoursWorked: number;
    incentiveAmount: number;
    incentiveType: 'recurring' | 'one-time' | 'full-time';
    role: string;
    finderFees?: number;
  }[];
  adjustments?: {
    candidateId: string;
    candidateName: string;
    affectedMonth: string;
    adjustmentAmount: number;
    adjustmentType: 'excess' | 'shortfall';
    reason: string;
  }[];
  sentAt?: string;
}

export interface RetroactiveIncentive {
  candidateId: string;
  candidateName: string;
  month: string;
  reason: string;
  addedToCycle?: string; // The cycle ID where this was eventually processed
}

export interface IncentiveReport {
  coordinatorName: string;
  coordinatorType: string;
  totalIncentive: number;
  details: {
    candidateId: string;
    candidateName: string;
    month: string;
    margin: number;
    hoursWorked: number;
    incentiveAmount: number;
    incentiveType: 'recurring' | 'one-time' | 'full-time';
    finderFees?: number;
  }[];
}

export const RECRUITER_INCENTIVE_TIERS: IncentiveTier[] = [
  { from: 1.00, to: 2.00, amount: 500 },
  { from: 2.01, to: 4.00, amount: 1000 },
  { from: 4.01, to: 6.00, amount: 1500 },
  { from: 6.01, to: 8.00, amount: 2000 },
  { from: 8.01, to: 10.00, amount: 2500 },
  { from: 10.01, to: 15.00, amount: 3500 },
  { from: 15.01, to: 20.00, amount: 4000 },
  { from: 20.01, to: 30.00, amount: 4500 },
  { from: 30.01, to: 40.00, amount: 7000 },
  { from: 40.01, to: 50.00, amount: 10000 }
];

export const ONE_TIME_INCENTIVES = {
  crm: 1000,
  manager: 1500,
  seniorManager: 1500,
  assoDirector: 1750,
  centerHead: 1500
};

// Full-time incentive structures
export const FULLTIME_RECRUITER_INCENTIVES = {
  lowFinderFee: { // Below $4,500
    1: 15000,
    2: 18000,
    3: 20000
  },
  highFinderFee: { // Above $4,500
    1: 20000,
    2: 25000,
    3: 30000
  }
};

export const FULLTIME_OTHER_INCENTIVES = {
  teamLead: 1000,
  manager: 1500,
  crm: 1500,
  assoDirector: 4000,
  centerHead: 4000
};

export const TEAM_LEAD_INCENTIVE = 250;
export const LOW_MARGIN_ONE_TIME_INCENTIVE = 2000; // For margin <= $0.99

// User and Authentication types
export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
  permissions: UserPermission[];
  createdAt: string;
  createdBy?: string;
  isActive: boolean;
}

// [
//   "START_INCENTIVE_CYCLE",
//   "LEGACY_REPORTS",
//   "ADD_CANDIDATES",
//   "CALCULATE_INCENTIVE_CYCLE",
//   "COORDINATORS",
//   "ADD_HOURS",
//   "MARGIN_REVISION",
//   "APPROVE_INCENTIVE_CYCLE",
//   "DOWNLOAD",
//   "CUSTOM_REPORTS",
//   "DELETE_APPROVED_CYCLES"
// ]

export type UserPermission = 
  | 'ADD_CANDIDATES'
  | 'MARGIN_REVISION'
  | 'COORDINATORS'
  | 'START_INCENTIVE_CYCLE'
  | 'CALCULATE_INCENTIVE_CYCLE'
  | 'ADD_HOURS'
  | 'APPROVE_INCENTIVE_CYCLE'
  | 'CUSTOM_REPORTS'
  | 'LEGACY_REPORTS'
  | 'DOWNLOAD'
  | 'USER_MANAGEMENT'
  | 'DELETE_APPROVED_CYCLES';

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
}

export const DEFAULT_USER_PERMISSIONS: UserPermission[] = [
  'ADD_CANDIDATES',
  "START_INCENTIVE_CYCLE",
  "LEGACY_REPORTS",
  "ADD_CANDIDATES",
  "CALCULATE_INCENTIVE_CYCLE",
  "COORDINATORS",
  "ADD_HOURS",
  "MARGIN_REVISION",
  "APPROVE_INCENTIVE_CYCLE",
  "DOWNLOAD",
  "CUSTOM_REPORTS",
  "DELETE_APPROVED_CYCLES"
];



export const ADMIN_PERMISSIONS: UserPermission[] = [
  ...DEFAULT_USER_PERMISSIONS,
  'USER_MANAGEMENT',
  'DELETE_APPROVED_CYCLES'
];

export interface CycleHours {
  candidateId: string;
  month: string;
  hoursWorked: number;
  isRetroactive?: boolean;
  isFullTime?: boolean;
  isOneTime?: boolean;
  isRecurring?: boolean;
}

export interface IncentiveData {
  candidateId: string;
  candidateName: string;
  coordinatorName: string;
  coordinatorType: string;
  amount: number;
  isOneTime: boolean;
  reason: string;
}

export interface CoordinatorIncentive {
  coordinatorName: string;
  coordinatorType: string;
  totalIncentive: number;
  details: {
    candidateId: string;
    candidateName: string;
    month: string;
    margin: number;
  };
}
// import { BrowserRouter } from "react-router-dom";
// import "./App.css";
// import Router from "./routers";
// import "react-toastify/dist/ReactToastify.css";

import { BrowserRouter } from "react-router-dom";
import Router from "./routers";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Router />
      </BrowserRouter>
    </div>
  );
}

export default App;
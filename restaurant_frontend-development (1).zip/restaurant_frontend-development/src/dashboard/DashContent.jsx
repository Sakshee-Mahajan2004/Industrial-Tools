import { Typography } from '@material-tailwind/react'
import React from 'react'

const DashContent = () => {
  return (
    <div>DashContent
        
    </div>
  )
}

export default DashContent
import React, { useState } from 'react';
import img1 from "../assets/room1.jpg";
import img2 from "../assets/room2.jpg";
import img3 from "../assets/room3.jpg";
import img4 from "../assets/room4.jpg";
import img5 from "../assets/room5.jpg";
import img6 from "../assets/room6.jpg";
import img7 from "../assets/room7.jpg";
import img8 from "../assets/room8.jpg";
import img9 from "../assets/room9.jpg";

const hotelImages = [img1, img2, img3, img4, img5, img6, img7, img8, img9];

const ViewDetailsModal = ({ hotel, onClose }) => {
  const [showAllImages, setShowAllImages] = useState(false);

  if (!hotel) return null;

  const handleShowAllImages = () => {
    setShowAllImages(true);
  };

  const handleCloseAllImages = () => {
    setShowAllImages(false);
  };

  return (
    <div className="fixed inset-0 bg-gray-500/75 z-50">
      <div className="fixed inset-0 z-10 flex items-center justify-center">
        <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-6xl h-150 overflow-y-auto relative">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Hotel Details</h3>
          <div className="flex">
            <div className="w-1/3 flex flex-col items-center">
              <div className="mb-4">
                <img src={hotelImages[0]} alt="Large Hotel" className="w-full h-60 object-cover rounded" />
              </div>
              <div className="flex space-x-1 ">
                {hotelImages.slice(1, 3).map((image, index) => (
                  <img key={index} src={image} alt={`Hotel Image ${index + 1}`} className="w-36 h-30 object-cover rounded" />
                ))}
              </div>
              {hotelImages.length > 3 && (
                <button
                  onClick={handleShowAllImages}
                  className="mt-2 text-blue-500 underline "
                >
                  See All
                </button>
              )}
            </div>
            <div className="w-2/3 pl-6">
              <div className="border p-4 mb-4">
                <div className="mb-4">
                  <strong>Hotel Name:</strong> {hotel.hotelName}
                </div>
                <div className="mb-4">
                  <strong>Owner Name:</strong> {hotel.hotelOwner?.firstName} {hotel.hotelOwner?.lastName}
                </div>
                <div className="mb-4">
                  <strong>Address:</strong> {hotel.hotelAdd}
                </div>
                <div className="mb-4">
                  <strong>Description:</strong> {hotel.hotelDes}
                </div>
              </div>
              <div className="border p-4">
                <div className="mb-4">
                  <strong>Rooms:</strong> {hotel.hotelRooms}
                </div>
                <div className="mb-4">
                  <strong>Amenities:</strong> {hotel.amenities?.map(a => a.amenityName).join(', ')}
                </div>
                <div className="mb-4">
                  <strong>Ratings:</strong> {hotel.ratings}
                </div>
                <div className="mb-4">
                  <strong>Payment Transactions:</strong> {hotel.paymentTransactions}
                </div>
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-4">
            <button
              onClick={onClose}
              className="bg-gray-300 text-gray-800 px-4 py-2 rounded mt-10"
            >
              Close
            </button>
          </div>
        </div>
      </div>

      {showAllImages && (
        <div className="fixed inset-0 bg-gray-500/75 z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-140 max-w-6xl">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">All Images</h3>
            <div className="grid grid-cols-3 gap-2">
              {hotelImages.map((image, index) => (
                <img key={index} src={image} alt={`Hotel Image ${index + 1}`} className="w-full h-35 object-cover rounded" />
              ))}
            </div>
            <div className="flex justify-end mt-4">
              <button
                onClick={handleCloseAllImages}
                className="bg-gray-300 text-gray-800 px-4 py-2 rounded"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ViewDetailsModal;
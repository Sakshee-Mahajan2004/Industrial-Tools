import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers, registerOwner } from '../app/userApi.js';
import { setPage, setPageSize } from '../redux/userSlice.jsx';
import GridTable from "../components/GridTable.jsx";

const Table = () => {
  const dispatch = useDispatch();
  const { data: users, totalPages, totalUsersCount, currentPage, pageSize, loading } = useSelector((state) => state.user);

  const [modalOpen, setModalOpen] = useState(false);
  const [newUser, setNewUser] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    mobile: '',
    role: 'hotel-owner',
  });

  useEffect(() => {

    dispatch(fetchUsers({ page: currentPage, size: pageSize }));
  }, [dispatch, currentPage, pageSize]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const userToSubmit = {
      ...newUser,
      role: { roleId: 1002 },
    };


    dispatch(registerOwner(userToSubmit))
      .unwrap()
      .then((response) => {
        dispatch(fetchUsers({ page: currentPage, size: pageSize })).unwrap();
        setNewUser({
          firstName: '',
          lastName: '',
          email: '',
          password: '',
          mobile: '',
          role: 'hotel-owner',
        });
        setModalOpen(false);
      })
      .catch((error) => {

      });
  };

  const modifiedUsers = users.map((user) => ({
    ...user,
    id: user.userId,
    role: user.role?.roleName || 'N/A',
  }));

  const columns = [
    { field: "id", headerName: "ID", width: 150 },
    { field: "firstName", headerName: "First Name", width: 250 },
    { field: "lastName", headerName: "Last Name", width: 250 },
    { field: "email", headerName: "Email", width: 250 },
    { field: "mobile", headerName: "Phone No", width: 250 },
    { field: "role", headerName: "Role", width: 250 },
  ];

  const handlePageSizeChange = (newPageSize) => {

    dispatch(setPageSize(newPageSize));
  };

  const handlePageChange = (page) => {
    dispatch(setPage(page));
  };

  return (
    <>
      <div className="p-4">
        {loading ? (
          <div>Loading...</div>
        ) : (
          <GridTable
            rowData={modifiedUsers}
            columnData={columns}
            actions={["DELETE", "EDIT", "VIEW"]}
            onClickAdd={() => setModalOpen(true)}
            onClick={() => setModalOpen(true)}
            hideAddButton={false}
            toolTipName={"Add Hotel Owner"}
            topActionButtonTitle="Add Hotel Owner"
            currentPage={currentPage}
            totalPages={totalPages}
            pageSize={pageSize}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            getRowId={(row) => row.userId}
          />
        )}
      </div>

      {modalOpen && (
        <div className="fixed inset-0 bg-gray-500/75 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg w-1/3">
            <h2 className="text-2xl font-semibold mb-4">Add New Hotel Owner</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="firstName" className="block text-sm text-gray-700">First Name</label>
                <input
                  id="firstName"
                  type="text"
                  value={newUser.firstName}
                  onChange={(e) => setNewUser({ ...newUser, firstName: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="lastName" className="block text-sm text-gray-700">Last Name</label>
                <input
                  id="lastName"
                  type="text"
                  value={newUser.lastName}
                  onChange={(e) => setNewUser({ ...newUser, lastName: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm text-gray-700">Email</label>
                <input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="mobile" className="block text-sm text-gray-700">Mobile</label>
                <input
                  id="mobile"
                  type="text"
                  value={newUser.mobile}
                  onChange={(e) => setNewUser({ ...newUser, mobile: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="password" className="block text-sm text-gray-700">Password</label>
                <input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                  Add User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default Table;
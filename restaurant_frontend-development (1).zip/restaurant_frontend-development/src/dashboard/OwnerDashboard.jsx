import React from 'react'

const OwnerDashboard = () => {
  return (
    <div>OwnerDashboard</div>
  )
}

export default OwnerDashboard
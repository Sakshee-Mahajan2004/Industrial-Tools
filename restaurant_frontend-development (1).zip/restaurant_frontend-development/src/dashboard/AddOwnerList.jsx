import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchHotelOwners } from "../app/hotelApi";
import InputField from "../components/InputField";

const AddOwnerList = ({ hotel, onSave, onCancel }) => {
  const dispatch = useDispatch();
  const { owners, loading, error } = useSelector((state) => state?.hotels);

  const [formData, setFormData] = useState({
    id: hotel?.id || "",
    name: hotel?.firstName || "",
    lastName: hotel?.lastName || "",
    email: hotel?.email || "",
    phoneNo: hotel?.mobile || "",
  });

  useEffect(() => {
    dispatch(fetchHotelOwners());
  }, [dispatch]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const isEditMode = hotel && hotel.id;

  return (
    <div className="relative z-10" role="dialog" aria-modal="true">
      <div
        className="fixed inset-0 bg-gray-200/50 transition-opacity"
        aria-hidden="true"
      ></div>
      <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
        <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
          <div className="relative transform overflow-hidden rounded-lg bg-[#5A2360] text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg">
              <div className="bg-[#5A2360] pt-5 pb-4 sm:p-6 sm:pb-4 rounded-t-lg">
                <h3
                  className="text-base font-semibold text-white text-center"
                  id="modal-title"
                >
                  {isEditMode ? "Edit Owner" : "Add Owner"}
                </h3>
              </div>
              <div className="px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <div className="mt-2">
                      {/* Name Field */}
                      <div className="mb-4">
                        <label
                          className="block text-gray-700 text-sm font-bold mb-2"
                          htmlFor="name"
                        >
                          Name
                        </label>
                        <InputField
                          type="text"
                          name="name"
                          placeholder="Name"
                          value={formData.name}
                          onChange={handleChange}
                          className={
                            "w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                          }
                        />
                      </div>

                      <div className="mb-4">
                        <label
                          className="block text-gray-700 text-sm font-bold mb-2"
                          htmlFor="name"
                        >
                          Last Name
                        </label>
                        <InputField
                          type="text"
                          name="lastName"
                          placeholder="Last Name"
                          value={formData.lastName}
                          onChange={handleChange}
                          className={
                            "w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                          }
                        />
                      </div>

                      {/* Phone Number Field */}
                      <div className="mb-4">
                        <label
                          className="block text-gray-700 text-sm font-bold mb-2"
                          htmlFor="phoneNo"
                        >
                          Phone No
                        </label>
                        <InputField
                          type="number"
                          name="phoneNo"
                          placeholder="Phone Number"
                          value={formData.phoneNo}
                          onChange={handleChange}
                          className={
                            "w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Save and Cancel Buttons */}
              <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                <button
                  type="submit"
                  className="inline-flex w-full justify-center rounded-md bg-[#5A2360] px-3 py-2 text-sm font-semibold text-white shadow-xs hover:bg-purple-600 sm:ml-3 sm:w-auto"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={onCancel}
                  className="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 ring-1 shadow-xs ring-gray-300 ring-inset hover:bg-gray-50 sm:mt-0 sm:w-auto"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddOwnerList;
 
import { configureStore } from "@reduxjs/toolkit";
import userSlice from "../redux/userSlice";
import hotelSlice from "../redux/hotelSlice";
import roomSlice from "../redux/roomSlice";
const store = configureStore({
  reducer: {
 
    user: userSlice,
    hotels: hotelSlice,
    rooms: roomSlice,
  
  },
});
 
export default store;
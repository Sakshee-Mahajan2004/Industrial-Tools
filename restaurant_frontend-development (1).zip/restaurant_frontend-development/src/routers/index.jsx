import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Login from '../pages/Login'
import Home from '../pages/Home'
import SignUp from '../pages/SignUp'
import ProtectedRoutes from './ProtectedRoutes'
import Dashboard from '../dashboard/Dashboard'
import HotelList from '../dashboard/HotelList'
import UserList from '../dashboard/UserList'
import AdminLayout from '../layout/AdminLayout'
import AppLayout from '../applayout/AppLayout'
import Adminprofile from '../dashboard/Adminprofile'
import Contact from '../pages/Contact'
import AboutUs from '../pages/AboutUs'
import Profile from '../pages/Profile'
import News from '../pages/News'
import { useSelector } from 'react-redux'
import NoPage from '../pages/NoPage'
import ForgotPassword from '../pages/ForgotPassword'
import VerifyEmailOtp from '../pages/VerifyEmailOtp'
import ResetPassword from '../pages/ResetPassword'
import Hotel from '../pages/Hotel'
import {ReviewBooking} from '../components/ReviewBooking'
import RoomDetails from '../components/RoomDetails'

function Router() {

    const { userInfo } = useSelector((state) => state.user)

    const roleId = userInfo?.role?.roleId
    return (
        <Routes>
            {userInfo == null &&

                <Route path="/" >
                    <Route index element={<Login />} />
                    <Route path="/signup" element={<SignUp />} />
                    <Route path='/forgot-password' element={<ForgotPassword />} />
                    <Route path='/verify-emailOtp' element={<VerifyEmailOtp />} />
                    <Route path='/reset-password' element={<ResetPassword />} />
                    <Route path="*" element={<NoPage />} />
                </Route>

            }

            {roleId === 1000 &&
                <Route path="/" element={<AppLayout />}>

                    <Route index element={
                        <ProtectedRoutes>
                            <Home />
                        </ProtectedRoutes>
                    } />
                    <Route path="contact" element={
                        <ProtectedRoutes>
                            <Contact />
                        </ProtectedRoutes>
                    } />
                    <Route path="room-details" element={
                        <ProtectedRoutes>
                            <RoomDetails />
                        </ProtectedRoutes>
                    } />
                    <Route path="about-us" element={
                        <ProtectedRoutes>
                            <AboutUs />
                        </ProtectedRoutes>
                    } />
                    <Route path="profile" element={
                        <ProtectedRoutes>
                            <Profile />
                        </ProtectedRoutes>
                    } />
                    <Route path="news" element={
                        <ProtectedRoutes>
                            <News />
                        </ProtectedRoutes>
                    } />
                    <Route index element={
                        <ProtectedRoutes>
                            <Home />
                        </ProtectedRoutes>
                    } />
                    <Route path="contact" element={
                        <ProtectedRoutes>
                            <Contact />
                        </ProtectedRoutes>
                    } />
                    <Route path="hotel" element={
                        <ProtectedRoutes>
                            <Hotel />
                        </ProtectedRoutes>
                    } />
                    <Route path="about-us" element={
                        <ProtectedRoutes>
                            <AboutUs />
                        </ProtectedRoutes>
                    } />
                    <Route path="profile" element={
                        <ProtectedRoutes>
                            <Profile />
                        </ProtectedRoutes>
                    } />
                    <Route path="news" element={
                        <ProtectedRoutes>
                            <News />
                        </ProtectedRoutes>
                    } />
                    <Route path="review-booking" element={
                        <ProtectedRoutes>
                            <ReviewBooking />
                        </ProtectedRoutes>
                    } />

                    <Route path="*" element={<NoPage />} />
                </Route>
            }

            {roleId === 1001 &&
                <Route path="/" element={<AdminLayout />}>
                    <Route index element={
                        <Dashboard />
                    } />
                    <Route path="hotel-list" element={
                        <HotelList />
                    } />
                    <Route path="user-list" element={
                        <UserList />
                    } />
                    <Route path="admin-profile" element={
                        <Adminprofile />
                    } />
                    <Route path="*" element={<NoPage />} />
                </Route>
            }

            {roleId === 1002 &&
                <Route path="/" element={<AdminLayout />}>
                    <Route index element={
                        <Dashboard />
                    } />
                    <Route path="hotel-list" element={
                        <HotelList />
                    } />
                    <Route path="*" element={<NoPage />} />
                </Route>
            }

        </Routes>
    )
}

export default Router;

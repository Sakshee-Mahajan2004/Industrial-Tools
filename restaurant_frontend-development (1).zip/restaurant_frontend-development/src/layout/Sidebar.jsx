import { Link, useLocation } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChartPie,
  faUsers,
  faBuilding,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";

const SidebarItem = ({ href, label, isCollapsed, icon }) => {
  const location = useLocation();
  const isActive = location.pathname === href;

  return (
    <li className="group">
      <Link
        to={href}
        className={`flex items-center py-3 px-4 hover:bg-white transition-all duration-300 ${
          isActive ? "bg-white border-l-4 border-black-500" : ""
        }`}
      >
        <FontAwesomeIcon icon={icon} className="w-5 h-5" />
        <span
          className={`text-black text-base font-medium ml-4 ${
            isCollapsed ? "hidden" : "block"
          }`}
        >
          {label}
        </span>
      </Link>
    </li>
  );
};

const Sidebar = ({ role, isCollapsed, toggleSidebar }) => {

  const {userInfo}=useSelector((state)=>state.user)
  const [menuList,setMenuList]=useState([])
  // Define sidebar items based on role.
  
  // const roleId=userInfo?.role?.roleId

  useEffect(()=>{
    let sidebarItems = [];
    if (userInfo?.role?.roleId === 1001) {
      sidebarItems = [
        { href: "/", label: "Dashboard", icon: faChartPie },
        { href: "/hotel-list", label: "Hotel List", icon: faBuilding },
        { href: "/user-list", label: "User List", icon: faUsers },
        { href: "/admin-profile", label: "Profile", icon: faUser },
      ];
    } else if (userInfo?.role?.roleId === 1002) {
      sidebarItems = [
        { href: "/owner", label: "Dashboard", icon: faChartPie },
        { href: "/owner/properties", label: "My Properties", icon: faBuilding },
        { href: "/owner/bookings", label: "Bookings", icon: faUsers },
      ];
    }
    setMenuList(sidebarItems)
  },[userInfo])

  return (
    <aside
      className={`${
        isCollapsed ? "w-14" : "w-64"
      } h-full bg-black/5 transition-all duration-300 ease-in-out relative`}
    >
      
      {/* Sidebar Navigation */}
      <nav className="mt-8">
        <ul>
          {menuList.map((item) => (
            <SidebarItem
              key={item.href}
              href={item.href}
              label={item.label}
              isCollapsed={isCollapsed}
              icon={item.icon}
            />
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
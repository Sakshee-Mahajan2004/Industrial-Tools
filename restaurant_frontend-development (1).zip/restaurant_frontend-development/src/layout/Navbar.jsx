import { useState, useEffect, useRef } from "react";
import AppButton from "../components/AppButton";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { KEY } from "../utils/Constant";
import { logout } from "../redux/userSlice";
const Navbar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const [filteredData, setFilteredData] = useState([]);

  const dropdownRef = useRef(null);
  const buttonRef = useRef(null);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleLogout = (e) => {
    e.preventDefault();

    localStorage.removeItem(KEY.USER_INFO);
    localStorage.removeItem(KEY.TOKEN);
    dispatch(logout());

    navigate("/", { replace: true });

  };

  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target)
      ) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <header className="w-full bg-white dark:bg-gray-900 shadow p-4 sticky z-1">
      <nav className="flex justify-between items-center">
        <div className="text-2xl font-bold flex gap-2 items-center">
          Admin Dashboard
        </div>
        <div className="flex items-center space-x-6">
          <AppButton
            onClick={handleLogout}
            className="bg-fuchsia-950 text-white py-2 px-6 rounded-lg font-semibold hover:bg-[#d6baa0]"
            title="LOGOUT"
          />
        </div>
      </nav>
      <div className="mt-4">
        <ul>
          {filteredData.length > 0 ? (
            filteredData.map((item) => (
              <li
                key={item.id}
                className="py-2"
              >{`${item.name} (${item.role})`}</li>
            ))
          ) : (
            <li></li>
          )}
        </ul>
      </div>
    </header>
  );
};

export default Navbar;

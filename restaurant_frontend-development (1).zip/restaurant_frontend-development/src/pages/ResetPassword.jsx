import React from 'react'
import { Button } from "@material-tailwind/react";
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import InputField from '../components/InputField';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';

const ResetPassword = () => {
    // const [otp, setOtp] = useState("");
    const [newpassword, setNewPassword] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState('');
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const location = useLocation();
    const email = location.state?.email;

    console.log(email, "email value entered by user at forgot password");

    const submit = (e) => {
        e.preventDefault();

    }
    console.log(error);
    return (
        <div className="container mx-auto flex justify-center items-center min-h-screen">
            <div className="bg-white p-6 shadow-lg rounded-lg" style={{ width: "350px" }}>
                <h3 className="text-center text-xl font-semibold mb-4">Update Password</h3>
                <form onSubmit={submit}>
                    <div className='mb-4'>
                        <InputField
                            value={newpassword}
                            onChange={(e) => {
                                setError('');
                                setNewPassword(e.target.value);

                            }}
                            placeholder="New Password"
                            name="password"
                            error={error}
                            className={"mb-2"}

                        />

                    </div>
                    <div className='mb-4'>
                        <InputField
                            value={password}
                            onChange={(e) => {
                                setError('');
                                setPassword(e.target.value);

                            }}
                            placeholder="Confirmed Password"
                            name="password"
                            error={error}
                            className={"mb-2"}

                        />

                    </div>

                    <Button
                        type="submit"
                        className="w-full py-2 px-4 bg-[#5A2360] text-white rounded-md hover:bg-blue-600"
                    >
                        Reset Password
                    </Button>
                </form>

            </div>
        </div>
    );

}

export default ResetPassword;



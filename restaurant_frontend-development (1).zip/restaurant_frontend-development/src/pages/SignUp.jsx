import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { registerUser } from "../app/userApi";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { resetMessage } from "../redux/userSlice";
import InputField from "../components/InputField";
import AppButton from "../components/AppButton";

export default function SignUp() {
    const { loading, regResponse, message } = useSelector(
        (state) => state.user
    );

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [errors, setErrors] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        mobile: ""
    });

    const [formData, setFormData] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        mobile: "",
    });

    useEffect(() => {
        if (message && !loading && !regResponse) {
            toast.error(message);
        } else if (message && !loading && regResponse) {
            toast.success(message);
            dispatch(resetMessage());
            setTimeout(() => {
                navigate("/", { replace: true });
            }, 1000);
        }
    }, [dispatch, loading, message, regResponse, navigate]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const submit = (e) => {
        e.preventDefault();
        setErrors({ firstName: "", lastName: "", email: "", password: "", mobile: "" });

        let hasError = false;
        let newErrors = { firstName: "", lastName: "", email: "", password: "", mobile: "" };

        if (!formData.firstName.trim()) {
            newErrors.firstName = "First name is required.";
            hasError = true;
        }

        if (!formData.lastName.trim()) {
            newErrors.lastName = "Last name is required.";
            hasError = true;
        }
        if (!formData.email.trim()) {
            newErrors.email = "Email is required.";
            hasError = true;
        }

        if (!formData.password.trim() || formData.password.length < 6) {
            newErrors.password = "Password must be at least 6 characters.";
            hasError = true;
        }

        if (!formData.mobile.trim() || formData.mobile.length !== 10) {
            newErrors.mobile = "Mobile should be up to 10 digits.";
            hasError = true;
        }

        setErrors(newErrors);

        if (!hasError) {

            dispatch(registerUser(formData));
        }
    };

    return (
        <div className="container mx-auto flex justify-center items-center min-h-screen">
            <div className="bg-white p-6 shadow-lg rounded-lg" style={{ width: "350px" }}>
                <h3 className="text-center text-xl font-semibold">Sign Up</h3>

                <form onSubmit={submit}>
                    <InputField
                        value={formData.firstName}
                        className="mt-5 block w-full p-2 !border !border-gray-300 rounded  focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50 "
                        onChange={(e) => {
                            handleChange(e);
                            setErrors({ ...errors, firstName: "" });
                        }}
                        placeholder="Enter First Name"
                        name="firstName"
                        error={errors.firstName}
                    />
                    {errors.firstName && <p className="text-red-500 text-sm">{errors.firstName}</p>}

                    <InputField
                        value={formData.lastName}
                        className="mt-5 block w-full p-2 !border !border-gray-300 rounded  focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50 "
                        onChange={(e) => {
                            handleChange(e);
                            setErrors({ ...errors, lastName: "" });
                        }}
                        placeholder="Enter Last Name"
                        name="lastName"
                        error={errors.lastName}
                    />
                    {errors.lastName && <p className="text-red-500 text-sm">{errors.lastName}</p>}

                    <InputField
                        value={formData.email}
                        className="mt-5 block w-full p-2 !border !border-gray-300 rounded  focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50 "
                        onChange={(e) => {
                            handleChange(e);
                            setErrors({ ...errors, email: "" });
                        }}
                        placeholder="Enter Email"
                        name="email"
                        error={errors.email}
                        type="email"
                    />
                    {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}


                    <InputField
                        value={formData.password}
                        className="mt-5 block w-full p-2 !border !border-gray-300 rounded  focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50 "
                        onChange={(e) => {
                            handleChange(e);
                            setErrors({ ...errors, password: "" });
                        }}
                        placeholder="Enter Password"
                        name="password"
                        error={errors.password}
                        type="password"
                    />
                    {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}


                    <InputField
                        value={formData.mobile}
                        className="mt-5 block w-full p-2 !border !border-gray-300 rounded  focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50 "
                        onChange={(e) => {
                            handleChange(e);
                            setErrors({ ...errors, mobile: "" });
                        }}
                        placeholder="Enter Mobile"
                        name="mobile"
                        error={errors.mobile}
                        type="tel" />
                    {errors.mobile && <p className="text-red-500 text-sm">{errors.mobile}</p>}

                    <AppButton
                        type="submit"
                        title="SignUp"
                        className="mt-5 w-full py-2 px-4 bg-[#5A2360] text-white rounded-md hover:bg-blue-600"
                    />
                </form>

                <p className="text-center mt-4 text-sm">
                    Already have an account?{" "}
                    <a href="/" className="text-blue-500 hover:text-blue-700">
                        Login
                    </a>
                    
                    
                </p>
                
            </div>
            <ToastContainer position="top-center" autoClose={3000} hideProgressBar newestOnTop />
        </div>
    );
}

import React from 'react'
import { Button } from "@material-tailwind/react";
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import InputField from '../components/InputField';
//import { verifyEmail } from '../app/userApi';
import { useNavigate } from 'react-router-dom';
import VerifyEmailOtp from './VerifyEmailOtp';

const ForgotPassword = () => {
    const [email, setEmail] = useState("");
   
    const [error, setError] = useState('');
    // const dispatch = useDispatch();
    const navigate = useNavigate();

    const submit = (e) => {
        e.preventDefault();
        if (email && !error) {
            console.log(email);
            // dispatch(verifyEmail(email));
            navigate(`/Verify-EmailOtp`, { state: { email } });


        } else {
            setError("Email is required");
        }
    }
    console.log(error);
    return (
        <div className="container mx-auto flex justify-center items-center min-h-screen">
            <div className="bg-white p-6 shadow-lg rounded-lg" style={{ width: "350px" }}>
                <h3 className="text-center text-xl font-semibold mb-4">Forgot Password ?</h3>

                <form onSubmit={submit}>
                    <div className='mb-4'>
                        <InputField
                            value={email}
                            onChange={(e) => {
                                setError('');
                                setEmail(e.target.value);

                            }}
                            placeholder="Enter email"
                            name="email"
                            error={error}
                            className={"mb-2"}

                        />

                    </div>

                    <Button
                        type="submit"
                        className="w-full py-2 px-4 bg-[#5A2360] text-white rounded-md hover:bg-blue-600"
                    >
                        SEND OTP
                    </Button>
                </form>

            </div>
        </div>
    );

}

export default ForgotPassword



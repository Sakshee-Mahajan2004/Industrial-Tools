import React from "react";

const formatDate = (date) => {
  if (!date) return "Select Date";
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

const DatePicker = ({ label, date, onClick, className }) => {
  return (
    <div className={className} onClick={onClick}>
      <label>{label}</label>
      <input
        type="text"
        value={formatDate(date)}
        readOnly
        className="w-full bg-transparent text-white text-center "
      />
    </div>
  );
};

export default DatePicker;

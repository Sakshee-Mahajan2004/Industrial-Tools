import React from "react";
import { FaMapMarkerAlt } from "react-icons/fa"; // Importing the map marker icon from react-icons

export const Map = () => {
  return (
    <div>
      <div className="bg-white  overflow-hidden max-w-lg mx-auto mt-6">
        <div className="flex flex-col space-y-4 border border-gray-200 rounded-2xl">
          <div className="flex flex-row justify-evenly ">
            <div className="bg-blue-500 text-white text-2xl font-semibold py-2 px-4 rounded-lg mt-1">
              3.9
            </div>
            <p className="text-sm text-gray-500 mt-2">
              Very Good (2040 RATINGS)
            </p>
            <button className="text-sm text-blue-500 mt-2 font-bold">
              All Reviews
            </button>
          </div>

          <div className="flex flex-row justify-evenly">
            {/* Map icon with background image */}
            <div
              className="h-12 w-16 flex items-center justify-center bg-blue-500 rounded-lg "
              style={{
                backgroundImage: "url('src/assets/map.png')", // Replace with your image URL
                backgroundSize: "cover", // Makes sure the image covers the entire div
                backgroundPosition: "center", // Centers the image
              }}
            >
              <FaMapMarkerAlt className="text-blue-500 text-3xl" />
            </div>

            <div className="flex flex-col">
              <p className="text-xl font-semibold">Anjuna</p>
              <p className="text-sm text-gray-500 mt-2">
                2.6 km drive to Anjuna Beach
              </p>
            </div>
            <button className="text-sm text-blue-500 mt-2 font-bold">
              See on Map
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Map;

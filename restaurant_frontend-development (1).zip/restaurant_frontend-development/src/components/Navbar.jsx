import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { KEY } from "../utils/Constant";
import AppButton from "./AppButton";
import image from "../assets/hotelLogo.png";
import "./Navbar.css";
import { logout } from "../redux/userSlice";

const Navbar = () => {
  const navigate = useNavigate();

  const dispatch = useDispatch();

  const handleLogout = (e) => {
    e.preventDefault();

    localStorage.removeItem(KEY.USER_INFO);
    localStorage.removeItem(KEY.TOKEN);
    dispatch(logout());

    navigate("/", { replace: true });

  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between flex-wrap bg-[#081123] p-0">
      <div className="flex flex-col items-center flex-shrink-0 text-white mr-6">
        <img src={image} alt="hotelLogo" className="h-[11vh]" />
      </div>

      <div className="block lg:hidden">
        <button className="flex items-center px-3 py-2 border rounded text-teal-200 border-teal-400 hover:text-white hover:border-white">
          <svg
            className="fill-current h-3 w-3"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <title>Menu</title>
            <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
          </svg>
        </button>
      </div>

      <div className="w-full block flex-grow lg:flex lg:items-center lg:w-auto">
        <div className="flex w-full h-full lg:flex-grow items-center lg:w-auto">
          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <NavLink
              to="/"
              className={({ isActive }) =>
                isActive
                  ? "w-full text-center px-2 py-3 nav-link active-link"
                  : "w-full text-center px-2 py-3 nav-link"
              }
            >
              HOME
            </NavLink>
          </div>

          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <NavLink
              to="/about-us"
              className={({ isActive }) =>
                isActive
                  ? "w-full text-center px-2 py-3 nav-link active-link"
                  : "w-full text-center px-2 py-3 nav-link"
              }
            >
              ABOUT US
            </NavLink>
          </div>

          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <NavLink
              to="/hotel"
              className={({ isActive }) =>
                isActive
                  ? "w-full text-center px-2 py-3 nav-link active-link"
                  : "w-full text-center px-2 py-3 nav-link"
              }
            >
              HOTELS
            </NavLink>
          </div>

          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <NavLink
              to="/contact"
              className={({ isActive }) =>
                isActive
                  ? "w-full text-center px-2 py-3 nav-link active-link"
                  : "w-full text-center px-2 py-3 nav-link"
              }
            >
              CONTACT
            </NavLink>
          </div>

          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <NavLink
              to="/news"
              className={({ isActive }) =>
                isActive
                  ? "w-full text-center px-2 py-3 nav-link active-link"
                  : "w-full text-center px-2 py-3 nav-link"
              }
            >
              NEWS
            </NavLink>
          </div>

          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <NavLink
              to="/profile"
              className={({ isActive }) =>
                isActive
                  ? "w-full text-center px-2 py-3 nav-link active-link"
                  : "w-full text-center px-2 py-3 nav-link"
              }
            >
              PROFILE
            </NavLink>
          </div>

          <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <AppButton
              onClick={handleLogout}
              className="bg-fuchsia-950 text-white py-2 px-6 rounded-lg font-semibold hover:bg-[#d6baa0]"
              title="LOGOUT"
            />
          </div>

          <AppButton title="Book Now" className="w-35" />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

import React from "react";
import Price from "./Price";
import Image from "./Image";
import Amenity from "./Amenity";
import Map from "./Map";

export const RoomDetails = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-cover bg-center">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 bg-white shadow-md rounded-lg max-w-7xl w-full gap-2 p-4">
        {/* Image Component */}
        <div className="p-0">
          <Image />
        </div>

        {/* Price Component */}
        <div className="flex flex-col justify-start p-0 ">
          <Price />
        </div>

        {/* Amenity Component */}
        <div className="flex flex-col p-0">
          <Amenity />
        </div>

        {/* Map Component */}
        <div className="flex flex-col p-0">
          <Map />
        </div>
      </div>
    </div>
  );
};
export default RoomDetails;
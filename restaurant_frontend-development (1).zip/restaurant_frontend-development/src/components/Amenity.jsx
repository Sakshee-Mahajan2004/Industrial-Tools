import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getRooms } from "../redux/roomSlice";
import {
  FaSwimmer,
  FaDumbbell,
  FaChild,
  FaGamepad,
  FaConciergeBell,
  FaUtensils,
  FaCocktail,
  FaSpa,
  FaHotel,
} from "react-icons/fa"; // Example Icons

const iconMap = {
  "swimming pool": <FaSwimmer className="border-black w-10 h-10 p-2" />,
  gym: <FaDumbbell className="border-black w-8 h-8 p-2" />,
  "kids play area": <FaChild className="border-black w-8 h-8 p-2" />,
  "indoor games": <FaGamepad className="border-black w-8 h-8 p-2" />,
  restaurant: <FaUtensils className="border-black w-8 h-8 p-2" />,
  "24-hour room service": (
    <FaConciergeBell className="border-black w-8 h-8 p-2" />
  ),
  bar: <FaCocktail className="border-black w-8 h-8 p-2" />,
  lounge: <FaSpa className="border-black w-8 h-8 p-2" />,
  yoga: <FaHotel className="border-black w-8 h-8 p-2" />,
  "butler services": <FaConciergeBell className="border-black w-8 h-8 p-2" />,
  spa: <FaSpa className="border-black w-8 h-8 p-2" />, // Added "spa" key
};

const Amenity = () => {
  const dispatch = useDispatch();
  const { selectedRoomId, rooms, status, error } = useSelector(
    (state) => state.rooms
  );

  useEffect(() => {
    if (status === "idle") {
      dispatch(getRooms());
    }
  }, [dispatch, status]);

  if (status === "loading") {
    return <div>Loading...</div>;
  }

  if (status === "failed") {
    return <div>Error: {error}</div>;
  }

  // Find the specific room based on selectedRoomId from the Redux state
  const roomData = rooms.find((room) => room.roomId === selectedRoomId) || {};

  // If roomData is empty or undefined, show a message that the room is not found
  if (!roomData.roomId) {
    return <div>Room not found</div>;
  }

  const amenities = roomData.hotel?.amenities || [];
  const owner = roomData.hotel?.hotelOwner || {};

  return (
    <div className="max-w-4xl mx-auto bg-white">
      <h1 className="mb-4 text-2xl font-bold">Amenities</h1>
      {/* Amenity Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-4">
        {amenities.map((amenity, index) => (
          <div key={index} className="flex flex-col items-center">
            {/* Icon */}
            {iconMap[amenity.amenityName.toLowerCase()]}

            {/* Amenity Name */}
            <h3 className="text-sm font-semibold text-center mt-2">
              {amenity.amenityName}
            </h3>
          </div>
        ))}
      </div>

      {/* Owner Info Section */}
      <div className="bg-blue-100 p-4 rounded-lg mt-4">
        <div className="flex justify-between space-x-50">
          <p className="text-blue-900 font-medium">
            Owner: {owner.firstName} {owner.lastName}
          </p>
          <p className="text-blue-900">Mobile number: {owner.mobile}</p>
        </div>
      </div>
    </div>
  );
};

export default Amenity;

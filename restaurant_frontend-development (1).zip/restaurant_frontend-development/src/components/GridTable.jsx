import React, { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { IoSearchSharp } from "react-icons/io5";
import { RxCross2 } from "react-icons/rx";
import { Tooltip } from "@mui/material";
import { TbTrash } from "react-icons/tb";
import { FiEdit, FiEye } from "react-icons/fi";
import { FaPlus } from "react-icons/fa6";
import { HiAdjustmentsHorizontal } from "react-icons/hi2";
import AddOwnerList from "../dashboard/addOwnerList";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers, updateUser } from "../app/userApi";

function GridTable({
  rowData,
  columnData,
  onClickAction,
  actions = [],
  onClickAdd,
  onClickFilter,
  filterButtonTitle = "",
  topActionButtonTitle = "",
  toolTipName,
  isFilterAdded,
  hideSearchBar,
  hideAddButton,
  isFilterActive = false,
  onPageChange,
  onPageSizeChange,
}) {
  const [rows, setRows] = useState([]);
  const [cols, setCols] = useState([]);
  const [searchString, setSearchString] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null); // State to manage selected row data
  const amenities = useSelector((state) => state.hotels.amenities);
  const { data: users, loading, totalUsersCount, currentPage, pageSize } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  useEffect(() => {
    if (rowData || columnData) {
      setRows(rowData);
    }
    if (actions?.length > 0 && columnData) {
      const actionColumn = {
        field: "action",
        headerName: "Action",
        width: 150,
        headerClassName: "super-app-theme--header",
        headerAlign: "left",
        renderCell: (param) => (
          <ActionOption
            row={param.row}
            actions={actions}
            onClick={(type) => {
              if (type === "EDIT") {
                setSelectedRowData(param.row);
                setIsModalOpen(true);
              }
              onClickAction && onClickAction(type, param.row, param.row.id);
            }}
          />
        ),
      };
      const newCols = [actionColumn, ...columnData];
      setCols(newCols);
    } else {
      setCols(columnData);
    }
  }, [rowData, columnData, actions]);

  // Handle search functionality
  const requestSearch = (searchValue) => {
    setSearchString(searchValue);
  };

  // Handle filter button click
  const handleFilterClick = () => {
    onClickFilter && onClickFilter();
  };

  // Handle modal close
  const handleCancel = () => {
    setIsModalOpen(false);
    setSelectedRowData(null); // Reset the selected row data
  };

  return (
    <div
      className={`rounded-sm border border-stroke bg-white ${hideSearchBar ? "" : "shadow-default dark:border-strokedark dark:bg-boxdark"}`}
    >
      {/* Search and Filter Section */}
      <div className="relative flex items-center gap-x-4 justify-between my-3 mx-2">
        <div className={`flex items-center rounded-sm border border-bgray ${hideSearchBar ? "hidden" : ""}`}>
          <input
            className="p-2 text-base float-left w-[200px] lg:w-[300px] bg-gray-100 focus:border-transparent outline-none"
            placeholder="Search..."
            value={searchString}
            onChange={(e) => requestSearch(e.target.value)}
          />
          {searchString ? (
            <RxCross2 className="w-5 h-5 mr-2" onClick={() => requestSearch("")} />
          ) : (
            <div className="w-5 h-5 mr-2" />
          )}
          <div className="border-l border-bgray py-2.5 px-3" onClick={() => requestSearch(searchString)}>
            <IoSearchSharp className="h-5 w-5" />
          </div>
        </div>
        <div className={`flex items-center gap-x-4 ${onClickFilter && onClickAdd ? "grid grid-cols-2" : "justify-end w-full pr-4"}`}>
          {/* Filter Button */}
          {onClickFilter && (
            <Tooltip title={"Apply Filters"}>
              <div
                className={`cursor-pointer w-25 h-9 flex items-center justify-center border rounded-lg ${isFilterActive ? "bg-primary text-white border-transparent" : "bg-white text-black border-[#1f7fbb] border-2"}`}
                onClick={handleFilterClick}
              >
                <span className="mr-1">{filterButtonTitle}</span>
                <HiAdjustmentsHorizontal className="h-4 w-6" />
              </div>
            </Tooltip>
          )}
          {/* Add Button */}
          {onClickAdd && !hideAddButton && (
            <Tooltip title={toolTipName}>
              <div
                className="cursor-pointer px-2 w-[auto] h-9 text-white flex items-center justify-center bg-[#4b004f] border border-white rounded-lg"
                onClick={() => {
                  onClickAdd && onClickAdd();
                }}
              >
                <span className="mr-1">{topActionButtonTitle}</span>
                <FaPlus className="h-4 w-4" />
              </div>
            </Tooltip>
          )}
        </div>
      </div>

      {/* DataGrid Section */}
      <div className="w-full h-[calc(100vh-150px)] lg:h-[26rem]">
        <DataGrid
          sx={{
            "& .super-app-theme--header": {
              fontSize: "16px",
              fontWeight: "bold",
              color: "#1f7fbb",
            },
            "& .MuiDataGrid-cell": {
              fontFamily: "sans-serif",
              paddingTop: "15px",
              paddingBottom: "15px",
            },
          }}
          getRowHeight={(params) => "auto"}
          className="bg-white rounded-none dark:border-strokedark dark:bg-boxdark"
          rows={rows}
          columns={cols}
          rowSelection={false}
          paginationMode="server"
          rowCount={totalUsersCount}
          paginationModel={{ page: currentPage, pageSize }}
          onPaginationModelChange={({ page, pageSize }) => {

            onPageChange(page);
            onPageSizeChange(pageSize);
          }}
          pageSizeOptions={[5, 10, 25, 50]}
          disableColumnMenu={true}
          rowHeight={48}
        />
      </div>

      {/* Modal for Add/Edit Owner */}
      {isModalOpen && (
        <AddOwnerList
          hotel={selectedRowData}
          amenities={amenities}
          onSave={(formData) => {
            dispatch(updateUser(formData))
              .unwrap()
              .then((response) => {
                setIsModalOpen(false);
                dispatch(fetchUsers({ page: currentPage, size: pageSize }));
              })
              .catch((error) => {

              });
          }}
          onCancel={handleCancel}
        />
      )}
    </div>
  );
}

export default GridTable;

// Action Options Component
export const ActionOption = ({ onClick, actions = [], row }) => {
  return (
    <div className="flex items-center gap-x-2">
      {actions.includes("DELETE") && (
        <p className="cursor-pointer">
          <TbTrash
            className="w-5 h-5 text-red-500"
            onClick={() => {
              onClick && onClick("DELETE");
            }}
          />
        </p>
      )}
      {actions.includes("EDIT") && (
        <p className="cursor-pointer w-5 h-5">
          <FiEdit
            className="w-5 h-5"
            onClick={() => {

              onClick && onClick("EDIT");
            }}
          />
        </p>
      )}
      {actions.includes("VIEW") && (
        <p className="cursor-pointer w-5 h-5">
          <FiEye
            className="w-5 h-5 text-blue-500"
            onClick={() => onClick && onClick("VIEW")}
          />
        </p>
      )}
    </div>
  );
};
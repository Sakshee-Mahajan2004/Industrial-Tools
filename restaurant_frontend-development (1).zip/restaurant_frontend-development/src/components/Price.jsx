import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getRooms } from "../redux/roomSlice"; // Adjust import according to your file structure

const Price = () => {
  const dispatch = useDispatch();

  // Access the selected roomId from the Redux store
  const { selectedRoomId, rooms, status, error } = useSelector(
    (state) => state.rooms
  );

  // Load rooms on initial render
  useEffect(() => {
    if (status === "idle") {
      dispatch(getRooms());
    }
  }, [dispatch, status]);

  // Handling loading, error, and no data states
  if (status === "loading") {
    return <div>Loading...</div>;
  }

  if (status === "failed") {
    return <div>Error: {error}</div>;
  }

  // Find the specific room based on selectedRoomId from the Redux state
  const roomData = rooms.find((room) => room.roomId === selectedRoomId) || {};

  // If roomData is empty or undefined, show a message that the room is not found
  if (!roomData.roomId) {
    return <div>Room not found</div>;
  }

  return (
    <div className="flex justify-center items-center">
      <section className="bg-white dark:bg-gray-900 w-full max-w-sm">
        <div className="flex flex-col mx-auto text-center text-gray-900 bg-white border border-gray-100 rounded-lg shadow dark:border-gray-600 xl:p-8 dark:bg-gray-800 dark:text-white">
          <h1 className="mb-4 text-2xl font-bold">
            {roomData.hotel?.hotelName || "Unknown Hotel"}
          </h1>
          <p className="font-light text-black sm:text-lg dark:text-gray-400">
            Room Number: {roomData.numberOfRooms}
          </p>
          <div className="flex items-baseline justify-center my-8">
            <span className="mr-2 text-5xl font-extrabold">
              ${roomData.roomBasePrice}
            </span>
            <span className="text-gray-500 dark:text-gray-400">/night</span>
          </div>

          <ul role="list" className="mb-8 space-y-4 text-left">
            <li className="flex items-center space-x-3">
              <svg
                className="flex-shrink-0 w-5 h-5 text-green-500 dark:text-green-400"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                ></path>
              </svg>
              <span>Enjoy complimentary 2 Pint(s) of Beer</span>
            </li>
            <li className="flex items-center space-x-3">
              <svg
                className="flex-shrink-0 w-5 h-5 text-green-500 dark:text-green-400"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                ></path>
              </svg>
              <span>Enjoy Happy Hours with 1+1 offer</span>
            </li>
          </ul>

          <button
            onClick={handleBuyNow}
            href="#"
            className="text-white bg-fuchsia-950 hover:bg-purple-800 focus:ring-4 focus:ring-purple-200 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:text-white dark:focus:ring-purple-900"
          >
            Buy Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default Price;

import React, { useState } from "react";
import img1 from "../assets/room1.jpg"; // Adjust the path to your image

const Image = () => (
  <div className="absolute top-2 right-2 w-20 h-20 sm:w-30 sm:h-30 lg:w-40 lg:h-40">
    <img src={img1} alt="Hotel" className="w-full h-full object-cover rounded-lg" />
  </div>
);

const HotelInfo = () => (
  <div className="hotel-info mb-6 p-4 bg-white shadow rounded relative">
    <h1 className="hotel-name text-2xl font-bold mb-4">Hotel Regent Laguna</h1>
    <p className="mb-2">Hotel ID: 01234</p>
    <p className="mb-2">Couple Friendly</p>
    <p className="mb-2">
      Address: Survey No. 173/3, H.No. - 860/3, Soranto Waddo, Anjuna,
      Bardez, North Goa - 403509, Goa, India
    </p>
    <Image />
  </div>
);

const BookingDetails = ({ mealOption }) => (
  <div className="booking-details mb-6 p-4 bg-white shadow rounded">
    <h2 className="text-xl font-semibold mb-4">Booking Details</h2>
    <div className="booking-row flex justify-between mb-4">
      <div className="booking-time">
        <h3 className="font-semibold">Check In</h3>
        <p>Sat 22 Mar 2025, 2 PM</p>
      </div>
      <div className="booking-time">
        <h3 className="font-semibold">Check Out</h3>
        <p>Sun 23 Mar 2025, 11 AM</p>
      </div>
    </div>
    <div className="booking-row">
      <div className="booking-info">
        <p>1 Night | 2 Adults | 1 Room</p>
        <p>Deluxe Room</p>
        <p>{mealOption}</p>
        <p>Non-Refundable</p>
      </div>
    </div>
  </div>
);

const MealOptions = ({ mealOption, handleMealOptionChange }) => (
  <div className="meal-options mb-6 p-4 bg-white shadow rounded">
    <h3 className="text-lg font-semibold mb-4">Upgrade Your Stay</h3>
    <label className="block mb-2">
      <input
        type="radio"
        name="meal"
        value="Room Only"
        checked={mealOption === "Room Only"}
        onChange={handleMealOptionChange}
        className="mr-2"
      />
      Room Only
    </label>
    <label className="block mb-2">
      <input
        type="radio"
        name="meal"
        value="Add Breakfast for ₹470"
        checked={mealOption === "Add Breakfast for ₹470"}
        onChange={handleMealOptionChange}
        className="mr-2"
      />
      Add Breakfast for ₹470 for all guests
    </label>
    <label className="block mb-2">
      <input
        type="radio"
        name="meal"
        value="Add Breakfast + Lunch/Dinner for ₹1645"
        checked={mealOption === "Add Breakfast + Lunch/Dinner for ₹1645"}
        onChange={handleMealOptionChange}
        className="mr-2"
      />
      Add Breakfast + Lunch/Dinner for ₹1645 for all guests
    </label>
  </div>
);

const ImportantInfo = () => (
  <div className="important-info mb-6 p-4 bg-white shadow rounded">
    <h3 className="text-lg font-semibold mb-4">Important Information</h3>
    <ul className="list-disc list-inside">
      <li>Passport, Aadhar, Driving License and Govt. ID are accepted as ID proof(s).</li>
      <li>Pets are not allowed.</li>
      <li>Outside food is not allowed.</li>
      <li>Unmarried couples allowed.</li>
    </ul>
  </div>
);

const GuestDetails = () => (
  <div className="guest-details mb-6 p-4 bg-white shadow rounded">
    <h3 className="text-lg font-semibold mb-4">Guest Details</h3>
    <label className="block mb-2">Title</label>
    <select className="block w-full mb-4 p-2 border border-gray-300 rounded">
      <option value="Mr">Mr</option>
      <option value="Ms">Ms</option>
      <option value="Mrs">Mrs</option>
    </select>

    <label className="block mb-2">Full Name</label>
    <input type="text" placeholder="First Name" className="block w-full mb-2 p-2 border border-gray-300 rounded" />
    <input type="text" placeholder="Last Name" className="block w-full mb-4 p-2 border border-gray-300 rounded" />

    <label className="block mb-2">Email Address</label>
    <input type="email" placeholder="Email ID" className="block w-full mb-4 p-2 border border-gray-300 rounded" />

    <label className="block mb-2">Mobile Number</label>
    <input type="tel" placeholder="Enter Mobile Number" className="block w-full mb-4 p-2 border border-gray-300 rounded" />

    <label className="block mb-2">Enter GST Details (Optional)</label>
    <input type="text" placeholder="GST Number" className="block w-full mb-4 p-2 border border-gray-300 rounded" />

    <button className="add-guest bg-blue-500 text-white py-2 px-4 rounded">+ Add Guest</button>
  </div>
);

const TripSecure = ({ tripSecure, toggleTripSecure }) => (
  <div className="trip-secure mb-6 p-4 bg-white shadow rounded">
    <h3 className="text-lg font-semibold mb-4">Secure Your Trip</h3>
    <div className="trip-secure-options">
      <p className="mb-2">Enjoy a Worry-Free Stay</p>
      <label className="block mb-2">
        <input
          type="checkbox"
          checked={tripSecure}
          onChange={toggleTripSecure}
          className="mr-2"
        />
        Yes, secure my trip. ₹59 per guest
      </label>
      <p>Non Refundable I 18% GST Included</p>
    </div>
  </div>
);

const Terms = () => (
  <div className="terms mb-6 p-4 bg-white shadow rounded">
    <p>
      By proceeding, I agree to MakeMyTrip’s User Agreement, Terms of Service, and Cancellation & Property Booking Policies.
    </p>
  </div>
);

export const ReviewBooking = () => {
  const [tripSecure, setTripSecure] = useState(false);
  const [mealOption, setMealOption] = useState("Room Only");

  const toggleTripSecure = () => setTripSecure((prev) => !prev);
  const handleMealOptionChange = (e) => setMealOption(e.target.value);

  return (
    <div className="review-booking p-10 bg-gray-100 relative">
      <HotelInfo />
      <BookingDetails mealOption={mealOption} />
      <MealOptions mealOption={mealOption} handleMealOptionChange={handleMealOptionChange} />
      <ImportantInfo />
      <GuestDetails />
      <TripSecure tripSecure={tripSecure} toggleTripSecure={toggleTripSecure} />
      <Terms />
      <button className="pay-now bg-green-500 text-white py-2 px-4 rounded">Pay Now</button>
    </div>
  );
};
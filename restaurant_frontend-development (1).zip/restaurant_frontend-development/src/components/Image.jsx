import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios"; // Import axios for API calls
import { getRooms } from "../redux/roomSlice"; // Adjust import according to your file structure
import SummaryModal from "./SummaryModal"; // Import SummaryModal

const Image = () => {
  const dispatch = useDispatch();
  const { rooms, selectedRoomId, status, error } = useSelector(
    (state) => state.rooms
  );

  const [images, setImages] = useState([]); // State for images
  const [carouselOpen, setCarouselOpen] = useState(false); // Manage carousel visibility
  const [currentImageIndex, setCurrentImageIndex] = useState(0); // Track the current image index
  const [summaryModalOpen, setSummaryModalOpen] = useState(false); // Manage summary modal visibility

  useEffect(() => {
    if (status === "idle") {
      dispatch(getRooms());
    }
  }, [status, dispatch]);

  useEffect(() => {
    const fetchImages = async () => {
      if (!selectedRoomId) return; // Ensure selectedRoomId is defined
      try {
        const response = await axios.get(
          `http://localhost:8080/api/images/getImages`
        );
        console.log("API Response:", response.data); // Debugging the API response

        if (Array.isArray(response.data.data)) {
          const fullImageUrls = response.data.data.map((image) => ({
            ...image,
            imageUrl: `http://localhost:8080/${image.imageUrl.replace(
              /\\/g,
              "/"
            )}`, // Construct full image URLs
          }));
          setImages(fullImageUrls);
        } else {
          console.error("Image API response is not an array:", response.data);
        }
      } catch (error) {
        if (error.response && error.response.status === 404) {
          console.error("No images found for the selected roomId");
          setImages([]); // Set images to an empty array
        } else {
          console.error("Error fetching images:", error);
        }
      }
    };

    fetchImages();
  }, [selectedRoomId]);

  if (status === "loading") {
    return <div>Loading...</div>;
  }

  if (status === "failed") {
    return <div>Error: {error}</div>;
  }

  // Find the room data using the selectedRoomId
  const roomData = rooms.find((room) => room.roomId === selectedRoomId) || {};
  const summaryText = roomData.hotel?.hotelDes || "No description available.";

  // Open carousel with the clicked image
  const openCarousel = (index) => {
    setCurrentImageIndex(index); // Set the clicked image as the starting image in the carousel
    setCarouselOpen(true); // Open the carousel
  };

  // Close carousel
  const closeCarousel = () => setCarouselOpen(false);

  // Go to the next image in the carousel
  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  // Go to the previous image in the carousel
  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  // Close carousel when clicking outside
  const handleBackdropClick = (e) => {
    // Only close the carousel if the click is on the backdrop (not inside the carousel)
    if (e.target === e.currentTarget) {
      closeCarousel();
    }
  };

  // Toggle summary modal
  const toggleSummaryModal = () => {
    setSummaryModalOpen((prev) => !prev);
  };

  return (
    <div>
      {/* Image Section */}
      <div className="flex flex-row items-center space-x-4">
        {/* Left Side - Large Image */}
        <div className="w-full lg:w-2/3 relative">
          {images.length > 0 && (
            <img
              src={images[0].imageUrl}
              alt="Large Image"
              className="w-full h-auto rounded-2xl shadow-lg cursor-pointer"
              onClick={() => openCarousel(0)} // Open the carousel with the first image
            />
          )}
          {/* "12+ Photos" Label */}
          <div className="absolute bottom-4 left-4 text-white text-lg font-semibold opacity-75 hover:opacity-100">
            {images.length} Photos
          </div>
        </div>

        {/* Right Side - Two Small Images */}
        <div className="flex flex-col space-y-4 w-full lg:w-1/3">
          {images.slice(1, 3).map((image, index) => (
            <div key={index} className="relative group">
              <img
                src={image.imageUrl}
                alt={`Small Image ${index + 1}`}
                className="w-full h-auto rounded-2xl shadow-lg cursor-pointer"
                onClick={() => openCarousel(index + 1)} // Open the carousel with the clicked image
              />
              {/* "12+ Photos" Label */}
              <div className="absolute bottom-4 left-4 text-white text-lg font-semibold opacity-75 group-hover:opacity-100">
                {images.length} Photos
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Summary Section Below Image */}
      <div className="mt-4">
        <p className="text-gray-700">{summaryText.slice(0, 150)}...</p>
        <button
          onClick={toggleSummaryModal}
          className="text-blue-500 font-semibold hover:underline"
        >
          Read More
        </button>
      </div>

      {/* Carousel Display */}
      {carouselOpen && (
        <div
          className="fixed inset-0  backdrop-blur-sm flex justify-center items-center z-50"
          onClick={handleBackdropClick} // Close carousel when clicking outside
        >
          <div
            className="bg-white p-6 rounded-lg shadow-lg w-1/2 relative" // Set width to 1/2 of the page
            onClick={(e) => e.stopPropagation()} // Prevent closing the carousel when clicking inside
          >
            {/* Close Carousel Button */}
            <button
              onClick={closeCarousel}
              className="absolute top-1 right-2 text-xl font-bold text-gray-600 cursor-pointer"
            >
              ×
            </button>

            {/* Carousel Controls */}
            <div className="relative flex justify-center items-center mb-6">
              <button
                onClick={prevImage}
                className="absolute left-4 text-white text-2xl font-semibold bg-black bg-opacity-50 rounded-full p-2"
              >
                &lt;
              </button>

              {/* Display the selected image */}
              <img
                src={images[currentImageIndex]?.imageUrl}
                alt={`Room Image ${currentImageIndex + 1}`}
                className="w-full h-auto rounded-2xl shadow-lg" // Use full width and auto height
              />

              <button
                onClick={nextImage}
                className="absolute right-4 text-white text-2xl font-semibold bg-black bg-opacity-50 rounded-full p-2"
              >
                &gt;
              </button>
            </div>

            <div className="flex justify-center space-x-4 mt-4">
              {images.map((image, index) => (
                <img
                  key={index}
                  src={image.imageUrl}
                  className="w-10 h-10 rounded-2xl shadow-lg cursor-pointer object-cover"
                  onClick={() => setCurrentImageIndex(index)}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Summary Modal */}
      {summaryModalOpen && (
        <SummaryModal summary={summaryText} closeModal={toggleSummaryModal} />
      )}
    </div>
  );
};

export default Image;

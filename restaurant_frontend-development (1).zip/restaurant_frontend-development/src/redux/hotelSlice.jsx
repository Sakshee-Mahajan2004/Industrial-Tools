import { createSlice } from "@reduxjs/toolkit";
import {
  fetchHotels,
  fetchAmenities,
  saveHotel,
  updateHotel,
  deleteHotel,
  fetchHotelOwners,
  fetchHotelsByLocation,
  fetchHotelsByCity,
  getAllHotels,
} from "../app/hotelApi";

const hotelSlice = createSlice({
  name: "hotels",
  initialState: {
    hotels: [],
    cities: [],
    amenities: [],
    owners: [],
    locations: [],
    status: "idle",
    error: null,
    currentPage: 0,
    totalPages: 0,
    pageSize: 5,
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
      state.totalPages = Math.ceil(state.hotels.length / action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHotels.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotels.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = action.payload.hotels;
        state.cities = action.payload.cities;
        state.totalPages = Math.ceil(action.payload.total / state.pageSize);
      })
      .addCase(fetchHotels.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(getAllHotels.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllHotels.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = action.payload.data;
        state.totalPages = Math.ceil(action.payload.total / state.pageSize);
      })
      .addCase(getAllHotels.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchHotelsByCity.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotelsByCity.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.rooms = action.payload.hotels;
        state.totalPages = Math.ceil(action.payload.total / state.pageSize);
      })
      .addCase(fetchHotelsByCity.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchAmenities.fulfilled, (state, action) => {
        state.amenities = action.payload;
      })
      .addCase(fetchAmenities.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchAmenities.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(saveHotel.pending, (state) => {
        state.status = "loading";
      })
      .addCase(saveHotel.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels.push(action.payload);
      })
      .addCase(saveHotel.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(updateHotel.pending, (state) => {
        state.status = "loading";
      })
      .addCase(updateHotel.fulfilled, (state, action) => {
        state.status = "succeeded";
        const updatedHotel = action.payload;
        const index = state.hotels.findIndex(
          (hotel) => hotel.hotelId === updatedHotel.hotelId
        );
        if (index !== -1) {
          state.hotels[index] = updatedHotel;
        }
      })
      .addCase(updateHotel.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(deleteHotel.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteHotel.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = state.hotels.filter(
          (hotel) => hotel.hotelId !== action.payload
        );
      })
      .addCase(deleteHotel.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchHotelOwners.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHotelOwners.fulfilled, (state, action) => {
        state.owners = action.payload;
        state.loading = false;
      })
      .addCase(fetchHotelOwners.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(fetchHotelsByLocation.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotelsByLocation.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.locations = action.payload; 
      })     
      .addCase(fetchHotelsByLocation.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      });
  },
});

export const { setCurrentPage, setPageSize } = hotelSlice.actions;

export default hotelSlice.reducer;
import { createSlice } from "@reduxjs/toolkit";
import { fetchUsers, loginUser, registerOwner, registerUser } from "../app/userApi";
import { KEY } from "../utils/Constant";

const getLoggedInUserInfo = () => {
    let data = localStorage.getItem(KEY.USER_INFO)

    if (data) {
        data = JSON.parse(data)
    }
    return data
}

const initialState = {
    data: [],
    loading: false,
    error: false,
    message: null,
    userInfo: getLoggedInUserInfo(),
    regResponse: null,
    totalUsersCount: 0,
    currentPage: 0,
    pageSize: 5,
    adminId: null
};

const userSlice = createSlice({
    name: "user",
    initialState,
    reducers: {
        resetMessage: (state) => {
            state.loading = false;
            state.message = "";
        },

        logout: (state) => {
            state.userInfo = null;
            state.message = "";
        },
        setPage: (state, action) => {
            state.currentPage = action.payload;
        },
        setPageSize: (state, action) => {

            state.pageSize = action.payload;
        },
        setAdminId: (state, action) => {
            state.adminId = action.payload;
        }
    },

    extraReducers: (builder) => {
        builder
            .addCase(fetchUsers.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchUsers.fulfilled, (state, action) => {
                state.loading = false;
                state.data = action.payload.data || [];
                state.totalUsersCount = action.payload.total || 0;
            })
            .addCase(fetchUsers.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            .addCase(registerOwner.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.error = false;
                state.data.push(payload.data);
            })
            .addCase(registerOwner.pending, (state) => {
                state.loading = true;
            })
            .addCase(registerOwner.rejected, (state, { payload }) => {
                state.loading = false;
                state.error = true;
                state.message = payload;
            })

            // login
            .addCase(loginUser.pending, (state) => {
                state.loading = true;
                state.userInfo = null;
                state.message = "";
            })
            .addCase(loginUser.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.userInfo = payload.data;
                state.message = payload.message;
            })
            .addCase(loginUser.rejected, (state, action) => {
                state.loading = false;
                state.userInfo = null;
                state.message = action.payload;
            })

            // Register
            .addCase(registerUser.pending, (state) => {
                state.loading = true;
                state.regResponse = null;
                state.message = "";
            })
            .addCase(registerUser.fulfilled, (state, { payload }) => {
                state.loading = false;
                state.regResponse = payload;
                state.message = payload.message;
            })
            .addCase(registerUser.rejected, (state, action) => {
                state.loading = false;
                state.regResponse = null;
                state.message = action.payload;
            })
    },
});

export const { resetMessage, logout, setPage, setPageSize, setAdminId } = userSlice.actions;
export default userSlice.reducer;

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { fetchRooms } from "../app/roomApi";
 
export const getRooms = createAsyncThunk(
  "rooms/getRooms",
  async ({ page, size }) => {
    const response = await fetchRooms(`/hotel/getAll?page=${page}&size=${size}&sortDirection=asc&sortBy=hotelId`);
    return response.data;
  }
);
 
const roomSlice = createSlice({
  name: "rooms",
  initialState: {
    rooms: [],
    selectedRoomId: null,
    status: "idle", 
    error: null,
    currentPage: 0, 
    pageSize: 10, 
    
  },
  
  reducers: {
    setSelectedRoomId: (state, action) => {
      state.selectedRoomId = action.payload;
    },
    setPage: (state, action) => {
      state.currentPage = action.payload; 
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload; 
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getRooms.pending, (state) => {
        state.status = "loading";
        state.status = "loading";
      })
      .addCase(getRooms.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.status = "succeeded";
        state.rooms = action.payload;
      })
      .addCase(getRooms.rejected, (state, action) => {
        state.status = "failed";
        state.status = "failed";
        state.error = action.error.message;
      });
  },
});
 
export const { setSelectedRoomId, setPage, setPageSize } = roomSlice.actions;
export default roomSlice.reducer;

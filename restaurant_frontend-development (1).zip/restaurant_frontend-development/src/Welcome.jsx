import React from "react";

const Welcome = () => {
  return (
    <div>
      <p>React Vite setup with Tailwind Css</p>
      <a href="https://preview.colorlib.com/#samira">
        Click here to see demo website
      </a>
    </div>
  );
};

export default Welcome;

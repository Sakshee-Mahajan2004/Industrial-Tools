import axiosInstance, { get } from "./axiosInstance";
import { createAsyncThunk } from "@reduxjs/toolkit";

export const fetchHotelOwners = createAsyncThunk(
  "hotels/fetchHotelOwners",
  async ({ page = 0, size = 15 } = {}) => {
    const response = await get(`/user/allUsers?page=${page}&size=${size}`);
    const hotelOwners = response.data.data.filter(
      (user) => user.role.roleId === 1002
    );
    return hotelOwners;
  }
);

export const fetchHotelsByLocation = createAsyncThunk(
  "hotels/fetchHotelsByLocation",
  async (_, { rejectWithValue }) => {
    try {
      const response = await get(`/hotel/hotelLocation`);
      return response.data.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
export const fetchHotelsByCity = createAsyncThunk(
  "hotels/fetchHotelsByCity",
  async ({ city, hotelRooms = 1, page = 0, size = 20 }) => {
    const response = await get(
      `/hotel/hotelCity?city=${city}&hotelRooms=${hotelRooms}&page=${page}&size=${size}`
    );
    return {
      hotels: response.data.data,
      total: response.data.total,
    };
  }
);
export const getAllHotels = createAsyncThunk(
  "hotels/getAllHotels",
  async ({ page, size }) => { 
    const response = await get(`/hotel/getAll?page=${page}&size=${size}`);
    return response.data.data;
  }
);

export const fetchHotels = createAsyncThunk(
  "hotels/fetchHotels",
  async ({  city, hotelRooms = 1, page = 0, size = 20  } = {}) => {
    const response = await get(
      `/hotel/hotelCity?city=${city}&hotelRooms=${hotelRooms}&page=${page}&size=${size}`
    );
      return {
        hotels: response.data.data,
        total: response.data.total,
    };
  }
);

export const fetchAmenities = createAsyncThunk(
  "hotels/fetchAmenities",
  async ({ page = 0, size = 20 } = {}) => {
    const response = await get(`/masterAmenity/getAll?page=${page}&size=${size}`);
    return response.data.data;
  }
);

export const saveHotel = createAsyncThunk(
  "hotels/saveHotel",
  async (hotelData) => {
    const response = await axiosInstance.post("/hotel/save", hotelData);
    return response.data.data;
  }
);

export const updateHotel = createAsyncThunk(
  "hotels/updateHotel",
  async (hotelData) => {
    const response = await axiosInstance.put(`/hotel/update/${hotelData.hotelId}`, hotelData);
    return response.data.data;
  }
);

export const deleteHotel = createAsyncThunk(
  "hotels/deleteHotel",
  async (hotelId) => {
    await axiosInstance.delete(`/hotel/delete/${hotelId}`);
    return hotelId;
  }
);
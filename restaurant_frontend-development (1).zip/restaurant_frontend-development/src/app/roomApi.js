import axiosInstance from "./axiosInstance";
 
export const fetchRooms = async (url) => {
  const response = await axiosInstance.get(url);
  if (!response.data || !response.data.data) {
    throw new Error("Invalid response structure");
  }
  return response.data.data;
};
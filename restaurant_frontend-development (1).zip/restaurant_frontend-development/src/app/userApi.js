import { createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance, { post, get } from "./axiosInstance";
import { KEY } from "../utils/Constant";


export const loginUser = createAsyncThunk(
    "user/login",
    async (data, { rejectWithValue }) => {
        try {
            const response = await post("/user/login", data);
            if (response) {
                const token = response.data.token;
                localStorage.setItem(KEY.TOKEN, token);
                localStorage.setItem(KEY.USER_INFO, JSON.stringify(response.data));
                axiosInstance.defaults.headers.common['Authorization'] = "Bearer " + token;
                return response;
            }
        } catch (error) {
            return rejectWithValue(
                error.data?.error || "Login failed, please try again."
            );
        }
    }
);

export const registerUser = createAsyncThunk(
    "user/register",
    async (data, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.post("/user/register", data)
            if (response.status === 200) {
                return response.data;
            }
        } catch (error) {

            return rejectWithValue(
                error.response?.data?.error || "Registration failed, please try again."
            );
        }
    }
)


// Fetch all users
export const fetchUsers = createAsyncThunk(
    "user/fetchUsers",
    async ({ page, size }) => {
        const response = await get(`/user/allUsers?page=${page}&size=${size}`);
        return response.data.data;

    });

// Fetch  AdminProfile by id
export const fetchUserById = createAsyncThunk(
    "user/users",
    // 
    async (adminId) => {
        const response = await get(`/user/users/${adminId}`);

        return response.data;
    });

export const updateUser = createAsyncThunk(
    "user/updateUser",
    async (userData) => {
        try {
            const response = await axiosInstance.put(
                `/user/updateUser/${userData.id}`,
                {
                    firstName: userData.name,
                    lastName: userData.lastName,
                    mobile: userData.phoneNo,
                }
            );

            return response.data;
        } catch (error) {

            throw error;
        }
    }
);

export const verifyEmail = createAsyncThunk("user/verifyEmail", async (data, { rejectWithValue, dispatch }) => {
    console.log('data: ', data);
    try {
        const response = await axiosInstance.post(`verifyEmail/${data}`);
        console.log(response, "resposne at verifyEmail");
        if (response && response.status === 200) {

        }
    } catch {
        console.error("Error:", error);
        return rejectWithValue(
            error.response?.data?.error || "Registration failed, please try again."
        );

    }
})

export const registerOwner = createAsyncThunk(
    "user/registerOwner",
    async (userData, { rejectWithValue }) => {
        try {
            const response = await axiosInstance.post("/user/Owner/register", userData);
            if (response.data) {
                return response.data;
            } else {
                return rejectWithValue("Invalid response from server");
            }
        } catch (error) {
            return rejectWithValue(
                error.response?.data?.error || "Failed to register owner."
            );
        }
    }
);

